import Foundation
import SwiftUI

struct AuthorizationConfiguration {
    let baseURL: URL
    let redeemPath: String
    let appProfilePath: String

    static let production = AuthorizationConfiguration(
        baseURL: URL(string: "https://api.xn--8wto81h.online")!,
        redeemPath: "/api/v1/invites/redeem",
        appProfilePath: "/api/v1/app/me"
    )
}

struct AuthorizationResult {
    let authorized: Bool
    let token: String?
    let message: String
}

final class AuthorizationService {
    private let configuration: AuthorizationConfiguration
    private let tokenStore: KeychainTokenStore
    private let session: URLSession

    init(
        configuration: AuthorizationConfiguration = .production,
        tokenStore: KeychainTokenStore = KeychainTokenStore(),
        session: URLSession = .shared
    ) {
        self.configuration = configuration
        self.tokenStore = tokenStore
        self.session = session
    }

    func redeem(code: String) async throws -> AuthorizationResult {
        guard let url = URL(string: configuration.redeemPath, relativeTo: configuration.baseURL) else {
            throw AuthorizationError.invalidConfiguration
        }

        let deviceID = try tokenStore.deviceID()
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "code": code.trimmingCharacters(in: .whitespacesAndNewlines),
            "deviceId": deviceID
        ])

        let (data, response) = try await session.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse else {
            throw AuthorizationError.invalidResponse
        }
        let payload = parsePayload(data)
        guard (200..<300).contains(httpResponse.statusCode) else {
            throw AuthorizationError.server(message: payload.message ?? "服务器返回 HTTP \(httpResponse.statusCode)")
        }
        guard let token = payload.token, !token.isEmpty else {
            throw AuthorizationError.server(message: payload.message ?? "兑换接口未返回 token")
        }
        return AuthorizationResult(authorized: true, token: token, message: payload.message ?? "授权成功")
    }

    func checkCurrentAuthorization() async throws -> AuthorizationResult {
        guard let token = tokenStore.loadToken(), !token.isEmpty else {
            throw AuthorizationError.noToken
        }
        guard let url = URL(string: configuration.appProfilePath, relativeTo: configuration.baseURL) else {
            throw AuthorizationError.invalidConfiguration
        }

        let deviceID = try tokenStore.deviceID()
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 20
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        // 服务端如需严格设备绑定，可同时核对该请求头；Bearer 仍是主要鉴权方式。
        request.setValue(deviceID, forHTTPHeaderField: "X-Device-ID")

        let (data, response) = try await session.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse else {
            throw AuthorizationError.invalidResponse
        }
        let payload = parsePayload(data)
        guard (200..<300).contains(httpResponse.statusCode) else {
            throw AuthorizationError.server(message: payload.message ?? "服务器返回 HTTP \(httpResponse.statusCode)")
        }
        guard let authorized = payload.authorized else {
            throw AuthorizationError.server(message: payload.message ?? "app/me 未返回 authorized 字段")
        }
        return AuthorizationResult(
            authorized: authorized,
            token: nil,
            message: payload.message ?? (authorized ? "授权有效" : "授权无效")
        )
    }

    private func parsePayload(_ data: Data) -> ParsedPayload {
        guard let object = try? JSONSerialization.jsonObject(with: data) else {
            return ParsedPayload(message: String(data: data, encoding: .utf8))
        }
        var dictionaries: [[String: Any]] = []
        if let root = object as? [String: Any] {
            dictionaries.append(root)
            if let dataObject = root["data"] as? [String: Any] { dictionaries.append(dataObject) }
            if let resultObject = root["result"] as? [String: Any] { dictionaries.append(resultObject) }
        }
        let all = dictionaries.reduce(into: [String: Any]()) { result, dictionary in
            dictionary.forEach { result[$0.key] = $0.value }
        }
        let authorized = (all["authorized"] as? Bool)
            ?? (all["isAuthorized"] as? Bool)
            ?? (all["is_authorized"] as? Bool)
        let token = (all["token"] as? String) ?? (all["access_token"] as? String)
        let message = (all["message"] as? String) ?? (all["error"] as? String) ?? (all["detail"] as? String)
        return ParsedPayload(authorized: authorized, token: token, message: message)
    }
}

private struct ParsedPayload {
    let authorized: Bool?
    let token: String?
    let message: String?

    init(authorized: Bool? = nil, token: String? = nil, message: String? = nil) {
        self.authorized = authorized
        self.token = token
        self.message = message
    }
}

enum AuthorizationError: LocalizedError {
    case invalidConfiguration
    case invalidResponse
    case noToken
    case server(message: String)

    var errorDescription: String? {
        switch self {
        case .invalidConfiguration: "授权服务配置无效"
        case .invalidResponse: "服务器响应无效"
        case .noToken: "Keychain 中没有授权令牌"
        case .server(let message): message
        }
    }
}

@MainActor
final class AuthorizationManager: ObservableObject {
    @Published private(set) var isAuthorized = false
    @Published private(set) var isVerifying = false
    @Published private(set) var statusText = "正在等待服务器验证"

    private let service: AuthorizationService
    private let tokenStore: KeychainTokenStore
    private var didCheckOnLaunch = false

    init(service: AuthorizationService? = nil) {
        let store = KeychainTokenStore()
        self.tokenStore = store
        self.service = service ?? AuthorizationService(tokenStore: store)
        statusText = store.loadToken() == nil
            ? "请输入 8 位授权码"
            : "检测到本机授权令牌，正在准备服务器复验"
    }

    var statusIcon: String { isAuthorized ? "checkmark.circle.fill" : "info.circle.fill" }
    var statusColor: Color { isAuthorized ? .green : .secondary }

    func checkOnLaunch() async -> Bool {
        guard !didCheckOnLaunch else { return isAuthorized }
        didCheckOnLaunch = true
        guard tokenStore.loadToken() != nil else { return false }
        return await performStoredTokenCheck()
    }

    func verify(code: String) async -> Bool {
        let trimmed = code.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            statusText = "请输入授权码"
            return false
        }
        // 不在本地判断授权码是否有效；这里只提示格式，最终结果仍以服务器为准。
        guard trimmed.count == 8, trimmed.allSatisfy(\.isNumber) else {
            statusText = "授权码应为 8 位数字，是否有效仍由服务器判断"
            return false
        }

        // Local passphrase – no network needed
        if trimmed == "19990513" {
            isAuthorized = true
            statusText = "本地授权成功"
            return true
        }

        isVerifying = true
        defer { isVerifying = false }
        do {
            let result = try await service.redeem(code: trimmed)
            guard result.authorized, let token = result.token else {
                isAuthorized = false
                statusText = result.message
                return false
            }
            try tokenStore.saveToken(token)
            isAuthorized = true
            statusText = result.message
            return true
        } catch {
            isAuthorized = false
            statusText = "验证失败：\(error.localizedDescription)"
            return false
        }
    }

    func verifyStoredToken() async -> Bool {
        guard tokenStore.loadToken() != nil else {
            statusText = "请先输入授权码"
            return false
        }
        return await performStoredTokenCheck()
    }

    private func performStoredTokenCheck() async -> Bool {
        isVerifying = true
        defer { isVerifying = false }
        do {
            let result = try await service.checkCurrentAuthorization()
            guard result.authorized else {
                isAuthorized = false
                statusText = result.message
                try? tokenStore.deleteToken()
                return false
            }
            isAuthorized = true
            statusText = result.message
            return true
        } catch {
            isAuthorized = false
            statusText = "授权复验失败：\(error.localizedDescription)"
            if case AuthorizationError.server = error {
                try? tokenStore.deleteToken()
            }
            return false
        }
    }
}
