//
//  FileBrowserView.swift
//  mond
//
//  Reconstructed from the 1.6 binary's symbols, reflection metadata and
//  user-facing strings. The browser never requests the /private/var parent:
//  system access is granted and verified one precise target at a time.
//

import Combine
import Foundation
import QuickLook
import SwiftUI
import UniformTypeIdentifiers

/// Keeps iOS's `/private/var` spelling stable even when a simulator exposes the
/// same directory through its `/var` symlink. This is used only for access and
/// containment decisions; actual file operations continue to use their URL.
private func logicalPath(_ url: URL) -> String {
    let path = (url.path as NSString).standardizingPath
    if path == "/var" || path.hasPrefix("/var/") {
        return "/private\(path)"
    }
    return path
}

enum BrowserAccessMode {
    case sandbox
    case systemManaged
}

struct SystemTarget: Identifiable, Hashable {
    let title: String
    let subtitle: String
    let icon: String
    let mode: BrowserAccessMode
    let queryPath: String
    let allowsManagedWrites: Bool

    var id: String { queryPath }
    var url: URL { URL(fileURLWithPath: queryPath, isDirectory: true) }
}

struct BrowserRoot {
    let root: URL
    var sandboxHandles: [Int64]
    var grantedTargetPaths: Set<String>
    let supportedSystemTargets: [SystemTarget]

    init(
        root: URL,
        sandboxHandles: [Int64] = [],
        grantedTargetPaths: Set<String> = [],
        supportedSystemTargets: [SystemTarget] = []
    ) {
        self.root = root
        self.sandboxHandles = sandboxHandles
        self.grantedTargetPaths = grantedTargetPaths
        self.supportedSystemTargets = supportedSystemTargets
    }

    var accessMode: BrowserAccessMode {
        logicalPath(root).hasPrefix("/private/var") ? .systemManaged : .sandbox
    }

    var title: String {
        if logicalPath(root) == "/private/var" { return "系统位置" }
        if let target = supportedSystemTargets.first(where: { logicalPath($0.url) == logicalPath(root) }) {
            return target.title
        }
        switch root.lastPathComponent {
        case "Documents": return "文稿"
        case "Application Support": return "App 支持数据"
        case "Caches": return "缓存"
        default: return root.lastPathComponent.isEmpty ? root.path : root.lastPathComponent
        }
    }

    var subtitle: String {
        if logicalPath(root) == "/private/var" {
            return "请选择精确目标；不会请求父目录权限"
        }
        if let target = supportedSystemTargets.first(where: { logicalPath($0.url) == logicalPath(root) }) {
            return target.subtitle
        }
        switch root.lastPathComponent {
        case "Documents": return "可编辑，并可通过文件 App 或 iTunes 共享查看"
        case "Application Support": return "可编辑的 App 支持和偏好设置文件"
        case "Caches": return "可编辑缓存，iOS 可在需要时清理"
        default: return root.path
        }
    }

    var icon: String {
        if logicalPath(root) == "/private/var" { return "externaldrive.badge.questionmark" }
        if let target = supportedSystemTargets.first(where: { logicalPath($0.url) == logicalPath(root) }) {
            return target.icon
        }
        switch root.lastPathComponent {
        case "Documents": return "doc"
        case "Application Support": return "books.vertical"
        case "Caches": return "clock.arrow.circlepath"
        default: return "folder"
        }
    }

    static let systemTargets: [SystemTarget] = [
        SystemTarget(
            title: "MobileGestalt 缓存",
            subtitle: "设备能力与外观缓存",
            icon: "iphone.gen3",
            mode: .systemManaged,
            queryPath: TweakPaths.gestalt_dir,
            allowsManagedWrites: true
        ),
        SystemTarget(
            title: "MDM 配置文件",
            subtitle: "Apple 商务管理和学校管理使用的 MDM 配置存储",
            icon: "shield.lefthalf.filled",
            mode: .systemManaged,
            queryPath: TweakPaths.mdm_profiles_dir,
            allowsManagedWrites: true
        ),
        SystemTarget(
            title: "系统数据容器",
            subtitle: "/private/var/containers/Data/System",
            icon: "gearshape.2",
            mode: .systemManaged,
            queryPath: "/private/var/containers/Data/System/",
            allowsManagedWrites: true
        ),
        SystemTarget(
            title: "App 容器",
            subtitle: "/private/var/mobile/Containers/Data/Application",
            icon: "app.badge",
            mode: .systemManaged,
            queryPath: "/private/var/mobile/Containers/Data/Application/",
            allowsManagedWrites: true
        ),
        SystemTarget(
            title: "内部守护进程容器",
            subtitle: "/private/var/mobile/Containers/Data/InternalDaemon",
            icon: "server.rack",
            mode: .systemManaged,
            queryPath: "/private/var/mobile/Containers/Data/InternalDaemon/",
            allowsManagedWrites: true
        ),
        SystemTarget(
            title: "插件容器",
            subtitle: "/private/var/mobile/Containers/Data/PluginKitPlugin",
            icon: "puzzlepiece.extension",
            mode: .systemManaged,
            queryPath: "/private/var/mobile/Containers/Data/PluginKitPlugin/",
            allowsManagedWrites: true
        ),
        SystemTarget(
            title: "App 群组容器",
            subtitle: "/private/var/mobile/Containers/Shared/AppGroup",
            icon: "square.3.layers.3d",
            mode: .systemManaged,
            queryPath: "/private/var/mobile/Containers/Shared/AppGroup/",
            allowsManagedWrites: true
        )
    ]

    static var documents: BrowserRoot {
        BrowserRoot(root: FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0])
    }

    static var applicationSupport: BrowserRoot {
        let url = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        return BrowserRoot(root: url)
    }

    static var caches: BrowserRoot {
        BrowserRoot(root: FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0])
    }

    static var systemIndex: BrowserRoot {
        BrowserRoot(
            root: URL(fileURLWithPath: "/private/var", isDirectory: true),
            supportedSystemTargets: systemTargets
        )
    }

    static var mdmProfiles: BrowserRoot {
        BrowserRoot(
            root: URL(fileURLWithPath: TweakPaths.mdm_profiles_dir, isDirectory: true),
            supportedSystemTargets: systemTargets
        )
    }

    static func preciseSystemTarget(_ target: SystemTarget) -> BrowserRoot {
        BrowserRoot(root: target.url, supportedSystemTargets: systemTargets)
    }
}

struct FileNode: Identifiable, Hashable {
    let url: URL
    let isDirectory: Bool
    let size: Int64
    let modified: Date?

    var id: String { logicalPath(url) }
}

private enum FileBrowserError: LocalizedError {
    case exploitFailed(Int64)
    case grantDidNotOpenPath(String)
    case writeProbeFailed(String)
    case protectedSystemItem(String)
    case backupFailed(String)
    case deletionVerificationFailed(String)
    case editorUnsupported(String)
    case fileTooLarge(String)
    case invalidName
    case readOnly
    case outsideRoot
    case directoryMutationBlocked

    var errorDescription: String? {
        switch self {
        case .exploitFailed(let code):
            let detail: String
            switch code {
            case -255: detail = "请求的路径不是绝对路径。"
            case -254: detail = "该路径在此设备上不存在。"
            case -5: detail = "无法构建遍历路径。"
            case -4: detail = "iOS 拒绝签发沙盒扩展。"
            case -3: detail = "containermanager 未返回对象。当前精确路径或 iOS 版本不受支持。"
            case -2: detail = "无法创建容器查询。"
            case -1: detail = "缺少必需的容器管理符号。"
            default: detail = "访问请求失败。"
            }
            return "\(detail) bad_query 返回 \(code)。"
        case .grantDidNotOpenPath(let path):
            return "bad_query 已返回句柄，但 \(path) 仍无法读取。"
        case .writeProbeFailed(let path):
            return "已获得读取权限，但 iOS 未授予对 \(path) 的写入权限。"
        case .protectedSystemItem(let name):
            return "\(name) 不能重命名。可以编辑，或通过单独的备份后关键删除流程删除。"
        case .backupFailed(let reason):
            return "安全备份失败，因此已取消系统更改：\(reason)"
        case .deletionVerificationFailed(let path):
            return "已请求删除，但重新读取目录后 \(path) 仍然存在。iOS 可能已立即重建该文件，安全备份已保留。"
        case .editorUnsupported(let name):
            return "\(name) 不是受支持的可编辑文本、JSON、XML 或属性列表文件。"
        case .fileTooLarge(let name):
            return "\(name) 过大；内置编辑器上限为 2 MB。"
        case .invalidName:
            return "名称不能为空、“.”、“..”，也不能包含斜杠。"
        case .readOnly:
            return "当前位置未启用写入。"
        case .outsideRoot:
            return "请求的路径位于当前选定根目录之外。"
        case .directoryMutationBlocked:
            return "此浏览器不允许重命名或删除系统目录。"
        }
    }
}

@MainActor
final class FileBrowserModel: ObservableObject {
    @Published private(set) var currentURL: URL
    @Published private(set) var nodes: [FileNode] = []
    @Published private(set) var isLoading = false
    @Published private(set) var errorMessage: String?
    @Published private(set) var accessNote: String?
    @Published private(set) var operationMessage: String?
    @Published private(set) var unlockedWriteTarget: String?

    private var root: BrowserRoot
    private let fileManager = FileManager.default

    init(root: BrowserRoot) {
        self.root = root
        currentURL = root.root
    }

    deinit {
        for handle in root.sandboxHandles where handle >= 0 {
            bad_query_release(handle)
        }
    }

    var rootTitle: String { root.title }
    var rootSubtitle: String { root.subtitle }

    var isSystemIndex: Bool {
        logicalPath(root.root) == "/private/var"
    }

    var canGoUp: Bool {
        !isSystemIndex && logicalPath(currentURL) != logicalPath(root.root)
    }

    var canEdit: Bool {
        guard contains(currentURL) else { return false }
        if root.accessMode == .sandbox { return true }
        guard let target = systemTarget(containing: currentURL) else { return false }
        return unlockedWriteTarget == logicalPath(target.url)
    }

    var canUnlockSystemEditing: Bool {
        guard root.accessMode == .systemManaged,
              !isSystemIndex,
              let target = systemTarget(containing: currentURL),
              target.allowsManagedWrites else { return false }
        return unlockedWriteTarget != logicalPath(target.url)
    }

    func canRename(_ node: FileNode) -> Bool {
        canEdit && contains(node.url) && !(root.accessMode == .systemManaged && node.isDirectory) && !isCriticalSystemFile(node.url)
    }

    func reload() {
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }

        if isSystemIndex {
            nodes = root.supportedSystemTargets.map {
                FileNode(url: $0.url, isDirectory: true, size: 0, modified: nil)
            }
            accessNote = "请选择 /private/var 下的精确目标。虚拟文件夹不会被误显示为访问成功。"
            return
        }

        do {
            if root.accessMode == .systemManaged {
                try grantSystemAccess(to: currentURL, requireFreshExtension: false)
            }
            let keys: Set<URLResourceKey> = [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey]
            nodes = try fileManager.contentsOfDirectory(
                at: currentURL,
                includingPropertiesForKeys: Array(keys),
                options: []
            ).map { url in
                let values = try url.resourceValues(forKeys: keys)
                return FileNode(
                    url: url,
                    isDirectory: values.isDirectory ?? false,
                    size: Int64(values.fileSize ?? 0),
                    modified: values.contentModificationDate
                )
            }.sorted {
                if $0.isDirectory != $1.isDirectory { return $0.isDirectory }
                return $0.url.lastPathComponent.localizedStandardCompare($1.url.lastPathComponent) == .orderedAscending
            }
        } catch {
            nodes = []
            errorMessage = error.localizedDescription
        }
    }

    func open(_ node: FileNode) {
        guard node.isDirectory, contains(node.url) else {
            errorMessage = FileBrowserError.outsideRoot.localizedDescription
            return
        }
        currentURL = node.url.standardizedFileURL
        operationMessage = nil
        reload()
    }

    func goUp() {
        guard canGoUp else { return }
        let parent = currentURL.deletingLastPathComponent().standardizedFileURL
        guard contains(parent) else { return }
        currentURL = parent
        operationMessage = nil
        reload()
    }

    func unlockSystemEditing() {
        errorMessage = nil
        operationMessage = nil
        do {
            guard let target = systemTarget(containing: currentURL) else {
                throw FileBrowserError.outsideRoot
            }
            do {
                try grantSystemAccess(to: target.url, requireFreshExtension: true)
            } catch {
                accessNote = "新的写入授权失败（\(error.localizedDescription)）；正通过实际文件操作测试当前进程已有的可读扩展。"
            }
            try verifyWriteOperations(in: target.url)
            unlockedWriteTarget = logicalPath(target.url)
            operationMessage = "已在 \(target.url.path) 验证创建、重命名、原子替换和删除。更改现有系统文件前会先备份。"
        } catch {
            unlockedWriteTarget = nil
            errorMessage = error.localizedDescription
        }
    }

    func editableText(for node: FileNode) throws -> String {
        guard !node.isDirectory else { throw FileBrowserError.editorUnsupported(node.url.lastPathComponent) }
        guard node.size <= 2 * 1_024 * 1_024 else {
            throw FileBrowserError.fileTooLarge(node.url.lastPathComponent)
        }
        guard Self.editableExtensions.contains(node.url.pathExtension.lowercased()) else {
            throw FileBrowserError.editorUnsupported(node.url.lastPathComponent)
        }
        let data = try Data(contentsOf: node.url, options: [.mappedIfSafe])
        guard let text = String(data: data, encoding: .utf8) else {
            throw FileBrowserError.editorUnsupported(node.url.lastPathComponent)
        }
        return text
    }

    func saveEditedText(_ text: String, to node: FileNode) throws {
        guard canEdit else { throw FileBrowserError.readOnly }
        guard contains(node.url) else { throw FileBrowserError.outsideRoot }
        guard let data = text.data(using: .utf8) else {
            throw FileBrowserError.editorUnsupported(node.url.lastPathComponent)
        }
        try validateEditableData(data, for: node.url)
        var backup: URL?
        if root.accessMode == .systemManaged {
            backup = try backupSystemFile(node.url)
        }
        do {
            try atomicallyReplaceFile(at: node.url, with: data)
        } catch {
            throw FileBrowserError.backupFailed("\(error.localizedDescription)\(backup.map { " (backup: \($0.path))" } ?? "")")
        }
        operationMessage = root.accessMode == .systemManaged
            ? "保存成功。已为系统文件创建安全备份。"
            : "保存成功。"
        reload()
    }

    func createFolder(named name: String) {
        performEditableOperation(successMessage: "文件夹已创建。") {
            let destination = try destinationURL(for: name)
            try fileManager.createDirectory(at: destination, withIntermediateDirectories: false)
        }
    }

    func createEmptyFile(named name: String) {
        performEditableOperation(successMessage: "空文件已创建。") {
            let destination = try destinationURL(for: name)
            guard fileManager.createFile(atPath: destination.path, contents: Data()) else {
                throw CocoaError(.fileWriteUnknown)
            }
        }
    }

    func rename(_ node: FileNode, to name: String) {
        performEditableOperation(successMessage: "已重命名 \(node.url.lastPathComponent)。") {
            guard canRename(node) else {
                if root.accessMode == .systemManaged && node.isDirectory {
                    throw FileBrowserError.directoryMutationBlocked
                }
                throw FileBrowserError.protectedSystemItem(node.url.lastPathComponent)
            }
            let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
            guard Self.validName(trimmed) else { throw FileBrowserError.invalidName }
            let destination = node.url.deletingLastPathComponent().appendingPathComponent(trimmed)
            guard contains(destination) else { throw FileBrowserError.outsideRoot }
            if root.accessMode == .systemManaged && !node.isDirectory {
                _ = try backupSystemFile(node.url)
            }
            try fileManager.moveItem(at: node.url, to: destination)
        }
    }

    func delete(_ node: FileNode) {
        performEditableOperation(successMessage: "已删除并验证 \(node.url.lastPathComponent)。") {
            guard canEdit else { throw FileBrowserError.readOnly }
            guard contains(node.url) else { throw FileBrowserError.outsideRoot }
            if root.accessMode == .systemManaged && node.isDirectory {
                throw FileBrowserError.directoryMutationBlocked
            }
            var backup: URL?
            if root.accessMode == .systemManaged && !node.isDirectory {
                backup = try backupSystemFile(node.url)
            }
            try fileManager.removeItem(at: node.url)
            guard !fileManager.fileExists(atPath: node.url.path) else {
                throw FileBrowserError.deletionVerificationFailed(node.url.path)
            }
            if let backup {
                operationMessage = "已删除并验证 \(node.url.lastPathComponent)。安全备份：\(backup.path)"
            }
        }
    }

    func overwriteWithEmptyDict(_ node: FileNode) {
        performEditableOperation(successMessage: "已使用空内容覆盖 \(node.url.lastPathComponent)（用于防止守护进程自动恢复）。") {
            guard canEdit, !node.isDirectory else { throw FileBrowserError.readOnly }
            guard contains(node.url) else { throw FileBrowserError.outsideRoot }
            if root.accessMode == .systemManaged {
                _ = try backupSystemFile(node.url)
            }
            let emptyPlist = """
            <?xml version="1.0" encoding="UTF-8"?>
            <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
            <plist version="1.0">
            <dict/>
            </plist>
            """
            try atomicallyReplaceFile(at: node.url, with: Data(emptyPlist.utf8))
        }
    }

    func destinationURL(for name: String) throws -> URL {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard Self.validName(trimmed) else { throw FileBrowserError.invalidName }
        let destination = currentURL.appendingPathComponent(trimmed).standardizedFileURL
        guard contains(destination) else { throw FileBrowserError.outsideRoot }
        return destination
    }

    func grantSystemAccess(to url: URL, requireFreshExtension: Bool) throws {
        guard root.accessMode == .systemManaged else { return }
        guard let target = systemTarget(containing: url) else { throw FileBrowserError.outsideRoot }
        let targetPath = logicalPath(target.url)

        if !requireFreshExtension,
           root.grantedTargetPaths.contains(targetPath),
           directoryIsReadable(target.url) {
            return
        }

        if !requireFreshExtension && directoryIsReadable(target.url) {
            root.grantedTargetPaths.insert(targetPath)
            accessNote = "已使用当前进程的现有沙盒扩展，验证对 \(targetPath) 的真实访问。"
            return
        }

        var path = Array(target.queryPath.utf8CString)
        let handle = path.withUnsafeMutableBufferPointer {
            bad_query($0.baseAddress, false, nil, false)
        }
        guard handle >= 0 else { throw FileBrowserError.exploitFailed(handle) }
        root.sandboxHandles.append(handle)
        guard directoryIsReadable(target.url) else {
            throw FileBrowserError.grantDidNotOpenPath(targetPath)
        }
        root.grantedTargetPaths.insert(targetPath)
        accessNote = "bad_query 已授予并验证对 \(targetPath) 的真实访问。"
    }

    func performEditableOperation(successMessage: String, _ operation: () throws -> Void) {
        errorMessage = nil
        operationMessage = nil
        do {
            guard canEdit else { throw FileBrowserError.readOnly }
            try operation()
            if operationMessage == nil { operationMessage = successMessage }
            reload()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func verifyWriteOperations(in directory: URL) throws {
        guard contains(directory) else { throw FileBrowserError.outsideRoot }
        let suffix = UUID().uuidString
        let first = directory.appendingPathComponent(".mond-write-probe-\(suffix)")
        let renamed = directory.appendingPathComponent(".mond-write-probe-renamed-\(suffix)")
        let replacement = directory.appendingPathComponent(".mond-atomic-replace-probe-\(suffix)")
        defer {
            try? fileManager.removeItem(at: first)
            try? fileManager.removeItem(at: renamed)
            try? fileManager.removeItem(at: replacement)
        }
        do {
            try Data("mond-write-probe".utf8).write(to: first, options: [.withoutOverwriting])
            try fileManager.moveItem(at: first, to: renamed)
            try Data("mond-atomic-replace-probe".utf8).write(to: replacement, options: [.withoutOverwriting])
            _ = try fileManager.replaceItemAt(renamed, withItemAt: replacement)
            try fileManager.removeItem(at: renamed)
            guard !fileManager.fileExists(atPath: first.path),
                  !fileManager.fileExists(atPath: renamed.path),
                  !fileManager.fileExists(atPath: replacement.path) else {
                throw FileBrowserError.writeProbeFailed(directory.path)
            }
        } catch {
            throw FileBrowserError.writeProbeFailed("\(directory.path): \(error.localizedDescription)")
        }
    }

    func backupSystemFile(_ source: URL) throws -> URL {
        guard fileManager.fileExists(atPath: source.path) else {
            throw FileBrowserError.backupFailed("源文件不存在")
        }
        let documents = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let backupDirectory = documents.appendingPathComponent("SystemFileBackups", isDirectory: true)
        do {
            try fileManager.createDirectory(at: backupDirectory, withIntermediateDirectories: true)
            let timestamp = ISO8601DateFormatter().string(from: Date()).replacingOccurrences(of: ":", with: "-")
            let destination = backupDirectory.appendingPathComponent("\(source.lastPathComponent).\(timestamp).\(UUID().uuidString).bak")
            try fileManager.copyItem(at: source, to: destination)
            let original = try Data(contentsOf: source, options: [.mappedIfSafe])
            let copied = try Data(contentsOf: destination, options: [.mappedIfSafe])
            guard original == copied else {
                try? fileManager.removeItem(at: destination)
                throw FileBrowserError.backupFailed("备份验证失败")
            }
            return destination
        } catch let error as FileBrowserError {
            throw error
        } catch {
            throw FileBrowserError.backupFailed(error.localizedDescription)
        }
    }

    func atomicallyReplaceFile(at target: URL, with data: Data) throws {
        guard contains(target) else { throw FileBrowserError.outsideRoot }
        let temporary = target.deletingLastPathComponent()
            .appendingPathComponent(".\(target.lastPathComponent).\(UUID().uuidString).tmp")
        try data.write(to: temporary, options: [.withoutOverwriting])
        defer { try? fileManager.removeItem(at: temporary) }
        if fileManager.fileExists(atPath: target.path) {
            _ = try fileManager.replaceItemAt(target, withItemAt: temporary)
        } else {
            try fileManager.moveItem(at: temporary, to: target)
        }
    }

    func systemTarget(containing url: URL) -> SystemTarget? {
        let path = logicalPath(url)
        return root.supportedSystemTargets
            .sorted { $0.url.path.count > $1.url.path.count }
            .first { target in
                let targetPath = logicalPath(target.url)
                return path == targetPath || path.hasPrefix(targetPath + "/")
            }
    }

    func contains(_ url: URL) -> Bool {
        let candidate = logicalPath(url)
        if isSystemIndex {
            return candidate == "/private/var" || systemTarget(containing: url) != nil
        }
        let rootPath = logicalPath(root.root)
        return candidate == rootPath || candidate.hasPrefix(rootPath + "/")
    }

    private func directoryIsReadable(_ url: URL) -> Bool {
        (try? fileManager.contentsOfDirectory(atPath: url.path)) != nil
    }

    private func isCriticalSystemFile(_ url: URL) -> Bool {
        logicalPath(url) == logicalPath(URL(fileURLWithPath: TweakPaths.gestalt))
    }

    private func validateEditableData(_ data: Data, for url: URL) throws {
        switch url.pathExtension.lowercased() {
        case "json":
            _ = try JSONSerialization.jsonObject(with: data)
        case "plist":
            _ = try PropertyListSerialization.propertyList(from: data, options: [], format: nil)
        default:
            break
        }
    }

    private static func validName(_ name: String) -> Bool {
        !name.isEmpty && name != "." && name != ".." && !name.contains("/") && !name.contains("\0")
    }

    static let editableExtensions: Set<String> = [
        "txt", "text", "md", "log", "json", "xml", "plist", "strings", "conf", "ini", "yaml", "yml"
    ]
}

private enum CreationKind: String, Identifiable {
    case folder
    case file

    var id: String { rawValue }
    var title: String { self == .folder ? "新建文件夹" : "新建空文件" }
}

struct FileBrowserView: View {
    @StateObject private var model: FileBrowserModel
    @State private var creationKind: CreationKind?
    @State private var pendingName = ""
    @State private var renameNode: FileNode?
    @State private var deleteNode: FileNode?
    @State private var criticalDeleteNode: FileNode?
    @State private var criticalDeleteConfirmation = ""
    @State private var showUnlockConfirmation = false

    init(root: BrowserRoot) {
        _model = StateObject(wrappedValue: FileBrowserModel(root: root))
    }

    private var statusIcon: String {
        if model.isSystemIndex { return "lock.shield" }
        if model.canEdit { return "checkmark.shield" }
        if model.canUnlockSystemEditing { return "checkmark.circle" }
        return "folder"
    }

    private var statusText: String {
        if model.isSystemIndex {
            return "不会全局授予 /private/var 权限。请选择精确目标。只有可逆文件操作验证成功后才会解锁写入；编辑、重命名或删除系统文件前会自动备份。"
        }
        if model.canEdit && model.unlockedWriteTarget != nil {
            return "已验证真实读写权限。系统文件编辑和删除会创建安全备份；关键删除需要键入确认词。"
        }
        if model.canUnlockSystemEditing {
            return "已验证真实读取权限。点击锁定图标测试可逆写入操作，并明确启用更改。"
        }
        return "可编辑的 App 容器。长按一行可重命名或删除。"
    }

    var body: some View {
        List {
            Section {
                HStack(alignment: .top, spacing: 12) {
                    Image(systemName: statusIcon)
                        .foregroundStyle(model.canEdit ? .green : .secondary)
                    Text(statusText)
                        .font(.footnote)
                }
            }

            if let accessNote = model.accessNote {
                Section("访问验证") {
                    Text(accessNote).font(.footnote).textSelection(.enabled)
                }
            }

            if let error = model.errorMessage {
                Section("错误") {
                    Text(error).foregroundStyle(.red).textSelection(.enabled)
                }
            }

            if let message = model.operationMessage {
                Section("操作结果") {
                    Text(message).foregroundStyle(.secondary).textSelection(.enabled)
                }
            }

            Section(model.currentURL.path) {
                if model.isLoading {
                    HStack { Spacer(); ProgressView(); Spacer() }
                } else if model.nodes.isEmpty {
                    ContentUnavailableView("没有文件", systemImage: "folder", description: Text("此目录为空或当前无法访问。"))
                } else {
                    ForEach(model.nodes) { node in
                        nodeDestination(for: node)
                            .contextMenu { editableMenu(for: node) }
                    }
                    .onDelete { offsets in
                        guard let index = offsets.first, model.nodes.indices.contains(index) else { return }
                        requestDelete(model.nodes[index])
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(InternalTheme.background.ignoresSafeArea())
        .navigationTitle(model.rootTitle)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                if model.canGoUp {
                    Button { model.goUp() } label: { Image(systemName: "arrow.up") }
                        .accessibilityLabel("返回上一层")
                }
                Button { model.reload() } label: { Image(systemName: "arrow.clockwise") }
                    .accessibilityLabel("刷新")
                if model.canUnlockSystemEditing {
                    Button { showUnlockConfirmation = true } label: { Image(systemName: "lock") }
                        .accessibilityLabel("验证写入权限")
                }
                if model.canEdit {
                    Menu {
                        Button { beginCreation(.folder) } label: { Label("新建文件夹", systemImage: "folder.badge.plus") }
                        Button { beginCreation(.file) } label: { Label("新建空文件", systemImage: "doc.badge.plus") }
                    } label: {
                        Image(systemName: "plus")
                    }
                }
            }
        }
        .onAppear { model.reload() }
        .alert(creationKind?.title ?? "新建", isPresented: creationAlertPresented) {
            TextField("名称", text: $pendingName)
            Button("取消", role: .cancel) { creationKind = nil }
            Button("创建") {
                if creationKind == .folder { model.createFolder(named: pendingName) }
                if creationKind == .file { model.createEmptyFile(named: pendingName) }
                creationKind = nil
            }
        }
        .alert("重命名", isPresented: renameAlertPresented) {
            TextField("名称", text: $pendingName)
            Button("取消", role: .cancel) { renameNode = nil }
            Button("重命名") {
                if let node = renameNode { model.rename(node, to: pendingName) }
                renameNode = nil
            }
        }
        .alert("确定删除？", isPresented: deleteAlertPresented) {
            Button("取消", role: .cancel) { deleteNode = nil }
            Button("删除", role: .destructive) {
                if let node = deleteNode { model.delete(node) }
                deleteNode = nil
            }
        } message: {
            Text(model.unlockedWriteTarget == nil ? "此操作无法撤销。" : "删除前会先将普通文件复制到 Documents/SystemFileBackups。")
        }
        .alert("删除关键系统文件？", isPresented: criticalDeleteAlertPresented) {
            TextField("输入 DELETE", text: $criticalDeleteConfirmation)
            Button("取消", role: .cancel) {
                criticalDeleteNode = nil
                criticalDeleteConfirmation = ""
            }
            Button("备份并删除", role: .destructive) {
                if criticalDeleteConfirmation == "DELETE", let node = criticalDeleteNode { model.delete(node) }
                criticalDeleteNode = nil
                criticalDeleteConfirmation = ""
            }
            .disabled(criticalDeleteConfirmation != "DELETE")
        } message: {
            Text("删除 com.apple.MobileGestalt.plist 可能导致 iOS 不稳定或无法启动。弦光会先将其复制到 Documents/SystemFileBackups，然后删除并重新读取目录以验证结果。输入 DELETE 以继续。")
        }
        .alert("启用系统写入？", isPresented: $showUnlockConfirmation) {
            Button("取消", role: .cancel) {}
            Button("验证并启用") { model.unlockSystemEditing() }
        } message: {
            Text("弦光会创建临时探测文件，在不更改现有文件的前提下验证创建、重命名、原子替换和删除操作。编辑、重命名或删除系统文件前会先备份。系统目录不能重命名或删除；删除 MobileGestalt.plist 需要额外键入确认。")
        }
    }

    @ViewBuilder
    private func nodeDestination(for node: FileNode) -> some View {
        if model.isSystemIndex, let target = model.systemTarget(containing: node.url) {
            NavigationLink {
                FileBrowserView(root: .preciseSystemTarget(target))
            } label: {
                FileNodeRow(node: node, subtitle: target.subtitle, iconOverride: target.icon)
            }
        } else if node.isDirectory {
            Button { model.open(node) } label: {
                FileNodeRow(node: node)
            }
            .buttonStyle(.plain)
        } else {
            NavigationLink {
                FilePreviewView(node: node, allowSharing: true, showFullPath: true, model: model)
            } label: {
                FileNodeRow(node: node)
            }
        }
    }

    @ViewBuilder
    private func editableMenu(for node: FileNode) -> some View {
        if !node.isDirectory {
            ShareLink(item: node.url) { Label("共享", systemImage: "square.and.arrow.up") }
        }
        if model.canRename(node) {
            Button {
                pendingName = node.url.lastPathComponent
                renameNode = node
            } label: {
                Label("重命名", systemImage: "pencil")
            }
        }
        if model.canEdit && !node.isDirectory && ["plist", "json"].contains(node.url.pathExtension.lowercased()) {
            Button {
                model.overwriteWithEmptyDict(node)
            } label: {
                Label("用空内容（{}）覆盖", systemImage: "doc.badge.minus")
            }
        }
        if model.canEdit {
            Button(role: .destructive) { requestDelete(node) } label: {
                Label("删除", systemImage: "trash")
            }
        }
    }

    private func beginCreation(_ kind: CreationKind) {
        pendingName = ""
        creationKind = kind
    }

    private func requestDelete(_ node: FileNode) {
        if logicalPath(node.url) == logicalPath(URL(fileURLWithPath: TweakPaths.gestalt)) {
            criticalDeleteConfirmation = ""
            criticalDeleteNode = node
        } else {
            deleteNode = node
        }
    }

    private var creationAlertPresented: Binding<Bool> {
        Binding(get: { creationKind != nil }, set: { if !$0 { creationKind = nil } })
    }

    private var renameAlertPresented: Binding<Bool> {
        Binding(get: { renameNode != nil }, set: { if !$0 { renameNode = nil } })
    }

    private var deleteAlertPresented: Binding<Bool> {
        Binding(get: { deleteNode != nil }, set: { if !$0 { deleteNode = nil } })
    }

    private var criticalDeleteAlertPresented: Binding<Bool> {
        Binding(get: { criticalDeleteNode != nil }, set: { if !$0 { criticalDeleteNode = nil } })
    }
}

struct FileBrowserHomeView: View {
    private var roots: [BrowserRoot] {
        [.documents, .applicationSupport, .caches, .systemIndex]
    }

    var body: some View {
        List {
            Section {
                ForEach(roots, id: \.root.path) { root in
                    NavigationLink {
                        FileBrowserView(root: root)
                    } label: {
                        Label {
                            VStack(alignment: .leading, spacing: 3) {
                                Text(root.title)
                                Text(root.subtitle).font(.caption).foregroundStyle(.secondary)
                            }
                        } icon: {
                            Image(systemName: root.icon).frame(width: 28, height: 28)
                        }
                    }
                }
            } footer: {
                Text("浏览弦光容器，或验证 /private/var 下的精确路径。受管写入需要针对每个目标单独确认。")
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(InternalTheme.background.ignoresSafeArea())
        .navigationTitle("文件浏览器")
    }
}

private struct FileNodeRow: View {
    let node: FileNode
    var subtitle: String? = nil
    var iconOverride: String? = nil

    private var iconName: String {
        if let iconOverride { return iconOverride }
        if node.isDirectory { return "folder" }
        switch node.url.pathExtension.lowercased() {
        case "plist", "json", "xml": return "list.bullet.rectangle"
        case "png", "jpg", "jpeg", "heic", "gif": return "photo"
        case "zip", "ipa": return "archivebox"
        default: return "doc"
        }
    }

    var body: some View {
        Label {
            VStack(alignment: .leading, spacing: 2) {
                Text(node.url.lastPathComponent)
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                if let subtitle {
                    Text(subtitle).font(.caption).foregroundStyle(.secondary).lineLimit(2)
                } else if !node.isDirectory {
                    Text(ByteCountFormatter.string(fromByteCount: node.size, countStyle: .file))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        } icon: {
            Image(systemName: iconName).foregroundStyle(node.isDirectory ? .blue : .secondary)
        }
    }
}

struct FilePreviewView: View {
    let node: FileNode
    let allowSharing: Bool
    let showFullPath: Bool
    @ObservedObject var model: FileBrowserModel

    var body: some View {
        List {
            Section {
                QuickLookPreview(url: node.url)
                    .frame(minHeight: 360)
            }

            if showFullPath {
                Section("路径") {
                    Text(node.url.path).font(.caption.monospaced()).textSelection(.enabled)
                }
            }

            Section("详细信息") {
                LabeledContent("大小", value: ByteCountFormatter.string(fromByteCount: node.size, countStyle: .file))
                if let modified = node.modified {
                    LabeledContent("修改时间", value: modified.formatted(date: .abbreviated, time: .standard))
                }
            }

            if FileBrowserModel.editableExtensions.contains(node.url.pathExtension.lowercased()) {
                NavigationLink {
                    TextFileEditorView(node: node, model: model)
                } label: {
                    Label("编辑文本", systemImage: "square.and.pencil")
                }
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(InternalTheme.background.ignoresSafeArea())
        .navigationTitle(node.url.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            if allowSharing {
                ToolbarItem(placement: .topBarTrailing) {
                    ShareLink(item: node.url) { Image(systemName: "square.and.arrow.up") }
                }
            }
        }
    }
}

private struct QuickLookPreview: UIViewControllerRepresentable {
    let url: URL

    func makeCoordinator() -> Coordinator { Coordinator(url: url) }

    func makeUIViewController(context: Context) -> QLPreviewController {
        let controller = QLPreviewController()
        controller.dataSource = context.coordinator
        return controller
    }

    func updateUIViewController(_ uiViewController: QLPreviewController, context: Context) {
        context.coordinator.url = url
        uiViewController.reloadData()
    }

    final class Coordinator: NSObject, QLPreviewControllerDataSource {
        var url: URL

        init(url: URL) { self.url = url }

        func numberOfPreviewItems(in controller: QLPreviewController) -> Int { 1 }

        func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
            url as NSURL
        }
    }
}

private struct TextFileEditorView: View {
    let node: FileNode
    @ObservedObject var model: FileBrowserModel
    @State private var text = ""
    @State private var loadError: String?
    @State private var isLoaded = false
    @State private var showSaveConfirmation = false
    @State private var saveResult: String?

    var body: some View {
        Group {
            if let loadError {
                ContentUnavailableView("无法编辑", systemImage: "exclamationmark.triangle", description: Text(loadError))
            } else if isLoaded {
                TextEditor(text: $text)
                    .font(.system(.body, design: .monospaced))
                    .autocorrectionDisabled()
                    .padding(8)
            } else {
                ProgressView()
            }
        }
        .navigationTitle(node.url.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("保存") { showSaveConfirmation = true }
                    .disabled(!isLoaded || !model.canEdit)
            }
        }
        .onAppear {
            guard !isLoaded else { return }
            do {
                text = try model.editableText(for: node)
                isLoaded = true
            } catch {
                loadError = error.localizedDescription
            }
        }
        .alert("保存更改？", isPresented: $showSaveConfirmation) {
            Button("取消", role: .cancel) {}
            Button("保存") { save() }
        } message: {
            Text(model.unlockedWriteTarget == nil
                 ? "在适用时会先验证文件，然后进行原子替换。"
                 : "当前文件会先备份到 Documents/SystemFileBackups，通过验证后再进行原子替换。无效的 plist 或 JSON 内容会被拒绝。")
        }
        .alert("保存结果", isPresented: Binding(get: { saveResult != nil }, set: { if !$0 { saveResult = nil } })) {
            Button("好") { saveResult = nil }
        } message: {
            Text(saveResult ?? "")
        }
    }

    private func save() {
        do {
            try model.saveEditedText(text, to: node)
            saveResult = model.unlockedWriteTarget == nil
                ? "保存成功。"
                : "保存成功。已为系统文件创建安全备份。"
        } catch {
            saveResult = error.localizedDescription
        }
    }
}
