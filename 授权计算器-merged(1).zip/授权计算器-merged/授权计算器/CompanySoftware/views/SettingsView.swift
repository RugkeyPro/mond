//
//  SettingsView.swift
//  mond
//
//  Created by ruter on 18.07.26.
//

import SwiftUI
import PartyUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var state: AppState
    
    @AppStorage("token") private var token: String = ""
    @AppStorage("method") private var method: String = "bad_query"
    @State private var show_confirm: Bool = false
    
    var valid: Bool {
        (sandbox_extension_consume(token) ?? -1) >= 0
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "—"
    }

    private var buildNumber: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "—"
    }
    
    var body: some View {
        NavigationStack {
            List {
                Section {
                    HStack {
                        if let icons = Bundle.main.infoDictionary?["CFBundleIcons"] as? [String: Any],
                           let primary = icons["CFBundlePrimaryIcon"] as? [String: Any],
                           let files = primary["CFBundleIconFiles"] as? [String],
                           let icon = files.last,
                           let img = UIImage(named: icon) {
                            Image(uiImage: img)
                                .resizable()
                                .frame(width: 45, height: 45)
                                .cornerRadius(12)
                        }
                        
                        VStack(alignment: .leading) {
                            Text("弦光")
                                .font(.title3.bold())
                            
                            Text("技术支持 · 邹北绮")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                        
                        Spacer()
                    }
                }
                
                Section {
                    LogView()
                        .modifier(TerminalPlatter())
                } header: {
                    Label("运行日志", systemImage: "apple.terminal")
                }
                
                Section {
                    HStack {
                        TextField("沙盒扩展令牌", text: $token)
                        
                        Spacer()
                        
                        Button {
                            UIPasteboard.general.string = token
                        } label: {
                            Image(systemName: "document.on.document")
                        }
                    }
                    .contextMenu {
                        Text("类别：\(token.split(separator: ";").first { $0.contains("com.apple") }.map(String.init) ?? "无")")
                        Text("路径：\(token.split(separator: ";").last.map(String.init) ?? "无")")
                        
                        Button {
                            UIPasteboard.general.string = token
                        } label: {
                            Label("复制令牌", systemImage: "doc.on.doc")
                        }
                    }
                    .lineLimit(1)
                    
                    Button {
                        token = sandbox_extension_issue_file(path: TweakPaths.gestalt_dir) ?? "令牌生成失败"
                    } label: {
                        Text("生成令牌")
                    }
                    .disabled(!state.exploit_succeeded)
                } header: {
                    Label("访问令牌", systemImage: "key")
                } footer: {
                    if !token.isEmpty && token != "令牌生成失败" {
                        if valid {
                            Text("当前沙盒令牌有效。")
                        } else {
                            Text("当前沙盒令牌无效。")
                        }
                    }
                    
                    if !state.exploit_succeeded {
                        Text("因访问授予失败而停用。请确认当前 iOS 版本受支持。")
                    }
                }
                
                Section {
                    Picker("方法", selection: $method) {
                        Text("bad_query").tag("bad_query")
                        Text("cmg").tag("cmg")
                    }
                    .pickerStyle(.segmented)
                    
                    Button {
                        _ = grant_mg_write()
                    } label: {
                        Text("执行访问授予")
                    }
                } header: {
                    Label("访问授予", systemImage: "wrench.and.screwdriver")
                } footer: {
                    Text(method == "cmg" ? "**CMG：** 支持 iOS 27.0 beta 1 至 beta 4，建议优先使用 bad_query。" : "**bad_query：** 支持 iOS 27.0 beta 1 至 beta 4，由 [forcequit](https://github.com/forcequitOS) 提供。")
                }
                
                Section {
                    Button {
                        show_confirm = true
                    } label: {
                        Text("重载系统界面")
                    }
                } header: {
                    Label("工具", systemImage: "wrench.and.screwdriver")
                }

                Section {
                    LabeledContent("版本号", value: appVersion)
                    LabeledContent("构建版本", value: buildNumber)
                } header: {
                    Label("关于", systemImage: "info.circle")
                }
            }
            .listStyle(.insetGrouped)
            .scrollContentBackground(.hidden)
            .background(InternalTheme.background.ignoresSafeArea())
            .navigationTitle("弦光设置")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    HStack {
                        Button {
                            dismiss()
                        } label: {
                            Text("完成")
                        }
                    }
                }
            }
            .alert("确认重载系统界面？", isPresented: $show_confirm) {
                Button("取消") {
                    show_confirm = false
                }
                
                Button("确认") {
                    state.respring()
                }
            } message: {
                Text("系统界面将立即重载，请先保存正在进行的工作。")
            }
        }
    }
}
