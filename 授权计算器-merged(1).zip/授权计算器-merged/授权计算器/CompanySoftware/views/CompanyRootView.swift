//
//  ContentView.swift
//  mond
//
//  Created by ruter on 16.07.26.
//

import SwiftUI
import PartyUI

struct CompanyRootView: View {
    @EnvironmentObject var state: AppState
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    var onBack: (() -> Void)? = nil
    @AppStorage("mg_devicename") private var mg_devicename: String = ""
    @AppStorage("token") private var token: String = ""
    
    @State private var mg_dict_now: NSMutableDictionary = NSMutableDictionary()
    @State private var is_valid: Bool = false
    
    @State private var og_st: Int = 0
    @State private var selected_st: String = ""
    
    @State private var enable_devicename: Bool = false
    @State private var og_devicename: String = ""
    @State private var product_type: String = ""
    
    @State private var show_settings: Bool = false
    
    private var mg_valid: Bool {
        guard let data = try? Data(contentsOf: URL(fileURLWithPath: TweakPaths.gestalt)) else { return false }
        return (try? PropertyListSerialization.propertyList(from: data, options: [], format: nil)) != nil
    }
    
    private var mg_empty: Bool {
        guard let attributes = try? FileManager.default.attributesOfItem(atPath: TweakPaths.gestalt),
              let size = attributes[.size] as? UInt64 else { return false }

        return size == 0
    }
    
    var valid: Bool {
        (sandbox_extension_consume(token) ?? -1) >= 0
    }

    var selected_st_value: Int {
        switch selected_st {
            case "og":
                return og_st
            case "no_dynamic_island":
                return 0
            case "14p":
                return 2436
            case "14pm":
                return 2796
            case "15pm":
                return 2976
            case "16p":
                return 2622
            case "16pm":
                return 2868
            case "air":
                return 2736
            case "x":
                return 2436
            default:
                return 0
        }
    }

    private var st_to_sel: [Int: String] {
        [
            0: "no_dynamic_island",
            2436: "14p",
            2796: "14pm",
            2976: "15pm",
            2622: "16p",
            2868: "16pm",
            2736: "air"
        ]
    }
    
    var body: some View {
        NavigationStack {
            List {
                Section {
                    InternalBrandHeader(
                        isReady: state.exploit_succeeded,
                        versionText: "iOS \(UIDevice.current.systemVersion)"
                    )
                    .listRowInsets(EdgeInsets())
                    .listRowBackground(Color.clear)
                }

                Section {
                    NavigationLink {
                        FileBrowserHomeView()
                    } label: {
                        Label("文件浏览器", systemImage: "folder")
                    }
                } header: {
                    Label("文件", systemImage: "internaldrive")
                } footer: {
                    Text("浏览弦光容器，或对 /private/var 下的精确路径进行验证。受管写入需要针对每个目标单独确认。")
                }

                Section {
                    NavigationLink {
                        FileBrowserView(root: .mdmProfiles)
                    } label: {
                        Label("MDM 配置文件", systemImage: "shield.lefthalf.filled")
                    }

                    Button {
                        mdm_neuter()
                    } label: {
                        Label("绕过 MDM（使用空字典覆盖配置）", systemImage: "shield.lefthalf.filled")
                    }
                    .foregroundStyle(.red)
                } header: {
                    Label("MDM 管理", systemImage: "lock.shield")
                } footer: {
                    Text("“绕过 MDM”会用空内容覆盖配置文件，避免删除后守护进程自动恢复。更改前会创建安全备份，完成后需重启。")
                }

                if !mg_valid || mg_empty {
                    Section {
                        if mg_empty {
                            PlainAlert(title: "请勿重启！", icon: "exclamationmark.triangle.fill", text: "MobileGestalt.plist 似乎为空。", color: Color.yellow)
                        }
                        
                        if !mg_valid {
                            PlainAlert(title: "请勿重启！", icon: "exclamationmark.triangle.fill", text: "MobileGestalt.plist 似乎无效。", color: Color.yellow)
                        }
                    } header: {
                        Label("警告", systemImage: "exclamationmark.triangle")
                    } footer: {
                        Text("此时重启可能导致循环启动。请先点击“恢复更改”；如果警告仍然存在，请立即停止操作。")
                    }
                }
                
                Section {
                    HStack(spacing: 12) {
                        InternalActionButton(
                            title: "应用更改",
                            symbol: "checkmark.circle.fill",
                            color: .cyan,
                            action: mg_apply
                        )
                        InternalActionButton(
                            title: "恢复更改",
                            symbol: "arrow.uturn.backward.circle.fill",
                            color: .orange,
                            action: mg_revert
                        )
                    }
                } footer: {
                    Text("**警告：** 不当使用这些更改可能破坏设备功能，甚至导致无法正常启动。")
                }
                
                Section {
                    Picker(selection: $selected_st) {
                        Text("原始值（\(og_st)）").tag("og")
                        
                        if is_device_good() {
                            Text("关闭灵动岛").tag("no_dynamic_island")
                        }
                    
                        Text("iPhone 14 Pro").tag("14p")
                        Text("iPhone 14 Pro Max").tag("14pm")
                        Text("iPhone 15 Pro Max").tag("15pm")
                    
                        if doubleSystemVersion() >= 18.0 {
                            Text("iPhone 16 Pro").tag("16p")
                            Text("iPhone 16 Pro Max").tag("16pm")
                        }
                    
                        if doubleSystemVersion() >= 26.0 {
                            Text("iPhone Air").tag("air")
                        }
                    
                        if hasHomeButton() {
                            Text("iPhone X 手势").tag("x")
                        }
                    } label: {
                        HStack {
                            Text("外观子类型")
                            Spacer()
                        }
                    }
                    
                    Toggle("自定义设备名称", isOn: $enable_devicename)
                    
                    if enable_devicename {
                        TextField("设备名称", text: $mg_devicename)
                    }
                } header: {
                    Label("设备外观", systemImage: "paintbrush.pointed")
                }
                
                // basic tweak toggles
                Section {
                    PlainToggle(text: "灵动岛", minSupportedVersion: 19.0, isOn: mg_key_binding(["YlEtTtHlNesRBMal1CqRaA"]))
                    PlainToggle(text: "息屏显示", minSupportedVersion: 18.0, isOn: mg_key_binding(["j8/Omm6s1lsmTDFsXjsBfA", "2OOJf1VhaM7NxfRok3HbWQ"]))
                    PlainToggle(text: "息屏显示鲜艳效果", minSupportedVersion: 18.0, isOn: mg_key_binding(["ykpu7qyhqFweVMKtxNylWA"]))
                    PlainToggle(text: "充电上限", minSupportedVersion: 17.0, isOn: mg_key_binding(["37NVydb//GP/GrhuTN+exg"]))
                    PlainToggle(text: "开机音效", isOn: mg_key_binding(["QHxt+hGLaBPbQJbXiUJX3w"]))
                    PlainToggle(text: "液态玻璃低电量模式", minSupportedVersion: 19.0, isOn: mg_key_binding(["SAGvsp6O6kAQ4fEfDJpC4Q"]))
                } header: {
                    Label("软件功能", systemImage: "gearshape")
                }
                
                Section {
                    PlainToggle(text: "相机控制", minSupportedVersion: 18.0, isOn: mg_key_binding(["CwvKxM2cEogD3p+HYgaW0Q", "oOV1jhJbdV3AddkcCg0AEA"]))
                    PlainToggle(text: "操作按钮", minSupportedVersion: 17.0, isOn: mg_key_binding(["cT44WE1EohiwRzhsZ8xEsw"]))
                    PlainToggle(text: "车祸检测", isOn: mg_key_binding(["HCzWusHQwZDea6nNhaKndw"]))
                    if hasHomeButton() {
                        PlainToggle(text: "启用轻点唤醒", isOn: mg_key_binding(["yZf3GTRMGTuwSV/lD7Cagw"]))
                    }
                    PlainToggle(text: "脉冲宽度调制", minSupportedVersion: 19.0, isOn: mg_key_binding(["6IejgN+1Fmu5/QrZFOIeNw"]))
                } header: {
                    Label("硬件功能", systemImage: "iphone")
                }
                
                Section {
                    PlainToggle(text: "安全研究设备界面", minSupportedVersion: 26.0, isOn: mg_key_binding(["XYlJKKkj2hztRP1NWWnhlw"]))
                    
                    PlainToggle(
                        text: "关闭地区限制",
                        infoType: .info,
                        infoMessage: "此功能在部分 iOS 版本或设备上可能失效或不产生作用。",
                        isOn: mg_region_restrict_binding()
                    )
                    
                    PlainToggle(
                        text: "Apple Intelligence",
                        infoType: .info,
                        infoMessage: "使用方法：\n1. 先伪装为首款支持 Apple Intelligence 的相邻型号。\n2. 切回本机型号。\n3. 再切换到最终目标型号，“设置”中应出现 Apple Intelligence 图标。\n4. 将 iPhone 接入电源，并保持“设置 > 通用 > iPhone 储存空间”打开约 1 小时。\n\n注意：不要再切回。",
                        minSupportedVersion: 18.1,
                        isOn: mg_key_binding(["A62OafQ85EJAiiqKn4agtg"])
                    )
                    
                    HStack(spacing: 10) {
                        Picker("机型伪装", selection: $product_type) {
                            Text("默认").tag(machine_name())
                            if UIDevice.current.userInterfaceIdiom == .pad {
                                if doubleSystemVersion() >= 17.4 {
                                    Text("iPad Pro 11-inch (M4)").tag("iPad16,3")
                                    Text("iPad Pro 11-inch (M4, Cellular)").tag("iPad16,4")
                                }
                                Text("iPad Pro 11-inch (4th Gen)").tag("iPad14,3")
                                Text("iPad Pro 11-inch (4th Gen, Cellular)").tag("iPad14,4")
                            } else {
                                Text("iPhone 15 Pro").tag("iPhone16,1")
                                Text("iPhone 15 Pro Max").tag("iPhone16,2")
                                if doubleSystemVersion() >= 18.0 {
                                    Text("iPhone 16").tag("iPhone17,3")
                                    Text("iPhone 16 Plus").tag("iPhone17,4")
                                    Text("iPhone 16 Pro").tag("iPhone17,1")
                                    Text("iPhone 16 Pro Max").tag("iPhone17,2")
                                }
                                if doubleSystemVersion() >= 19.0 {
                                    Text("iPhone 17").tag("iPhone18,3")
                                    Text("iPhone 17 Pro").tag("iPhone18,1")
                                    Text("iPhone 17 Pro Max").tag("iPhone18,2")
                                    Text("iPhone Air").tag("iPhone18,4")
                                }
                            }
                        }
                        
                        Button {
                            Alertinator.shared.alert(
                                title: "设备机型伪装说明",
                                body: "只有在需要下载 Apple Intelligence 时才建议伪装设备型号。这可能导致 Face ID 异常。如果恢复原型号后想保留 Apple Intelligence，请勿再进入“设置”中的“Apple Intelligence 与 Siri”页面。"
                            )
                        } label: {
                            Image(systemName: "info.circle")
                                .frame(width: 24, height: 22)
                        }
                        .buttonStyle(.plain)
                    }
                } header: {
                    Label("资格与机型", systemImage: "checklist")
                }
                
                Section {
                    let cache_extra = mg_dict_now["CacheExtra"] as? NSMutableDictionary
                    
                    PlainToggle(text: "允许安装 iPadOS App", isOn: mg_key_binding(["9MZ5AdH43csAUajl/dU+IQ"], type: [Int].self, default_val: [1], on_val: [1, 2]))
                    PlainToggle(text: "Apple Pencil 设置", isOn: mg_key_binding(["yhHcB0iH0d1XzPO/CFd3ow"]))
                    
                    if UIDevice.current.userInterfaceIdiom == .pad {
                        PlainToggle(text: "台前调度", isOn: mg_key_binding(["qeaj75wk3HF4DwQ8qbIi7g"]))
                    }
                    PlainToggle(
                        text: "iPadOS 界面",
                        infoType: .warning,
                        infoMessage: "这是一项高风险功能。如果你使用字母数字密码，请勿启用。不要关闭“台前调度中显示程序坞”，否则横屏时可能循环启动。部分设备在启用后点击台前调度可能进入恢复模式，也可能出现系统不稳定或 App 数据丢失。",
                        isOn: mg_trollpad_binding()
                    )
                    .disabled(cache_extra?["+3Uf0Pm5F8Xy7Onyvko0vA"] as? String != "iPhone")
                } header: {
                    Label("iPadOS 功能", systemImage: "ipad")
                }
                
                Section {
                    PlainToggle(text: "内部存储", isOn: mg_key_binding(["LBJfwOEzExRxzlAnSuI7eg"]))
                    PlainToggle(text: "内部功能", isOn: mg_internal_binding())
                    PlainToggle(text: "所有 App 显示 Metal HUD", isOn: mg_key_binding(["EqrsVvjcYDdxHBiQmGhAWw"]))
                } header: {
                    Label("内部选项", systemImage: "ant")
                }
            }
            .listStyle(.insetGrouped)
            .listSectionSpacing(18)
            .scrollContentBackground(.hidden)
            .background(InternalTheme.background.ignoresSafeArea())
            .navigationTitle("弦光工具")
            .tint(Color("AccentColor"))
            .onAppear {
                if !valid {
                    state.exploit_succeeded = grant_mg_write() >= 0
                } else {
                    print("(弦光) valid token saved, skipping exploit")
                    state.exploit_succeeded = true
                }
                
                mg_load()
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    if let onBack {
                        Button {
                            onBack()
                        } label: {
                            Label("返回弦光", systemImage: "chevron.left")
                        }
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    HStack {
                        Button {
                            show_settings = true
                        } label: {
                            Image(systemName: "gear")
                        }
                    }
                }
            }
            .sheet(isPresented: $show_settings) {
                SettingsView()
            }
        }
    }
    
    private enum MGViewError: Error, LocalizedError {
        case missingArtworkSubtype
        case missingArtworkDeviceName
        
        var errorDescription: String? {
            switch self {
            case .missingArtworkSubtype:
                return "无法获取 ArtworkDeviceSubType！"
            case .missingArtworkDeviceName:
                return "无法获取 ArtworkDeviceProductDescription！"
            }
        }
    }

    private func mdm_neuter() {
        var path = Array(TweakPaths.mdm_profiles_dir.utf8CString)
        let handle = path.withUnsafeMutableBufferPointer {
            bad_query($0.baseAddress, false, nil, false)
        }

        guard handle >= 0 else {
            Alertinator.shared.alert(
                title: "无法访问 MDM 配置文件！",
                body: "bad_query 未能授予 MDM 配置文件目录的访问权限。错误代码：\(handle)"
            )
            return
        }
        defer { bad_query_release(handle) }

        let profilesURL = URL(fileURLWithPath: TweakPaths.mdm_profiles, isDirectory: true)
        guard fm.fileExists(atPath: profilesURL.path) else {
            Alertinator.shared.alert(title: "无法访问 MDM 配置文件！", body: "未找到 MDM 配置文件目录。")
            return
        }

        do {
            let resourceKeys: Set<URLResourceKey> = [.isRegularFileKey]
            let files = try fm.contentsOfDirectory(
                at: profilesURL,
                includingPropertiesForKeys: Array(resourceKeys),
                options: []
            ).filter {
                (try? $0.resourceValues(forKeys: resourceKeys).isRegularFile) == true
            }

            let documents = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let backupDirectory = documents.appendingPathComponent("SystemFileBackups/MDM", isDirectory: true)
            try fm.createDirectory(at: backupDirectory, withIntermediateDirectories: true)

            var backups: [URL: URL] = [:]
            for source in files {
                let destination = backupDirectory.appendingPathComponent(
                    "\(source.lastPathComponent).\(UUID().uuidString).bak"
                )
                try fm.copyItem(at: source, to: destination)
                let original = try Data(contentsOf: source, options: [.mappedIfSafe])
                let copy = try Data(contentsOf: destination, options: [.mappedIfSafe])
                guard original == copy else {
                    throw CocoaError(.fileReadCorruptFile)
                }
                backups[source] = destination
            }

            let emptyPlist = """
            <?xml version="1.0" encoding="UTF-8"?>
            <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
            <plist version="1.0">
            <dict/>
            </plist>
            """
            let payload = Data(emptyPlist.utf8)
            var replaced: [URL] = []

            do {
                for source in files {
                    let temporary = profilesURL.appendingPathComponent(".\(source.lastPathComponent).\(UUID().uuidString).tmp")
                    try payload.write(to: temporary, options: [.withoutOverwriting])
                    defer { try? fm.removeItem(at: temporary) }
                    _ = try fm.replaceItemAt(source, withItemAt: temporary)
                    replaced.append(source)
                }
            } catch {
                for source in replaced {
                    guard let backup = backups[source], fm.fileExists(atPath: backup.path) else { continue }
                    let restore = profilesURL.appendingPathComponent(".\(source.lastPathComponent).restore.\(UUID().uuidString)")
                    try? fm.copyItem(at: backup, to: restore)
                    if fm.fileExists(atPath: restore.path) {
                        _ = try? fm.replaceItemAt(source, withItemAt: restore)
                    }
                }
                throw error
            }

            print("(mdm) overwrote \(files.count) MDM configuration files after verified backups")
            Alertinator.shared.alert(
                title: "MDM 处理成功",
                body: "已使用空内容覆盖 \(files.count) 个 MDM 配置文件。安全备份已保存至 Documents/SystemFileBackups/MDM。请重启设备以使更改生效。"
            )
        } catch {
            print("(mdm) failed to neutralize profiles: \(error)")
            Alertinator.shared.alert(
                title: "MDM 配置处理失败",
                body: error.localizedDescription
            )
        }
    }
    
    private func mg_load() {
        do {
            let mg_url_now = URL(fileURLWithPath: TweakPaths.gestalt)
            mg_dict_now = try NSMutableDictionary(contentsOf: mg_url_now, error: ())
            
            // this'll cache gestalt and put it in a safe place
            let mg_url_saved = URL(fileURLWithPath: AppPaths.backups).appendingPathComponent("SavedGestalt.plist")
            
            if !FileManager.default.fileExists(atPath: mg_url_saved.path) {
                try FileManager.default.copyItem(at: mg_url_now, to: mg_url_saved)
            }
            
            // get original gestalt values
            let mg_saved_dict = try NSMutableDictionary(contentsOf: mg_url_saved, error: ())
            let og_cache_extra = mg_saved_dict["CacheExtra"] as? NSMutableDictionary ?? NSMutableDictionary()
            let og_artwork = og_cache_extra["oPeik/9e8lQWMszEjbPzng"] as? NSMutableDictionary ?? NSMutableDictionary()
            
            guard let og_subtype = og_artwork["ArtworkDeviceSubType"] as? Int else { throw MGViewError.missingArtworkSubtype }
            og_st = og_subtype
            
            guard let og_devicename = og_artwork["ArtworkDeviceProductDescription"] as? String else { throw MGViewError.missingArtworkDeviceName }
            
            let cache_extra = mg_dict_now["CacheExtra"] as? NSMutableDictionary ?? NSMutableDictionary()
            let artwork = cache_extra["oPeik/9e8lQWMszEjbPzng"] as? NSMutableDictionary ?? NSMutableDictionary()
            
            selected_st = st_to_sel[artwork["ArtworkDeviceSubType"] as? Int ?? og_subtype] ?? "og"
            mg_devicename = artwork["ArtworkDeviceProductDescription"] as? String ?? og_devicename
            
            // assume it's been changed
            if mg_devicename != og_devicename {
                enable_devicename = true
            }
            
            if let productType = cache_extra["h9jDsbgj7xIVeIQ8S3/X3Q"] as? String, !productType.isEmpty {
                product_type = productType
            } else {
                product_type = machine_name()
            }
        } catch {
            print("(mg) failed to load data: \(error)")
            Alertinator.shared.alert(title: "无法加载当前 MobileGestalt", body: "请重启 App 后重试，并查看日志以获取详细信息。")
        }
    }
    
    private func mg_apply() {
        do {
            let cache_extra = mg_dict_now["CacheExtra"] as? NSMutableDictionary ?? NSMutableDictionary()
            if !product_type.isEmpty {
                cache_extra["h9jDsbgj7xIVeIQ8S3/X3Q"] = product_type
            }
            
            let artwork_dict = cache_extra["oPeik/9e8lQWMszEjbPzng"] as? NSMutableDictionary ?? NSMutableDictionary()
            artwork_dict["ArtworkDeviceSubType"] = selected_st_value
            
            if enable_devicename {
                artwork_dict["ArtworkDeviceProductDescription"] = mg_devicename
            }
            
            let data = try PropertyListSerialization.data(fromPropertyList: mg_dict_now, format: .xml, options: 0)

            try mg_write(data)
            mg_dict_now = NSMutableDictionary()
            enable_devicename = false

            print("(mg) successfully overwrote mobilegestalt!")
            Alertinator.shared.alert(title: "Gestalt 更改已应用", body: "请注销并重载界面以使更改生效。部分项目可能需要重启设备。", actionLabel: "重载界面", action: {
                state.respring()
            })
        } catch {
            print("(mg) failed to apply mobilegestalt: \(error)")
            Alertinator.shared.alert(title: "MobileGestalt 应用失败", body: "请重启 App 后重试，并查看日志以获取详细信息。")
        }
    }
    
    private func mg_revert() {
        do {
            let backup_url = URL(fileURLWithPath: AppPaths.backups).appendingPathComponent("SavedGestalt.plist")
            let backup_data = try Data(contentsOf: backup_url)
            try mg_write(backup_data)

            print("(mg) successfully reverted mobilegestalt!)")
            Alertinator.shared.alert(title: "Gestalt 更改已恢复", body: "请重启设备以使恢复生效。")
        } catch {
            // The direct file write path now surfaces the underlying error through the catch.
            print("(mg) failed to revert mobilegestalt: \(error)")
            Alertinator.shared.alert(title: "MobileGestalt 恢复失败", body: "请查看日志中的错误信息。")
        }
    }

    private func mg_write(_ data: Data) throws {
        let target_url = URL(fileURLWithPath: TweakPaths.gestalt)
        let temp_url = target_url.deletingLastPathComponent()
            .appendingPathComponent(".\(target_url.lastPathComponent).\(UUID().uuidString).tmp")

        try data.write(to: temp_url, options: [.withoutOverwriting])
        defer { try? fm.removeItem(at: temp_url) }

        if fm.fileExists(atPath: target_url.path) {
            _ = try fm.replaceItemAt(target_url, withItemAt: temp_url)
        } else {
            try fm.moveItem(at: temp_url, to: target_url)
        }
    }
    
    private func mg_key_binding(_ keys: [String]) -> Binding<Bool> {
        mg_key_binding(keys, type: Int.self, default_val: 0, on_val: 1)
    }

    private func mg_key_binding<T: Equatable>(_ keys: [String], type: T.Type, default_val: T?, on_val: T?) -> Binding<Bool>  {
        guard let cache_extra = mg_dict_now["CacheExtra"] as? NSMutableDictionary else {
            return .constant(false)
        }
        
        return Binding(get: {
            if let value = cache_extra[keys.first!] as? T?, let on_val {
                return value == on_val
            }
            
            return false
        }, set: { enabled in
            for key in keys {
                // if it exists inside of the plist, then update it. if not then pull the value completely.
                if enabled {
                    cache_extra[key] = on_val
                } else {
                    cache_extra.removeObject(forKey: key)
                }
            }
        })
    }
    
    private func mg_trollpad_binding() -> Binding<Bool> {
        guard let cache_data = mg_dict_now["CacheData"] as? NSMutableData,
                let cache_extra = mg_dict_now["CacheExtra"] as? NSMutableDictionary else {
            return .constant(false)
        }
        
        let value_off = cache_data_offset("mtrAoWJ3gsq+I90ZnQ0vQw")
        let keys = [
            "uKc7FPnEO++lVhHWHFlGbQ", // ipad
            "mG0AnH/Vy1veoqoLRAIgTA", // MedusaFloatingLiveAppCapability
            "UCG5MkVahJxG1YULbbd5Bg", // MedusaOverlayAppCapability
            "ZYqko/XM5zD3XBfN5RmaXA", // MedusaPinnedAppCapability
            "nVh/gwNpy7Jv1NOk00CMrw", // MedusaPIPCapability,
            "qeaj75wk3HF4DwQ8qbIi7g", // DeviceSupportsEnhancedMultitasking
        ]
        
        return Binding(get: {
            if let value = cache_extra[keys.first!] as? Int? {
                return value == 1
            }
            
            return false
        }, set: { enabled in
            if enabled {
                Alertinator.shared.alert(title: "高风险警告", body: "如果你使用字母数字密码，请勿启用此功能。请勿关闭“台前调度中显示程序坞”，否则横屏时可能循环启动。启用后也可能出现系统不稳定、界面缩放异常或 App 数据丢失。")
            }
            
            cache_data.mutableBytes.storeBytes(of: enabled ? 3 : 1, toByteOffset: value_off, as: Int.self)
            
            for key in keys {
                if enabled {
                    cache_extra[key] = 1
                } else {
                    cache_extra.removeObject(forKey: key)
                }
            }
        })
    }
    
    private func mg_region_restrict_binding() -> Binding<Bool> {
        guard let cache_extra = mg_dict_now["CacheExtra"] as? NSMutableDictionary else {
            return .constant(false)
        }
        
        return Binding<Bool>(
            get: {
                return cache_extra["h63QSdBCiT/z0WU6rdQv6Q"] as? String == "US" &&
                    cache_extra["zHeENZu+wbg7PUprwNwBWg"] as? String == "LL/A"
            },
            set: { enabled in
                if enabled {
                    Alertinator.shared.alert(title: "合规警告", body: "请勿使用此功能规避当地法律要求，例如关闭强制相机快门声。用户需对自己的使用行为负责。")
                    cache_extra["h63QSdBCiT/z0WU6rdQv6Q"] = "US"
                    cache_extra["zHeENZu+wbg7PUprwNwBWg"] = "LL/A"
                } else {
                    cache_extra.removeObject(forKey: "h63QSdBCiT/z0WU6rdQv6Q")
                    cache_extra.removeObject(forKey: "zHeENZu+wbg7PUprwNwBWg")
                }
            }
        )
    }
    
    private func mg_internal_binding() -> Binding<Bool> {
        guard let cache_data = mg_dict_now["CacheData"] as? NSMutableData else {
            return .constant(false)
        }
        
        let off_apple_internal_install = cache_data_offset("EqrsVvjcYDdxHBiQmGhAWw")
        let off_has_internal_settings_bundle = cache_data_offset("Oji6HRoPi7rH7HPdWVakuw")
        let off_internal_build = cache_data_offset("LBJfwOEzExRxzlAnSuI7eg")
        
        return Binding(
            get: {
                return cache_data.bytes.load(fromByteOffset: off_apple_internal_install, as: Int.self) == 1
            },
            set: { enabled in
                cache_data.mutableBytes.storeBytes(of: enabled ? 1 : 0, toByteOffset: off_apple_internal_install, as: Int.self)
                cache_data.mutableBytes.storeBytes(of: enabled ? 1 : 0, toByteOffset: off_has_internal_settings_bundle, as: Int.self)
                cache_data.mutableBytes.storeBytes(of: enabled ? 1 : 0, toByteOffset: off_internal_build, as: Int.self)
            }
        )
    }

    private func mg_apple_intelligence_binding() -> Binding<Bool> {
        guard let cache_extra = mg_dict_now["CacheExtra"] as? NSMutableDictionary else {
            return .constant(false)
        }
    
        let key = "A62OafQ85EJAiiqKn4agtg"
    
        return Binding<Bool>(
            get: {
                if let value = cache_extra[key] as? Int {
                    return value == 1
                }
    
                return false
            },
            set: { enabled in
                if enabled {
                    cache_extra[key] = 1
    
                    Alertinator.shared.alert(
                        title: "Apple Intelligence 伪装",
                        body: "使用方法：\n1. 先伪装为首款支持 Apple Intelligence 的相邻型号。\n2. 切回本机型号。\n3. 再切换到最终目标型号，“设置”中应出现 Apple Intelligence 图标。\n4. 将 iPhone 接入电源，并保持“设置 > 储存空间”打开约 1 小时。\n\n注意：不要再切回。"
                    )
                } else {
                    cache_extra.removeObject(forKey: key)
                }
            }
        )
    }
    
    private func is_device_good() -> Bool {
        let supported: [String] = ["iPhone15,2", "iPhone15,3", "iPhone15,4", "iPhone15,5", "iPhone16,1", "iPhone16,2", "iPhone17,3", "iPhone17,4", "iPhone17,1", "iPhone17,2", "iPhone18,3", "iPhone18,1", "iPhone18,2", "iPhone17,5"]
        
        if supported.contains(machine_name()) && doubleSystemVersion() < 19.0 {
            return true
        }
        
        return false
    }
    
    private func machine_name() -> String {
        var sys_info = utsname()
        uname(&sys_info)
        let machine_mirror = Mirror(reflecting: sys_info.machine)
        
        return machine_mirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8, value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
    }
}

enum InternalTheme {
    static let cyan = Color(red: 0.20, green: 0.82, blue: 1.0)
    static let violet = Color(red: 0.52, green: 0.38, blue: 1.0)
    static let background = LinearGradient(
        colors: [
            Color(red: 0.02, green: 0.04, blue: 0.085),
            Color(red: 0.045, green: 0.035, blue: 0.09),
            Color.black
        ],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
}

private struct InternalBrandHeader: View {
    let isReady: Bool
    let versionText: String

    var body: some View {
        HStack(spacing: 16) {
            ZStack {
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: [InternalTheme.cyan, InternalTheme.violet],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                Image(systemName: "waveform.path")
                    .font(.system(size: 28, weight: .semibold))
                    .foregroundStyle(.white)
            }
            .frame(width: 64, height: 64)
            .shadow(color: InternalTheme.cyan.opacity(0.2), radius: 16, y: 8)

            VStack(alignment: .leading, spacing: 5) {
                Text("弦光")
                    .font(.system(.title2, design: .rounded, weight: .bold))
                Text("设备能力与系统工具")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                HStack(spacing: 8) {
                    Label(isReady ? "已就绪" : "正在准备", systemImage: isReady ? "checkmark.circle.fill" : "hourglass")
                        .foregroundStyle(isReady ? .green : .orange)
                    Text(versionText)
                        .foregroundStyle(.secondary)
                }
                .font(.caption.weight(.semibold))
            }
            Spacer(minLength: 0)
        }
        .padding(18)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 26, style: .continuous)
                .stroke(Color.white.opacity(0.1), lineWidth: 1)
        }
        .padding(.horizontal, 2)
        .padding(.vertical, 5)
    }
}

private struct InternalActionButton: View {
    let title: String
    let symbol: String
    let color: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                Image(systemName: symbol)
                    .font(.system(size: 20, weight: .semibold))
                Text(title)
                    .font(.subheadline.weight(.semibold))
            }
            .foregroundStyle(color)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(color.opacity(0.12), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 17, style: .continuous)
                    .stroke(color.opacity(0.24), lineWidth: 1)
            }
        }
        .buttonStyle(InternalPressStyle())
    }
}

private struct InternalPressStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .opacity(configuration.isPressed ? 0.82 : 1)
            .animation(.easeOut(duration: 0.1), value: configuration.isPressed)
    }
}
