//
//  CompanySoftwareEntry.swift
//  授权计算器 (CompanySoftwareKit)
//
//  由 mond.swift 的 @main 入口改造而来：去掉 @main 与 App 结构，
//  保留全局 pipe/sema/fm/path，并暴露一个可供宿主 App 嵌入的公开根视图。
//

import SwiftUI
import PartyUI
import Foundation
import Darwin

var pipe = Pipe()
var sema = DispatchSemaphore(value: 0)
var fm = FileManager.default

var path: String {
    let url = FileManager.default
        .urls(for: .documentDirectory, in: .userDomainMask)[0]
        .appendingPathComponent("test.txt")

    if !FileManager.default.fileExists(atPath: url.path) {
        FileManager.default.createFile(atPath: url.path, contents: Data())
    }

    return url.path
}

/// 宿主 App 通过该公开类型嵌入公司软件界面。
@MainActor
public struct CompanySoftwareEntry: View {
    private let onBack: () -> Void

    public init(onBack: @escaping () -> Void) {
        self.onBack = onBack
    }

    public var body: some View {
        AnyView(CompanySoftwareRoot(onBack: onBack))
    }
}

/// 公司软件实际根视图（内部实现，不对外暴露具体类型）。
private struct CompanySoftwareRoot: View {
    @StateObject private var state = AppState()
    let onBack: () -> Void

    init(onBack: @escaping () -> Void) {
        self.onBack = onBack
        UserDefaults.standard.register(defaults: ["exploit_method": "bad_query"])
        if !is_debugged() {
            setvbuf(stdout, nil, _IONBF, 0)
            dup2(pipe.fileHandleForWriting.fileDescriptor, STDOUT_FILENO)
        }
    }

    var body: some View {
        CompanyRootView(onBack: onBack)
            .environmentObject(state)
            .onAppear {
                if !is_supported() {
                    Alertinator.shared.alert(
                        title: "当前系统可能不受支持",
                        body: "弦光可能不支持当前 iOS 版本。\n当前仅支持 iOS 27.0 beta 1 至 beta 4。"
                    )
                }
            }
            .overlay {
                if state.show_respring {
                    RespringView()
                        .brightness(-1.0)
                        .ignoresSafeArea()
                        .onAppear {
                            print("(respring) respringing now...")
                        }
                }
            }
    }
}
