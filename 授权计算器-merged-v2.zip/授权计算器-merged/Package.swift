// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "CalculatorCore",
    platforms: [.macOS(.v13)],
    products: [.library(name: "CalculatorCore", targets: ["CalculatorCore"])],
    targets: [
        .target(
            name: "CalculatorCore",
            path: "授权计算器/App",
            exclude: [
                "授权计算器App.swift", "ContentView.swift", "CalculatorAdvancedViews.swift", "LocalLedgerViews.swift",
                "KeychainTokenStore.swift", "AuthorizationService.swift", "AuthorizedSoftwareView.swift",
                "Assets.xcassets", "Localizable.xcstrings"
            ],
            sources: ["CalculatorEngine.swift", "LocalLedgerModels.swift"]
        ),
        .testTarget(
            name: "CalculatorCoreTests",
            dependencies: ["CalculatorCore"],
            path: "授权计算器Tests"
        )
    ]
)
