import SwiftUI

struct ScientificCalculatorView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var engine: CalculatorEngine
    @State private var exponentText = "2"

    private let columns = Array(repeating: GridItem(.flexible(), spacing: 10), count: 4)

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    calculatorReadout

                    Picker("角度单位", selection: angleModeBinding) {
                        ForEach(CalculatorAngleMode.allCases) { mode in
                            Text(mode.title).tag(mode)
                        }
                    }
                    .pickerStyle(.segmented)

                    LazyVGrid(columns: columns, spacing: 10) {
                        ForEach(ScientificFunction.allCases) { function in
                            Button(function.title) {
                                engine.applyScientific(function)
                            }
                            .buttonStyle(ScientificKeyStyle())
                        }

                        Button("π") { engine.insertConstant(.pi, name: "π") }
                            .buttonStyle(ScientificKeyStyle(accented: true))
                        Button("e") { engine.insertConstant(M_E, name: "e") }
                            .buttonStyle(ScientificKeyStyle(accented: true))
                        Button("随机") { engine.generateRandomNumber() }
                            .buttonStyle(ScientificKeyStyle(accented: true))
                    }

                    VStack(alignment: .leading, spacing: 10) {
                        Text("任意次方")
                            .font(.headline)
                        HStack(spacing: 10) {
                            Text(engine.formattedDisplay)
                                .font(.system(.body, design: .rounded, weight: .semibold))
                                .lineLimit(1)
                            Text("的")
                                .foregroundStyle(.secondary)
                            TextField("指数", text: $exponentText)
                                .keyboardType(.numbersAndPunctuation)
                                .textFieldStyle(.roundedBorder)
                            Button("次方") {
                                if let exponent = Double(exponentText) {
                                    engine.applyPower(exponent: exponent)
                                }
                            }
                            .buttonStyle(.borderedProminent)
                        }
                    }
                    .padding(16)
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18))
                }
                .padding(16)
            }
            .navigationTitle("科学计算")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") { dismiss() }
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private var calculatorReadout: some View {
        VStack(alignment: .trailing, spacing: 6) {
            Text(engine.lastError ?? (engine.expression.isEmpty ? "科学计算" : engine.expression))
                .font(.subheadline)
                .foregroundStyle(engine.lastError == nil ? Color.secondary : Color.red)
                .lineLimit(2)
            ScrollView(.horizontal, showsIndicators: false) {
                Text(engine.formattedDisplay)
                    .font(.system(size: 46, weight: .light, design: .rounded))
                    .monospacedDigit()
                    .frame(maxWidth: .infinity, alignment: .trailing)
            }
        }
        .frame(maxWidth: .infinity, alignment: .trailing)
        .padding(18)
        .background(
            LinearGradient(
                colors: [Color.indigo.opacity(0.32), Color.cyan.opacity(0.12)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ),
            in: RoundedRectangle(cornerRadius: 22)
        )
    }

    private var angleModeBinding: Binding<CalculatorAngleMode> {
        Binding(
            get: { engine.angleMode },
            set: { engine.setAngleMode($0) }
        )
    }
}

struct CalculatorMemoryView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var engine: CalculatorEngine

    var body: some View {
        NavigationStack {
            VStack(spacing: 18) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("记忆值")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    Text(engine.memoryValue.map { engine.string(for: $0) } ?? "尚未保存")
                        .font(.system(size: 38, weight: .light, design: .rounded))
                        .monospacedDigit()
                        .lineLimit(1)
                        .minimumScaleFactor(0.5)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(18)
                .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 20))

                HStack(spacing: 10) {
                    memoryButton("MC", "清除") { engine.memoryClear() }
                    memoryButton("MR", "读取") { engine.memoryRecall() }
                    memoryButton("MS", "保存") { engine.memoryStore() }
                }
                HStack(spacing: 10) {
                    memoryButton("M+", "累加") { engine.memoryAdd() }
                    memoryButton("M−", "减去") { engine.memorySubtract() }
                }

                Text("当前显示：\(engine.formattedDisplay)")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                Spacer()
            }
            .padding(18)
            .navigationTitle("计算器记忆")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") { dismiss() }
                }
            }
        }
        .preferredColorScheme(.dark)
        .presentationDetents([.height(380)])
    }

    private func memoryButton(_ title: String, _ subtitle: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Text(title).font(.title3.bold())
                Text(subtitle).font(.caption).foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, minHeight: 62)
        }
        .buttonStyle(.bordered)
        .buttonBorderShape(.roundedRectangle(radius: 15))
    }
}

struct CalculatorSettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @AppStorage("calculator.haptics.enabled") private var hapticsEnabled = true
    @Binding var engine: CalculatorEngine

    var body: some View {
        NavigationStack {
            Form {
                Section("结果显示") {
                    Toggle("显示千位分隔符", isOn: groupingBinding)
                    Picker("固定小数位", selection: decimalPlacesBinding) {
                        Text("自动").tag(-1)
                        ForEach([0, 2, 4, 6, 8, 12], id: \.self) { places in
                            Text("\(places) 位").tag(places)
                        }
                    }

                    LabeledContent("预览", value: engine.formattedDisplay)
                        .monospacedDigit()
                }

                Section {
                    Picker("计算精度", selection: calculationScaleBinding) {
                        ForEach([8, 12, 16, 20, 24, 28], id: \.self) { scale in
                            Text("\(scale) 位小数").tag(scale)
                        }
                    }
                    Picker("舍入方式", selection: roundingModeBinding) {
                        ForEach(CalculatorRoundingMode.allCases) { mode in
                            Text(mode.title).tag(mode)
                        }
                    }
                } header: {
                    Text("精度与舍入")
                } footer: {
                    Text("基础运算使用 Decimal，设置会应用到除法和表达式结果；消费与贷款金额固定使用银行家舍入保留两位小数。")
                }

                Section("说明") {
                    Toggle("按键触感反馈", isOn: $hapticsEnabled)
                    LabeledContent("历史容量", value: "100 条")
                    LabeledContent("撤销容量", value: "80 步")
                    LabeledContent("三角函数", value: engine.angleMode.title)
                }

                Section {
                    NavigationLink {
                        CalculatorPrivacyPolicyView()
                    } label: {
                        Label("APP隐私与政策", systemImage: "hand.raised.fill")
                    }
                } header: {
                    Text("隐私")
                } footer: {
                    Text("查看计算器功能如何处理历史、剪贴板与导出数据。")
                }
            }
            .navigationTitle("计算器设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") { dismiss() }
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private var groupingBinding: Binding<Bool> {
        Binding(
            get: { engine.usesThousandsSeparators },
            set: { engine.setUsesThousandsSeparators($0) }
        )
    }

    private var decimalPlacesBinding: Binding<Int> {
        Binding(
            get: { engine.fixedDecimalPlaces ?? -1 },
            set: { engine.setFixedDecimalPlaces($0 < 0 ? nil : $0) }
        )
    }

    private var calculationScaleBinding: Binding<Int> {
        Binding(
            get: { engine.calculationScale },
            set: { engine.setCalculationScale($0) }
        )
    }

    private var roundingModeBinding: Binding<CalculatorRoundingMode> {
        Binding(
            get: { engine.roundingMode },
            set: { engine.setRoundingMode($0) }
        )
    }

}

private struct CalculatorPrivacyPolicyView: View {
    var body: some View {
        List {
            Section {
                Label("本政策仅适用于 APP 内的计算器功能，不涵盖其他独立功能。", systemImage: "info.circle.fill")
                    .foregroundStyle(.secondary)
            }

            policySection(
                title: "数据收集",
                icon: "person.crop.circle.badge.xmark",
                text: "计算器不会收集、上传或出售你的个人信息，不包含广告跟踪，也不会为计算器功能创建用户画像。"
            )

            policySection(
                title: "本地保存",
                icon: "iphone",
                text: "计算历史、收藏、备注、记忆值、显示精度、舍入方式和触感偏好仅保存在当前设备的 APP 本地空间。计算器不使用 iCloud 或其他云端服务同步这些数据。"
            )

            policySection(
                title: "剪贴板",
                icon: "doc.on.clipboard",
                text: "只有在你主动点击“复制”或“粘贴并计算”时，计算器才会写入或读取系统剪贴板。剪贴板内容不会被后台读取、保存到历史之外的位置或上传。"
            )

            policySection(
                title: "历史与备注",
                icon: "clock.arrow.circlepath",
                text: "完成计算后，算式和结果会自动加入本地历史；备注和收藏由你主动添加。你可以单条删除、批量删除或清空全部历史。"
            )

            policySection(
                title: "文件导出",
                icon: "square.and.arrow.up",
                text: "导出 CSV 仅在你主动操作时生成。文件保存位置和后续分享对象由你通过 iOS 系统界面自行选择，计算器不会自动传输导出文件。"
            )

            policySection(
                title: "网络与第三方",
                icon: "network.slash",
                text: "计算器的基础运算、科学计算、单位换算、日期、消费和贷款计算均在设备本地完成，不需要网络，也不会将计算内容发送给第三方。"
            )

            policySection(
                title: "数据删除与保留",
                icon: "trash",
                text: "你可以在历史记录中清空计算数据，并通过记忆功能清除记忆值。删除 APP 会同时移除计算器保存在 APP 本地空间的数据。"
            )

            Section("政策更新") {
                Text("如果计算器未来的数据处理方式发生变化，本页面将同步更新并明确说明。")
                LabeledContent("更新日期") {
                    Text("2026年8月29日")
                }
            }
        }
        .navigationTitle("APP隐私与政策")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func policySection(title: LocalizedStringKey, icon: String, text: LocalizedStringKey) -> some View {
        Section {
            Text(text)
                .font(.body)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        } header: {
            Label {
                Text(title)
            } icon: {
                Image(systemName: icon)
            }
            .foregroundStyle(.primary)
        }
    }
}

struct CalculatorToolsHubView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section("换算") {
                    NavigationLink {
                        UnitConverterView()
                    } label: {
                        toolLabel("单位换算", "长度、面积、重量、温度、速度和容量", "arrow.left.arrow.right.circle.fill", .cyan)
                    }
                    NavigationLink {
                        BaseConverterView()
                    } label: {
                        toolLabel("进制转换", "二、八、十、十六进制", "number.circle.fill", .indigo)
                    }
                }

                Section("实用计算") {
                    NavigationLink {
                        DateCalculatorView()
                    } label: {
                        toolLabel("日期计算", "日期间隔和日期推算", "calendar.circle.fill", .orange)
                    }
                    NavigationLink {
                        BusinessCalculatorView()
                    } label: {
                        toolLabel("消费计算", "折扣、税费、小费和均摊", "percent", .pink)
                    }
                    NavigationLink {
                        LoanCalculatorView()
                    } label: {
                        toolLabel("贷款计算", "月供、总还款和利息", "house.circle.fill", .green)
                    }
                }
            }
            .navigationTitle("计算工具")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") { dismiss() }
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private func toolLabel(_ title: String, _ subtitle: String, _ icon: String, _ color: Color) -> some View {
        HStack(spacing: 13) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundStyle(color)
                .frame(width: 34)
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.headline)
                Text(subtitle).font(.caption).foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
}

private struct UnitConverterView: View {
    @State private var category: UnitCategory = .length
    @State private var input = "1"
    @State private var sourceIndex = 0
    @State private var targetIndex = 1

    var body: some View {
        Form {
            Section("类别") {
                Picker("单位类别", selection: $category) {
                    ForEach(UnitCategory.allCases) { category in
                        Text(category.title).tag(category)
                    }
                }
                .onChange(of: category) {
                    sourceIndex = 0
                    targetIndex = min(1, category.units.count - 1)
                }
            }

            Section("输入") {
                TextField("数值", text: $input)
                    .keyboardType(.numbersAndPunctuation)
                Picker("原单位", selection: $sourceIndex) {
                    ForEach(category.units.indices, id: \.self) { index in
                        Text(category.units[index].label).tag(index)
                    }
                }
                Picker("目标单位", selection: $targetIndex) {
                    ForEach(category.units.indices, id: \.self) { index in
                        Text(category.units[index].label).tag(index)
                    }
                }
                Button {
                    swap(&sourceIndex, &targetIndex)
                } label: {
                    Label("交换单位", systemImage: "arrow.up.arrow.down")
                }
            }

            Section("换算结果") {
                Text(resultText)
                    .font(.system(size: 30, weight: .semibold, design: .rounded))
                    .monospacedDigit()
                    .textSelection(.enabled)
            }
        }
        .navigationTitle("单位换算")
    }

    private var resultText: String {
        guard let value = Double(input),
              category.units.indices.contains(sourceIndex),
              category.units.indices.contains(targetIndex) else { return "—" }
        let source = category.units[sourceIndex]
        let target = category.units[targetIndex]
        let base = value * source.factor + source.offset
        let result = (base - target.offset) / target.factor
        return "\(String(format: "%.12g", result)) \(target.symbol)"
    }
}

private struct DateCalculatorView: View {
    @State private var startDate = Date()
    @State private var endDate = Calendar.current.date(byAdding: .day, value: 30, to: Date()) ?? Date()
    @State private var includesEndDate = false
    @State private var offsetDays = 30

    var body: some View {
        Form {
            Section("日期间隔") {
                DatePicker("开始日期", selection: $startDate, displayedComponents: .date)
                DatePicker("结束日期", selection: $endDate, displayedComponents: .date)
                Toggle("包含结束当天", isOn: $includesEndDate)

                LabeledContent("相差天数", value: "\(dayDifference) 天")
                LabeledContent("换算周数", value: String(format: "%.2f 周", Double(dayDifference) / 7))
            }

            Section("日期推算") {
                DatePicker("基准日期", selection: $startDate, displayedComponents: .date)
                Stepper("偏移 \(offsetDays) 天", value: $offsetDays, in: -36500...36500)
                LabeledContent("目标日期", value: targetDate.formatted(date: .long, time: .omitted))
            }
        }
        .navigationTitle("日期计算")
    }

    private var dayDifference: Int {
        let calendar = Calendar.current
        let start = calendar.startOfDay(for: startDate)
        let end = calendar.startOfDay(for: endDate)
        let days = calendar.dateComponents([.day], from: start, to: end).day ?? 0
        return days + (includesEndDate ? (days >= 0 ? 1 : -1) : 0)
    }

    private var targetDate: Date {
        Calendar.current.date(byAdding: .day, value: offsetDays, to: startDate) ?? startDate
    }
}

private struct BusinessCalculatorView: View {
    private static let moneyFormatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.locale = .current
        formatter.numberStyle = .decimal
        formatter.minimumFractionDigits = 2
        formatter.maximumFractionDigits = 2
        return formatter
    }()

    @State private var price = "100"
    @State private var discount = "10"
    @State private var tax = "0"
    @State private var tip = "0"
    @State private var people = 1

    var body: some View {
        Form {
            Section("金额") {
                DecimalField("原价", text: $price)
                DecimalField("折扣 %", text: $discount)
                DecimalField("税率 %", text: $tax)
                DecimalField("小费 %", text: $tip)
                Stepper("均摊人数：\(people)", value: $people, in: 1...100)
            }

            Section("结果") {
                LabeledContent("折后金额", value: currency(discountedPrice))
                LabeledContent("税费", value: currency(taxAmount))
                LabeledContent("小费", value: currency(tipAmount))
                LabeledContent("应付总额", value: currency(total))
                    .font(.headline)
                LabeledContent("每人支付", value: currency(total / Decimal(people)))
                    .font(.headline)
            }
        }
        .navigationTitle("消费计算")
    }

    private var basePrice: Decimal { decimal(price) }
    private var discountedPrice: Decimal { basePrice * (1 - decimal(discount) / 100) }
    private var taxAmount: Decimal { discountedPrice * decimal(tax) / 100 }
    private var tipAmount: Decimal { discountedPrice * decimal(tip) / 100 }
    private var total: Decimal { discountedPrice + taxAmount + tipAmount }

    private func decimal(_ value: String) -> Decimal {
        Decimal(string: value, locale: Locale(identifier: "en_US_POSIX")) ?? 0
    }

    private func currency(_ value: Decimal) -> String {
        var source = value
        var rounded = Decimal()
        NSDecimalRound(&rounded, &source, 2, .bankers)
        return Self.moneyFormatter.string(from: NSDecimalNumber(decimal: rounded)) ?? "0.00"
    }
}

private struct LoanCalculatorView: View {
    private static let moneyFormatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.locale = .current
        formatter.numberStyle = .decimal
        formatter.minimumFractionDigits = 2
        formatter.maximumFractionDigits = 2
        return formatter
    }()

    @State private var principal = "1000000"
    @State private var annualRate = "3.5"
    @State private var years = 30

    var body: some View {
        Form {
            Section("贷款信息") {
                DecimalField("贷款本金", text: $principal)
                DecimalField("年利率 %", text: $annualRate)
                Stepper("贷款期限：\(years) 年", value: $years, in: 1...50)
            }

            Section("等额本息") {
                LabeledContent("每月还款", value: money(monthlyPayment))
                    .font(.headline)
                LabeledContent("总还款", value: money(totalPayment))
                LabeledContent("总利息", value: money(max(0, totalPayment - loanPrincipal)))
                LabeledContent("还款期数", value: "\(years * 12) 期")
            }
        }
        .navigationTitle("贷款计算")
    }

    private var loanPrincipal: Decimal {
        max(0, Decimal(string: principal, locale: Locale(identifier: "en_US_POSIX")) ?? 0)
    }
    private var monthlyPayment: Decimal {
        let months = Double(years * 12)
        let principalValue = NSDecimalNumber(decimal: loanPrincipal).doubleValue
        let monthlyRate = max(0, Double(annualRate) ?? 0) / 1200
        guard monthlyRate > 0 else {
            return months > 0 ? roundedMoney(loanPrincipal / Decimal(Int(months))) : 0
        }
        let power = pow(1 + monthlyRate, months)
        return roundedMoney(Decimal(principalValue * monthlyRate * power / (power - 1)))
    }
    private var totalPayment: Decimal { roundedMoney(monthlyPayment * Decimal(years * 12)) }

    private func roundedMoney(_ value: Decimal) -> Decimal {
        var source = value
        var result = Decimal()
        NSDecimalRound(&result, &source, 2, .bankers)
        return result
    }

    private func money(_ value: Decimal) -> String {
        return Self.moneyFormatter.string(from: NSDecimalNumber(decimal: roundedMoney(value))) ?? "0.00"
    }
}

private struct BaseConverterView: View {
    @State private var input = "255"
    @State private var sourceBase = 10

    private let bases = [2, 8, 10, 16]

    var body: some View {
        Form {
            Section("输入") {
                TextField("整数", text: $input)
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
                Picker("原进制", selection: $sourceBase) {
                    ForEach(bases, id: \.self) { base in
                        Text(baseName(base)).tag(base)
                    }
                }
            }

            Section("转换结果") {
                if let value = parsedValue {
                    ForEach(bases, id: \.self) { base in
                        LabeledContent(baseName(base), value: String(value, radix: base, uppercase: true))
                            .monospacedDigit()
                            .textSelection(.enabled)
                    }
                } else {
                    ContentUnavailableView(
                        "输入格式不正确",
                        systemImage: "exclamationmark.triangle",
                        description: Text("请输入所选进制允许的整数字符。")
                    )
                }
            }
        }
        .navigationTitle("进制转换")
    }

    private var parsedValue: Int64? {
        Int64(input.trimmingCharacters(in: .whitespacesAndNewlines), radix: sourceBase)
    }

    private func baseName(_ base: Int) -> String {
        switch base {
        case 2: "二进制"
        case 8: "八进制"
        case 16: "十六进制"
        default: "十进制"
        }
    }
}

private struct DecimalField: View {
    let title: String
    @Binding var text: String

    init(_ title: String, text: Binding<String>) {
        self.title = title
        _text = text
    }

    var body: some View {
        HStack {
            Text(title)
            Spacer()
            TextField("0", text: $text)
                .keyboardType(.numbersAndPunctuation)
                .multilineTextAlignment(.trailing)
                .frame(maxWidth: 150)
        }
    }
}

private struct ScientificKeyStyle: ButtonStyle {
    var accented = false

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 17, weight: .semibold, design: .rounded))
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity, minHeight: 48)
            .background(
                accented ? Color.indigo.opacity(0.7) : Color.white.opacity(0.09),
                in: RoundedRectangle(cornerRadius: 14)
            )
            .scaleEffect(configuration.isPressed ? 0.96 : 1)
    }
}

private struct UnitDefinition {
    let name: String
    let symbol: String
    let factor: Double
    let offset: Double

    var label: String { "\(name)（\(symbol)）" }
}

private enum UnitCategory: String, CaseIterable, Identifiable {
    case length, area, mass, temperature, speed, volume

    var id: String { rawValue }
    var title: String {
        switch self {
        case .length: "长度"
        case .area: "面积"
        case .mass: "重量"
        case .temperature: "温度"
        case .speed: "速度"
        case .volume: "容量"
        }
    }

    var units: [UnitDefinition] {
        switch self {
        case .length:
            [unit("毫米", "mm", 0.001), unit("厘米", "cm", 0.01), unit("米", "m", 1), unit("千米", "km", 1000), unit("英寸", "in", 0.0254), unit("英尺", "ft", 0.3048), unit("英里", "mi", 1609.344)]
        case .area:
            [unit("平方米", "m²", 1), unit("平方千米", "km²", 1_000_000), unit("公顷", "ha", 10_000), unit("亩", "亩", 666.6666667), unit("平方英尺", "ft²", 0.09290304)]
        case .mass:
            [unit("克", "g", 0.001), unit("千克", "kg", 1), unit("吨", "t", 1000), unit("盎司", "oz", 0.0283495231), unit("磅", "lb", 0.45359237)]
        case .temperature:
            [unit("摄氏度", "℃", 1, 0), unit("华氏度", "℉", 5 / 9, -160 / 9), unit("开尔文", "K", 1, -273.15)]
        case .speed:
            [unit("米/秒", "m/s", 1), unit("千米/小时", "km/h", 1 / 3.6), unit("英里/小时", "mph", 0.44704), unit("节", "kn", 0.514444)]
        case .volume:
            [unit("毫升", "mL", 0.001), unit("升", "L", 1), unit("立方米", "m³", 1000), unit("美制加仑", "gal", 3.785411784), unit("液体盎司", "fl oz", 0.0295735296)]
        }
    }

    private func unit(_ name: String, _ symbol: String, _ factor: Double, _ offset: Double = 0) -> UnitDefinition {
        UnitDefinition(name: name, symbol: symbol, factor: factor, offset: offset)
    }
}
