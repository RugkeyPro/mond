import SwiftUI

@main
struct 授权计算器App: App {
    @StateObject private var authorization = AuthorizationManager()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(authorization)
        }
    }
}
