import Foundation
import Security

final class KeychainTokenStore {
    private let service: String
    private let tokenAccount = "authorization-token"
    private let deviceAccount = "authorization-device-id"

    init(service: String = Bundle.main.bundleIdentifier ?? "com.beiqizou.xianguang") {
        self.service = service
    }

    func saveToken(_ token: String) throws {
        try save(token, account: tokenAccount)
    }

    func loadToken() -> String? {
        try? load(account: tokenAccount)
    }

    func deleteToken() throws {
        try delete(account: tokenAccount)
    }

    func deviceID() throws -> String {
        if let existing = try load(account: deviceAccount), !existing.isEmpty {
            return existing
        }
        let generated = UUID().uuidString.lowercased()
        try save(generated, account: deviceAccount)
        return generated
    }

    private func save(_ value: String, account: String) throws {
        let data = Data(value.utf8)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        let attributes: [String: Any] = [kSecValueData as String: data]
        let updateStatus = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if updateStatus == errSecItemNotFound {
            var addQuery = query
            addQuery[kSecValueData as String] = data
            addQuery[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
            let status = SecItemAdd(addQuery as CFDictionary, nil)
            guard status == errSecSuccess else { throw KeychainError(status) }
        } else if updateStatus != errSecSuccess {
            throw KeychainError(updateStatus)
        }
    }

    private func load(account: String) throws -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data = result as? Data else { throw KeychainError(status) }
        return String(data: data, encoding: .utf8)
    }

    private func delete(account: String) throws {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        let status = SecItemDelete(query as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else { throw KeychainError(status) }
    }
}

struct KeychainError: LocalizedError {
    let status: OSStatus

    init(_ status: OSStatus) { self.status = status }

    var errorDescription: String? {
        SecCopyErrorMessageString(status, nil) as String? ?? "Keychain 错误（\(status)）"
    }
}
