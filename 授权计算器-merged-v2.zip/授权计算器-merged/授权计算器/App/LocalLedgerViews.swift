import SwiftUI

struct LocalLedgerRootView: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @StateObject private var store = LocalLedgerStore()
    @Binding var isInviteVerifying: Bool
    let onInviteCode: (String) -> Void
    @State private var selection: LocalLedgerTab = .overview
    @Namespace private var tabSelection

    var body: some View {
        TabView(selection: $selection) {
            LocalLedgerOverviewView(store: store)
                .tag(LocalLedgerTab.overview)

            LocalLedgerTransactionsView(store: store)
                .tag(LocalLedgerTab.transactions)

            LocalLedgerBudgetsView(store: store)
                .tag(LocalLedgerTab.budgets)

            ZStack {
                CalculatorBackground()
                AuroraCalculatorView(
                    isInviteVerifying: $isInviteVerifying,
                    onInviteCode: onInviteCode
                )
            }
            .tag(LocalLedgerTab.calculator)
        }
        .tabViewStyle(.page(indexDisplayMode: .never))
        .background(LocalLedgerBackground())
        .safeAreaInset(edge: .bottom, spacing: 0) {
            HStack(spacing: 5) {
                ForEach(LocalLedgerTab.allCases) { tab in
                    Button {
                        withAnimation(reduceMotion ? nil : .spring(response: 0.34, dampingFraction: 0.86)) {
                            selection = tab
                        }
                    } label: {
                        HStack(spacing: 7) {
                            Image(systemName: selection == tab ? tab.selectedSymbol : tab.symbol)
                                .font(.system(size: 16, weight: .semibold))
                            if selection == tab {
                                Text(tab.title)
                                    .font(.caption.weight(.semibold))
                                    .lineLimit(1)
                            }
                        }
                        .foregroundStyle(selection == tab ? Color.white : Color.white.opacity(0.52))
                        .frame(maxWidth: .infinity)
                        .frame(height: 48)
                        .background {
                            if selection == tab {
                                Capsule(style: .continuous)
                                    .fill(XianguangTheme.accentGradient)
                                    .matchedGeometryEffect(id: "selected-tab", in: tabSelection)
                                    .shadow(color: XianguangTheme.cyan.opacity(0.2), radius: 12, y: 5)
                            }
                        }
                        .contentShape(Capsule())
                    }
                    .buttonStyle(XianguangPressStyle())
                    .accessibilityLabel(tab.title)
                    .accessibilityAddTraits(selection == tab ? .isSelected : [])
                }
            }
            .padding(6)
            .background(
                reduceTransparency ? XianguangTheme.surface : Color.black.opacity(0.56),
                in: Capsule(style: .continuous)
            )
            .background(.ultraThinMaterial, in: Capsule(style: .continuous))
            .overlay {
                Capsule(style: .continuous)
                    .stroke(Color.white.opacity(0.1), lineWidth: 1)
            }
            .padding(.horizontal, 14)
            .padding(.top, 8)
            .padding(.bottom, 6)
        }
        .sensoryFeedback(.selection, trigger: selection)
        .tint(XianguangTheme.cyan)
    }
}

private enum LocalLedgerTab: String, CaseIterable, Identifiable {
    case overview, transactions, budgets, calculator

    var id: String { rawValue }

    var title: String {
        switch self {
        case .overview: "总览"
        case .transactions: "明细"
        case .budgets: "预算"
        case .calculator: "计算"
        }
    }

    var symbol: String {
        switch self {
        case .overview: "sparkles"
        case .transactions: "list.bullet.rectangle"
        case .budgets: "chart.pie"
        case .calculator: "plus.forwardslash.minus"
        }
    }

    var selectedSymbol: String {
        switch self {
        case .overview: "sparkles"
        case .transactions: "list.bullet.rectangle.fill"
        case .budgets: "chart.pie.fill"
        case .calculator: "plus.forwardslash.minus"
        }
    }
}

private struct LocalLedgerOverviewView: View {
    @ObservedObject var store: LocalLedgerStore
    @State private var presentingEntryKind: LocalLedgerEntryKind?
    @State private var showingAccounts = false
    @State private var showingSettings = false

    var body: some View {
        NavigationStack {
            ZStack {
                LocalLedgerBackground()
                ScrollView {
                    LazyVStack(spacing: 18) {
                        brandHeader
                        balanceCard
                        quickEntryCard
                        monthSummaryCard
                        categoryCard
                        recentCard
                    }
                    .padding(.horizontal, 18)
                    .padding(.top, 8)
                    .padding(.bottom, 28)
                }
                .scrollIndicators(.hidden)
            }
            .toolbarBackground(.hidden, for: .navigationBar)
            .toolbar {
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button { showingAccounts = true } label: { toolbarIcon("wallet.bifold.fill") }
                        .buttonStyle(XianguangPressStyle())
                        .accessibilityLabel("账户管理")
                    Button { showingSettings = true } label: {
                        toolbarIcon("slider.horizontal.3")
                    }
                    .buttonStyle(XianguangPressStyle())
                    .accessibilityLabel("本地账本设置")
                }
            }
            .sheet(item: $presentingEntryKind) { kind in
                LocalLedgerEntryForm(store: store, initialKind: kind)
            }
            .sheet(isPresented: $showingAccounts) {
                LocalLedgerAccountsView(store: store)
            }
            .sheet(isPresented: $showingSettings) {
                LocalLedgerSettingsView(store: store)
            }
        }
    }

    private var brandHeader: some View {
        HStack(spacing: 13) {
            XianguangMark()
                .frame(width: 46, height: 46)
            VStack(alignment: .leading, spacing: 2) {
                Text("弦光")
                    .font(.system(.title2, design: .rounded, weight: .bold))
                    .tracking(-0.5)
                Text("本地账本 · \(Date.now.formatted(.dateTime.month(.wide)))")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
        .accessibilityElement(children: .combine)
    }

    private func toolbarIcon(_ symbol: String) -> some View {
        Image(systemName: symbol)
            .font(.system(size: 15, weight: .semibold))
            .frame(width: 36, height: 36)
            .background(.thinMaterial, in: Circle())
            .overlay { Circle().stroke(Color.white.opacity(0.1), lineWidth: 1) }
    }

    private var balanceCard: some View {
        VStack(alignment: .leading, spacing: 19) {
            HStack {
                Label("总余额", systemImage: "waveform.path")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.72))
                Spacer()
                Label("本机存储", systemImage: "lock.fill")
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.7))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(Color.white.opacity(0.08), in: Capsule())
            }
            Text("¥\(store.moneyString(store.totalBalance))")
                .font(.system(size: 42, weight: .bold, design: .rounded))
                .tracking(-1.2)
                .monospacedDigit()
                .minimumScaleFactor(0.58)
            HStack(spacing: 8) {
                ForEach(store.accounts.prefix(3)) { account in
                    Label(account.name, systemImage: account.kind.symbol)
                        .font(.caption)
                        .lineLimit(1)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 7)
                        .background(Color.black.opacity(0.16), in: Capsule())
                }
                Spacer(minLength: 0)
                Text("\(store.entries.count) 笔")
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.white.opacity(0.62))
            }
        }
        .padding(20)
        .foregroundStyle(.white)
        .background(XianguangTheme.heroGradient, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
        .overlay(alignment: .topTrailing) {
            XianguangMark(showBackground: false)
                .frame(width: 132, height: 132)
                .opacity(0.16)
                .offset(x: 29, y: -35)
                .allowsHitTesting(false)
        }
        .overlay {
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .stroke(Color.white.opacity(0.16), lineWidth: 1)
        }
        .shadow(color: XianguangTheme.violet.opacity(0.18), radius: 28, y: 16)
    }

    private var quickEntryCard: some View {
        HStack(spacing: 12) {
            quickButton(kind: .expense, color: .orange)
            quickButton(kind: .income, color: .green)
        }
    }

    private func quickButton(kind: LocalLedgerEntryKind, color: Color) -> some View {
        Button { presentingEntryKind = kind } label: {
            HStack(spacing: 11) {
                Image(systemName: kind.symbol)
                    .font(.system(size: 16, weight: .bold))
                    .frame(width: 34, height: 34)
                    .background(color.opacity(0.18), in: Circle())
                VStack(alignment: .leading, spacing: 2) {
                    Text("记一笔\(kind.title)")
                        .font(.subheadline.weight(.bold))
                    Text(kind == .expense ? "记录日常消费" : "记录资金入账")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(13)
            .background(XianguangTheme.surface.opacity(0.82), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(color.opacity(0.22), lineWidth: 1)
            }
        }
        .buttonStyle(XianguangPressStyle())
        .foregroundStyle(.primary)
    }

    private var monthSummaryCard: some View {
        LocalLedgerCard {
            VStack(alignment: .leading, spacing: 14) {
                sectionHeader("本月收支", symbol: "calendar")
                HStack(spacing: 10) {
                    summaryMetric("收入", store.currentMonthIncome, .green)
                    summaryMetric("支出", store.currentMonthExpense, .orange)
                    summaryMetric("结余", store.currentMonthNet, store.currentMonthNet >= 0 ? .cyan : .red)
                }
            }
        }
    }

    private func summaryMetric(_ title: String, _ value: Decimal, _ color: Color) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            Text("¥\(store.moneyString(value))")
                .font(.subheadline.weight(.bold))
                .monospacedDigit()
                .foregroundStyle(color)
                .lineLimit(1)
                .minimumScaleFactor(0.55)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var categoryCard: some View {
        LocalLedgerCard {
            VStack(alignment: .leading, spacing: 13) {
                sectionHeader("本月支出去向", symbol: "chart.bar.xaxis")
                if store.currentMonthCategoryExpenses.isEmpty {
                    Text("添加支出后，这里会显示分类占比。")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                } else {
                    let maximum = store.currentMonthCategoryExpenses.first?.amount ?? 1
                    ForEach(store.currentMonthCategoryExpenses.prefix(5), id: \.category) { item in
                        VStack(spacing: 7) {
                            HStack {
                                Label(item.category.title, systemImage: item.category.symbol)
                                Spacer()
                                Text("¥\(store.moneyString(item.amount))").monospacedDigit()
                            }
                            .font(.subheadline)
                            ProgressView(value: ratio(item.amount, maximum))
                                .tint(categoryColor(item.category))
                        }
                    }
                }
            }
        }
    }

    private var recentCard: some View {
        LocalLedgerCard {
            VStack(alignment: .leading, spacing: 13) {
                sectionHeader("最近明细", symbol: "clock.arrow.circlepath")
                if store.entries.isEmpty {
                    Text("还没有账目，点击上方按钮记录第一笔。")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(store.entries.prefix(5)) { entry in
                        LocalLedgerEntryRow(entry: entry, store: store)
                        if entry.id != store.entries.prefix(5).last?.id { Divider() }
                    }
                }
            }
        }
    }

    private func sectionHeader(_ title: String, symbol: String) -> some View {
        Label(title, systemImage: symbol)
            .font(.headline)
            .foregroundStyle(.white.opacity(0.92))
    }
}

private struct LocalLedgerTransactionsView: View {
    @ObservedObject var store: LocalLedgerStore
    @State private var searchText = ""
    @State private var filter: LocalLedgerEntryKind?
    @State private var showingAdd = false
    @State private var editingEntry: LocalLedgerEntry?
    @State private var pendingDeletion: LocalLedgerEntry?

    var body: some View {
        NavigationStack {
            ZStack {
                LocalLedgerBackground()
                Group {
                    if store.entries.isEmpty {
                        ContentUnavailableView(
                            "暂无收支记录",
                            systemImage: "list.bullet.rectangle",
                            description: Text("点击右上角加号记录收入或支出。")
                        )
                    } else if filteredEntries.isEmpty {
                        ContentUnavailableView.search(text: searchText)
                    } else {
                        List {
                            Section {
                                Picker("类型", selection: $filter) {
                                    Text("全部").tag(nil as LocalLedgerEntryKind?)
                                    ForEach(LocalLedgerEntryKind.allCases) { kind in
                                        Text(kind.title).tag(kind as LocalLedgerEntryKind?)
                                    }
                                }
                                .pickerStyle(.segmented)
                            }
                            ForEach(groupedEntries) { group in
                                Section(group.title) {
                                    ForEach(group.entries) { entry in
                                        Button { editingEntry = entry } label: {
                                            LocalLedgerEntryRow(entry: entry, store: store)
                                        }
                                        .buttonStyle(XianguangPressStyle(scale: 0.992))
                                        .swipeActions {
                                            Button(role: .destructive) { pendingDeletion = entry } label: {
                                                Label("删除", systemImage: "trash")
                                            }
                                            Button { editingEntry = entry } label: {
                                                Label("编辑", systemImage: "pencil")
                                            }
                                            .tint(.indigo)
                                        }
                                    }
                                }
                            }
                        }
                        .scrollContentBackground(.hidden)
                        .listStyle(.insetGrouped)
                    }
                }
            }
            .navigationTitle("收支明细")
            .toolbarBackground(.hidden, for: .navigationBar)
            .searchable(text: $searchText, prompt: "搜索商家、备注、分类或金额")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showingAdd = true } label: {
                        Image(systemName: "plus")
                            .font(.system(size: 15, weight: .bold))
                            .frame(width: 36, height: 36)
                            .background(XianguangTheme.accentGradient, in: Circle())
                    }
                    .buttonStyle(XianguangPressStyle())
                        .accessibilityLabel("添加账目")
                }
            }
            .sheet(isPresented: $showingAdd) { LocalLedgerEntryForm(store: store) }
            .sheet(item: $editingEntry) { LocalLedgerEntryForm(store: store, entry: $0) }
            .confirmationDialog(
                "删除这条账目？",
                isPresented: Binding(
                    get: { pendingDeletion != nil },
                    set: { if !$0 { pendingDeletion = nil } }
                ),
                titleVisibility: .visible
            ) {
                Button("删除", role: .destructive) {
                    if let id = pendingDeletion?.id { store.deleteEntry(id: id) }
                    pendingDeletion = nil
                }
                Button("取消", role: .cancel) { pendingDeletion = nil }
            }
        }
    }

    private var filteredEntries: [LocalLedgerEntry] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        return store.entries.filter { entry in
            let matchesKind = filter == nil || entry.kind == filter
            let accountName = store.account(id: entry.accountID)?.name ?? ""
            let matchesQuery = query.isEmpty
                || entry.merchant.localizedCaseInsensitiveContains(query)
                || entry.note.localizedCaseInsensitiveContains(query)
                || entry.category.title.localizedCaseInsensitiveContains(query)
                || accountName.localizedCaseInsensitiveContains(query)
                || store.moneyString(entry.amount).contains(query)
            return matchesKind && matchesQuery
        }
    }

    private var groupedEntries: [LocalLedgerDayGroup] {
        let calendar = Calendar.current
        let grouped = Dictionary(grouping: filteredEntries) { calendar.startOfDay(for: $0.date) }
        return grouped.keys.sorted(by: >).map {
            LocalLedgerDayGroup(
                date: $0,
                title: dayTitle($0),
                entries: grouped[$0] ?? []
            )
        }
    }

    private func dayTitle(_ date: Date) -> String {
        if Calendar.current.isDateInToday(date) { return "今天" }
        if Calendar.current.isDateInYesterday(date) { return "昨天" }
        return date.formatted(date: .long, time: .omitted)
    }
}

private struct LocalLedgerBudgetsView: View {
    @ObservedObject var store: LocalLedgerStore
    @State private var showingAdd = false
    @State private var editingBudget: LocalLedgerBudget?

    var body: some View {
        NavigationStack {
            ZStack {
                LocalLedgerBackground()
                Group {
                    if store.budgets.isEmpty {
                        ContentUnavailableView(
                            "暂无月度预算",
                            systemImage: "chart.pie",
                            description: Text("设置总预算或分类预算，掌握本月消费进度。")
                        )
                    } else {
                        ScrollView {
                            LazyVStack(spacing: 14) {
                                ForEach(store.budgets) { budget in
                                    budgetCard(budget)
                                }
                            }
                            .padding(18)
                        }
                        .scrollIndicators(.hidden)
                    }
                }
            }
            .navigationTitle("月度预算")
            .toolbarBackground(.hidden, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showingAdd = true } label: {
                        Image(systemName: "plus")
                            .font(.system(size: 15, weight: .bold))
                            .frame(width: 36, height: 36)
                            .background(XianguangTheme.accentGradient, in: Circle())
                    }
                    .buttonStyle(XianguangPressStyle())
                        .accessibilityLabel("添加预算")
                }
            }
            .sheet(isPresented: $showingAdd) { LocalLedgerBudgetForm(store: store) }
            .sheet(item: $editingBudget) { LocalLedgerBudgetForm(store: store, budget: $0) }
        }
    }

    private func budgetCard(_ budget: LocalLedgerBudget) -> some View {
        let spent = store.spent(for: budget)
        let progress = budget.amount > 0
            ? min(1.5, NSDecimalNumber(decimal: spent / budget.amount).doubleValue)
            : 0
        return Button { editingBudget = budget } label: {
            LocalLedgerCard {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Label(
                            budget.category?.title ?? "本月总预算",
                            systemImage: budget.category?.symbol ?? "sum"
                        )
                        .font(.headline)
                        Spacer()
                        if !budget.isEnabled { Text("已停用").font(.caption).foregroundStyle(.secondary) }
                    }
                    ProgressView(value: min(progress, 1))
                        .tint(progress > 1 ? .red : progress > 0.8 ? .orange : .cyan)
                    HStack {
                        Text("已用 ¥\(store.moneyString(spent))")
                        Spacer()
                        Text("预算 ¥\(store.moneyString(budget.amount))")
                    }
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    if progress > 1 {
                        Label("已超出 ¥\(store.moneyString(spent - budget.amount))", systemImage: "exclamationmark.triangle.fill")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.red)
                    }
                }
            }
        }
        .buttonStyle(.plain)
    }
}

private struct LocalLedgerEntryForm: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: LocalLedgerStore
    private let entry: LocalLedgerEntry?

    @State private var kind: LocalLedgerEntryKind
    @State private var amountText: String
    @State private var category: LocalLedgerCategory
    @State private var accountID: UUID
    @State private var date: Date
    @State private var merchant: String
    @State private var note: String

    init(
        store: LocalLedgerStore,
        entry: LocalLedgerEntry? = nil,
        initialKind: LocalLedgerEntryKind = .expense
    ) {
        self.store = store
        self.entry = entry
        let kind = entry?.kind ?? initialKind
        _kind = State(initialValue: kind)
        _amountText = State(initialValue: entry.map { NSDecimalNumber(decimal: $0.amount).stringValue } ?? "")
        _category = State(initialValue: entry?.category ?? LocalLedgerCategory.available(for: kind).first ?? .other)
        _accountID = State(initialValue: entry?.accountID ?? store.accounts.first?.id ?? UUID())
        _date = State(initialValue: entry?.date ?? .now)
        _merchant = State(initialValue: entry?.merchant ?? "")
        _note = State(initialValue: entry?.note ?? "")
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("类型", selection: $kind) {
                        ForEach(LocalLedgerEntryKind.allCases) { Text($0.title).tag($0) }
                    }
                    .pickerStyle(.segmented)

                    HStack(alignment: .firstTextBaseline) {
                        Text("¥").font(.title2.bold())
                        TextField("0.00", text: $amountText)
                            .keyboardType(.decimalPad)
                            .font(.system(size: 34, weight: .bold, design: .rounded))
                            .monospacedDigit()
                    }
                }

                Section("分类与账户") {
                    Picker("分类", selection: $category) {
                        ForEach(LocalLedgerCategory.available(for: kind)) {
                            Label($0.title, systemImage: $0.symbol).tag($0)
                        }
                    }
                    Picker("账户", selection: $accountID) {
                        ForEach(store.accounts) { Label($0.name, systemImage: $0.kind.symbol).tag($0.id) }
                    }
                    DatePicker("日期", selection: $date, displayedComponents: [.date, .hourAndMinute])
                }

                Section("补充信息") {
                    TextField("商家或来源（可选）", text: $merchant)
                    TextField("备注（可选）", text: $note, axis: .vertical).lineLimit(2...5)
                }
            }
            .navigationTitle(entry == nil ? "记一笔" : "编辑账目")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存", action: save).disabled(parsedAmount == nil)
                }
            }
            .onChange(of: kind) { _, newKind in
                if !LocalLedgerCategory.available(for: newKind).contains(category) {
                    category = LocalLedgerCategory.available(for: newKind).first ?? .other
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private var parsedAmount: Decimal? {
        guard let value = Decimal(string: amountText.replacingOccurrences(of: ",", with: "."), locale: Locale(identifier: "en_US_POSIX")), value > 0 else { return nil }
        return value
    }

    private func save() {
        guard let amount = parsedAmount else { return }
        if let entry {
            store.updateEntry(
                id: entry.id, kind: kind, amount: amount, category: category,
                accountID: accountID, date: date, merchant: merchant, note: note
            )
        } else {
            store.addEntry(
                kind: kind, amount: amount, category: category,
                accountID: accountID, date: date, merchant: merchant, note: note
            )
        }
        dismiss()
    }
}

private struct LocalLedgerBudgetForm: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: LocalLedgerStore
    private let budget: LocalLedgerBudget?
    @State private var category: LocalLedgerCategory?
    @State private var amountText: String
    @State private var isEnabled: Bool

    init(store: LocalLedgerStore, budget: LocalLedgerBudget? = nil) {
        self.store = store
        self.budget = budget
        _category = State(initialValue: budget?.category)
        _amountText = State(initialValue: budget.map { NSDecimalNumber(decimal: $0.amount).stringValue } ?? "")
        _isEnabled = State(initialValue: budget?.isEnabled ?? true)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("预算范围") {
                    Picker("范围", selection: $category) {
                        Text("本月总支出").tag(nil as LocalLedgerCategory?)
                        ForEach(LocalLedgerCategory.allCases.filter(\.supportsExpense)) {
                            Label($0.title, systemImage: $0.symbol).tag($0 as LocalLedgerCategory?)
                        }
                    }
                    Toggle("启用预算", isOn: $isEnabled)
                }
                Section("每月额度") {
                    HStack {
                        Text("¥")
                        TextField("0.00", text: $amountText).keyboardType(.decimalPad).monospacedDigit()
                    }
                }
                if let budget {
                    Section {
                        Button("删除预算", role: .destructive) {
                            store.deleteBudget(id: budget.id)
                            dismiss()
                        }
                    }
                }
            }
            .navigationTitle(budget == nil ? "添加预算" : "编辑预算")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        guard let amount = parsedAmount else { return }
                        store.saveBudget(id: budget?.id, category: category, amount: amount, isEnabled: isEnabled)
                        dismiss()
                    }
                    .disabled(parsedAmount == nil)
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private var parsedAmount: Decimal? {
        guard let value = Decimal(string: amountText.replacingOccurrences(of: ",", with: "."), locale: Locale(identifier: "en_US_POSIX")), value > 0 else { return nil }
        return value
    }
}

private struct LocalLedgerAccountsView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: LocalLedgerStore
    @State private var showingAdd = false
    @State private var editingAccount: LocalLedgerAccount?
    @State private var deletionMessage: String?

    var body: some View {
        NavigationStack {
            List {
                ForEach(store.accounts) { account in
                    Button { editingAccount = account } label: {
                        HStack(spacing: 12) {
                            Image(systemName: account.kind.symbol)
                                .frame(width: 34, height: 34)
                                .background(Color.cyan.opacity(0.16), in: Circle())
                            VStack(alignment: .leading) {
                                Text(account.name).foregroundStyle(.primary)
                                Text(account.kind.title).font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Text("¥\(store.moneyString(store.balance(for: account.id)))")
                                .monospacedDigit().fontWeight(.semibold).foregroundStyle(.primary)
                        }
                    }
                    .buttonStyle(.plain)
                    .swipeActions {
                        Button(role: .destructive) {
                            if !store.deleteAccount(id: account.id) {
                                deletionMessage = "至少保留一个账户；已有账目的账户需要先删除相关账目。"
                            }
                        } label: { Label("删除", systemImage: "trash") }
                    }
                }
            }
            .navigationTitle("账户管理")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("完成") { dismiss() } }
                ToolbarItem(placement: .primaryAction) { Button { showingAdd = true } label: { Image(systemName: "plus") } }
            }
            .sheet(isPresented: $showingAdd) { LocalLedgerAccountForm(store: store) }
            .sheet(item: $editingAccount) { LocalLedgerAccountForm(store: store, account: $0) }
            .alert("无法删除账户", isPresented: Binding(
                get: { deletionMessage != nil },
                set: { if !$0 { deletionMessage = nil } }
            )) { Button("知道了") { deletionMessage = nil } } message: { Text(deletionMessage ?? "") }
        }
        .preferredColorScheme(.dark)
    }
}

private struct LocalLedgerAccountForm: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: LocalLedgerStore
    private let account: LocalLedgerAccount?
    @State private var name: String
    @State private var kind: LocalLedgerAccountKind
    @State private var openingBalance: String

    init(store: LocalLedgerStore, account: LocalLedgerAccount? = nil) {
        self.store = store
        self.account = account
        _name = State(initialValue: account?.name ?? "")
        _kind = State(initialValue: account?.kind ?? .cash)
        _openingBalance = State(initialValue: account.map { NSDecimalNumber(decimal: $0.openingBalance).stringValue } ?? "0")
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("账户信息") {
                    TextField("账户名称", text: $name)
                    Picker("账户类型", selection: $kind) {
                        ForEach(LocalLedgerAccountKind.allCases) { Label($0.title, systemImage: $0.symbol).tag($0) }
                    }
                    HStack {
                        Text("初始余额 ¥")
                        TextField("0.00", text: $openingBalance).keyboardType(.decimalPad).monospacedDigit()
                    }
                }
            }
            .navigationTitle(account == nil ? "添加账户" : "编辑账户")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存", action: save).disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private func save() {
        let amount = Decimal(string: openingBalance.replacingOccurrences(of: ",", with: "."), locale: Locale(identifier: "en_US_POSIX")) ?? 0
        if let account { store.updateAccount(id: account.id, name: name, kind: kind, openingBalance: amount) }
        else { store.addAccount(name: name, kind: kind, openingBalance: amount) }
        dismiss()
    }
}

private struct LocalLedgerSettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: LocalLedgerStore
    @State private var confirmingClear = false

    var body: some View {
        NavigationStack {
            Form {
                Section("本地运行") {
                    Label("账目、账户和预算仅保存在当前设备", systemImage: "iphone")
                    Label("记账功能不联网、不使用 iCloud", systemImage: "network.slash")
                    Label("不会申请通知、相册、定位、日历或健康权限", systemImage: "hand.raised.slash")
                }
                Section("数据") {
                    LabeledContent("账目", value: "\(store.entries.count) 笔")
                    LabeledContent("账户", value: "\(store.accounts.count) 个")
                    LabeledContent("预算", value: "\(store.budgets.count) 项")
                    Button("清空本地账本", role: .destructive) { confirmingClear = true }
                }
                Section("隐私说明") {
                    Text("记账数据使用 Codable 编码后存入 APP 沙盒的 UserDefaults。数据不会上传或与其他设备同步。删除 APP 会移除仍保存在 APP 沙盒内的账本数据。")
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("本地账本设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() } } }
            .confirmationDialog("清空全部本地账本？", isPresented: $confirmingClear, titleVisibility: .visible) {
                Button("永久清空", role: .destructive) { store.clearAllData() }
                Button("取消", role: .cancel) {}
            } message: {
                Text("将删除全部账目、账户和预算，并重新建立一个空的日常钱包。此操作无法撤销。")
            }
        }
        .preferredColorScheme(.dark)
    }
}

private struct LocalLedgerEntryRow: View {
    let entry: LocalLedgerEntry
    @ObservedObject var store: LocalLedgerStore

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: entry.category.symbol)
                .foregroundStyle(categoryColor(entry.category))
                .frame(width: 38, height: 38)
                .background(categoryColor(entry.category).opacity(0.14), in: Circle())
            VStack(alignment: .leading, spacing: 4) {
                Text(entry.merchant.isEmpty ? entry.category.title : entry.merchant)
                    .font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                HStack(spacing: 5) {
                    Text(entry.category.title)
                    if let name = store.account(id: entry.accountID)?.name { Text("· \(name)") }
                    Text("· \(entry.date.formatted(date: .omitted, time: .shortened))")
                }
                .font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 8)
            Text("\(entry.kind == .income ? "+" : "−")¥\(store.moneyString(entry.amount))")
                .font(.subheadline.weight(.bold)).monospacedDigit()
                .foregroundStyle(entry.kind == .income ? Color.green : Color.orange)
        }
        .contentShape(Rectangle())
    }
}

private struct LocalLedgerDayGroup: Identifiable {
    let date: Date
    let title: String
    let entries: [LocalLedgerEntry]
    var id: Date { date }
}

private struct LocalLedgerCard<Content: View>: View {
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @ViewBuilder let content: Content

    var body: some View {
        content
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(18)
            .background(
                reduceTransparency ? XianguangTheme.surface : XianguangTheme.surface.opacity(0.7),
                in: RoundedRectangle(cornerRadius: 24, style: .continuous)
            )
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .stroke(
                        LinearGradient(
                            colors: [Color.white.opacity(0.14), Color.white.opacity(0.035)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 1
                    )
            }
            .shadow(color: Color.black.opacity(0.15), radius: 18, y: 9)
    }
}

private struct LocalLedgerBackground: View {
    var body: some View {
        ZStack {
            XianguangTheme.backgroundGradient
            Circle()
                .fill(XianguangTheme.cyan.opacity(0.12))
                .frame(width: 250, height: 250)
                .blur(radius: 80)
                .offset(x: -160, y: -330)
            Circle()
                .fill(XianguangTheme.violet.opacity(0.13))
                .frame(width: 300, height: 300)
                .blur(radius: 100)
                .offset(x: 180, y: 170)
        }
        .ignoresSafeArea()
    }
}

private enum XianguangTheme {
    static let cyan = Color(red: 0.20, green: 0.82, blue: 1.0)
    static let violet = Color(red: 0.52, green: 0.38, blue: 1.0)
    static let surface = Color(red: 0.075, green: 0.085, blue: 0.14)
    static let accentGradient = LinearGradient(
        colors: [cyan, Color(red: 0.35, green: 0.57, blue: 1), violet],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    static let heroGradient = LinearGradient(
        colors: [
            Color(red: 0.05, green: 0.25, blue: 0.38),
            Color(red: 0.14, green: 0.13, blue: 0.34),
            Color(red: 0.24, green: 0.11, blue: 0.34)
        ],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    static let backgroundGradient = LinearGradient(
        colors: [
            Color(red: 0.018, green: 0.035, blue: 0.075),
            Color(red: 0.04, green: 0.035, blue: 0.095),
            Color(red: 0.012, green: 0.012, blue: 0.026)
        ],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
}

private struct XianguangPressStyle: ButtonStyle {
    var scale: CGFloat = 0.97

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? scale : 1)
            .opacity(configuration.isPressed ? 0.82 : 1)
            .animation(.easeOut(duration: 0.1), value: configuration.isPressed)
    }
}

private struct XianguangMark: View {
    var showBackground = true

    var body: some View {
        ZStack {
            if showBackground {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(XianguangTheme.surface)
                    .overlay {
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .stroke(Color.white.opacity(0.12), lineWidth: 1)
                    }
            }
            XianguangArc()
                .stroke(XianguangTheme.accentGradient, style: StrokeStyle(lineWidth: 3.2, lineCap: .round))
                .padding(showBackground ? 10 : 4)
            XianguangArc()
                .stroke(XianguangTheme.accentGradient, style: StrokeStyle(lineWidth: 3.2, lineCap: .round))
                .scaleEffect(x: -1, y: 1)
                .padding(showBackground ? 10 : 4)
            Circle()
                .fill(.white)
                .frame(width: showBackground ? 4.5 : 8, height: showBackground ? 4.5 : 8)
                .shadow(color: .white, radius: 5)
        }
    }
}

private struct XianguangArc: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.minX, y: rect.minY + rect.height * 0.18))
        path.addCurve(
            to: CGPoint(x: rect.maxX, y: rect.maxY - rect.height * 0.18),
            control1: CGPoint(x: rect.minX + rect.width * 0.46, y: rect.minY + rect.height * 0.28),
            control2: CGPoint(x: rect.minX + rect.width * 0.54, y: rect.maxY - rect.height * 0.28)
        )
        return path
    }
}

private func categoryColor(_ category: LocalLedgerCategory) -> Color {
    switch category {
    case .dining: .orange
    case .shopping: .pink
    case .transport: .blue
    case .housing: .indigo
    case .entertainment: .purple
    case .health: .red
    case .education: .cyan
    case .travel: .teal
    case .salary: .green
    case .bonus: .mint
    case .investment: .green
    case .other: .gray
    }
}

private func ratio(_ lhs: Decimal, _ rhs: Decimal) -> Double {
    guard rhs != 0 else { return 0 }
    return min(1, max(0, NSDecimalNumber(decimal: lhs / rhs).doubleValue))
}
