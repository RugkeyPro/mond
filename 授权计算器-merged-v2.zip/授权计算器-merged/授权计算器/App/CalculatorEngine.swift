import Foundation

enum CalculatorOperation: Equatable {
    case add
    case subtract
    case multiply
    case divide
}

enum CalculatorAngleMode: String, CaseIterable, Identifiable {
    case degrees
    case radians

    var id: String { rawValue }
    var title: String { self == .degrees ? "角度" : "弧度" }
}

enum CalculatorRoundingMode: String, CaseIterable, Identifiable {
    case plain
    case bankers
    case down
    case up

    var id: String { rawValue }

    var title: String {
        switch self {
        case .plain: "四舍五入"
        case .bankers: "银行家舍入"
        case .down: "向零舍入"
        case .up: "远离零舍入"
        }
    }

    var decimalMode: Decimal.RoundingMode {
        switch self {
        case .plain: .plain
        case .bankers: .bankers
        case .down: .down
        case .up: .up
        }
    }
}

enum ScientificFunction: String, CaseIterable, Identifiable {
    case square, cube, squareRoot, cubeRoot, reciprocal, absolute, factorial
    case sine, cosine, tangent, arcSine, arcCosine, arcTangent
    case naturalLog, commonLog, exponential

    var id: String { rawValue }

    var title: String {
        switch self {
        case .square: "x²"
        case .cube: "x³"
        case .squareRoot: "√x"
        case .cubeRoot: "∛x"
        case .reciprocal: "1/x"
        case .absolute: "|x|"
        case .factorial: "x!"
        case .sine: "sin"
        case .cosine: "cos"
        case .tangent: "tan"
        case .arcSine: "sin⁻¹"
        case .arcCosine: "cos⁻¹"
        case .arcTangent: "tan⁻¹"
        case .naturalLog: "ln"
        case .commonLog: "log"
        case .exponential: "eˣ"
        }
    }
}

struct CalculationHistoryEntry: Identifiable, Codable, Equatable {
    let id: UUID
    let expression: String
    let result: String
    let createdAt: Date
    var isFavorite: Bool
    var note: String
    var updatedAt: Date

    init(expression: String, result: String) {
        id = UUID()
        self.expression = expression
        self.result = result
        createdAt = Date()
        isFavorite = false
        note = ""
        updatedAt = createdAt
    }

    private enum CodingKeys: String, CodingKey {
        case id, expression, result, createdAt, isFavorite, note, updatedAt
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(UUID.self, forKey: .id)
        expression = try container.decode(String.self, forKey: .expression)
        result = try container.decode(String.self, forKey: .result)
        createdAt = try container.decode(Date.self, forKey: .createdAt)
        isFavorite = try container.decodeIfPresent(Bool.self, forKey: .isFavorite) ?? false
        note = try container.decodeIfPresent(String.self, forKey: .note) ?? ""
        updatedAt = try container.decodeIfPresent(Date.self, forKey: .updatedAt) ?? createdAt
    }
}

struct CalculatorExpressionPreview: Equatable {
    let result: String?
    let error: String?
    let errorPosition: Int?
}

struct CalculatorEngine {
    private static let historyEncoder = JSONEncoder()
    private static let historyDecoder = JSONDecoder()
    private static let financialFormatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.locale = .current
        formatter.numberStyle = .decimal
        formatter.minimumFractionDigits = 2
        formatter.maximumFractionDigits = 2
        return formatter
    }()

    private(set) var display = "0"
    private(set) var expression = ""
    private(set) var history: [CalculationHistoryEntry]
    private(set) var lastError: String?
    private(set) var lastErrorPosition: Int?
    private(set) var memoryValue: Decimal?
    private(set) var angleMode: CalculatorAngleMode
    private(set) var usesThousandsSeparators: Bool
    private(set) var fixedDecimalPlaces: Int?
    private(set) var calculationScale: Int
    private(set) var roundingMode: CalculatorRoundingMode

    private var storedValue: Decimal?
    private var pendingOperation: CalculatorOperation?
    private var repeatOperation: CalculatorOperation?
    private var repeatOperand: Decimal?
    private var shouldReplaceDisplay = false
    private var hasEnteredDigit = false
    private var isDirectDigitEntry = false
    private var undoStack: [CalculatorSnapshot] = []
    private var redoStack: [CalculatorSnapshot] = []

    private let historyDefaultsKey = "calculator.history.v1"
    private let memoryDefaultsKey = "calculator.memory.v1"
    private let angleModeDefaultsKey = "calculator.angle-mode.v1"
    private let groupingDefaultsKey = "calculator.grouping.v1"
    private let decimalPlacesDefaultsKey = "calculator.decimal-places.v1"
    private let calculationScaleDefaultsKey = "calculator.calculation-scale.v1"
    private let roundingModeDefaultsKey = "calculator.rounding-mode.v1"
    private let maximumHistoryCount = 100
    private let maximumUndoCount = 80

    init() {
        let defaults = UserDefaults.standard
        if let data = defaults.data(forKey: historyDefaultsKey),
           let savedHistory = try? Self.historyDecoder.decode([CalculationHistoryEntry].self, from: data) {
            history = Array(savedHistory.prefix(maximumHistoryCount))
        } else {
            history = []
        }

        memoryValue = defaults.string(forKey: memoryDefaultsKey).flatMap {
            Decimal(string: $0, locale: Locale(identifier: "en_US_POSIX"))
        }
        angleMode = CalculatorAngleMode(
            rawValue: defaults.string(forKey: angleModeDefaultsKey) ?? ""
        ) ?? .degrees
        usesThousandsSeparators = defaults.object(forKey: groupingDefaultsKey) == nil
            ? true
            : defaults.bool(forKey: groupingDefaultsKey)
        let savedPlaces = defaults.integer(forKey: decimalPlacesDefaultsKey)
        fixedDecimalPlaces = defaults.object(forKey: decimalPlacesDefaultsKey) == nil || savedPlaces < 0
            ? nil
            : savedPlaces
        calculationScale = defaults.object(forKey: calculationScaleDefaultsKey) == nil
            ? 16
            : max(2, min(28, defaults.integer(forKey: calculationScaleDefaultsKey)))
        roundingMode = CalculatorRoundingMode(
            rawValue: defaults.string(forKey: roundingModeDefaultsKey) ?? ""
        ) ?? .plain
    }

    var hasPendingCalculation: Bool {
        pendingOperation != nil || (repeatOperation != nil && repeatOperand != nil && shouldReplaceDisplay)
    }

    var canUndo: Bool { !undoStack.isEmpty }
    var canRedo: Bool { !redoStack.isEmpty }
    var hasMemory: Bool { memoryValue != nil }

    var invitationCodeCandidate: String? {
        guard pendingOperation == nil,
              repeatOperation == nil,
              isDirectDigitEntry,
              display.count == 8,
              display.allSatisfy(\.isNumber) else {
            return nil
        }
        return display
    }

    var expressionForEditing: String {
        if pendingOperation != nil {
            return shouldReplaceDisplay ? expression : "\(expression) \(display)"
        }
        if !expression.isEmpty {
            return expression
        }
        return display == "0" ? "" : display
    }

    var canCopyResult: Bool {
        display != "Error"
    }

    var formattedDisplay: String {
        guard display != "Error", let value = decimal(from: display) else { return display }
        if isDirectDigitEntry { return display }

        let base: String
        if let places = fixedDecimalPlaces {
            base = fixedFormat(value, places: places)
        } else {
            base = display
        }
        guard usesThousandsSeparators else { return base }
        return addThousandsSeparators(to: base)
    }

    mutating func input(_ digit: String) {
        guard display.count < 18 || shouldReplaceDisplay || !hasEnteredDigit else { return }
        checkpoint()
        lastError = nil
        if shouldReplaceDisplay || display == "Error" {
            if pendingOperation == nil {
                expression = ""
                repeatOperation = nil
                repeatOperand = nil
            }
            display = digit
            shouldReplaceDisplay = false
            hasEnteredDigit = true
        } else if !hasEnteredDigit {
            display = digit
            hasEnteredDigit = true
        } else {
            display.append(digit)
        }
        isDirectDigitEntry = pendingOperation == nil && expression.isEmpty
    }

    mutating func decimalPoint() {
        guard !display.contains(".") || shouldReplaceDisplay || display == "Error" else { return }
        checkpoint()
        lastError = nil
        if shouldReplaceDisplay || display == "Error" {
            if pendingOperation == nil {
                expression = ""
                repeatOperation = nil
                repeatOperand = nil
            }
            display = "0."
            shouldReplaceDisplay = false
            hasEnteredDigit = true
        } else {
            display.append(".")
            hasEnteredDigit = true
        }
        isDirectDigitEntry = false
    }

    mutating func choose(_ operation: CalculatorOperation) {
        guard let current = decimal(from: display) else { return }
        checkpoint()
        lastError = nil
        isDirectDigitEntry = false
        repeatOperation = nil
        repeatOperand = nil

        if shouldReplaceDisplay, storedValue != nil {
            pendingOperation = operation
            expression = "\(display) \(symbol(for: operation))"
            return
        }

        if let storedValue, let pendingOperation {
            guard let result = calculate(storedValue, current, pendingOperation) else {
                setCalculationError("不能除以 0")
                return
            }
            display = format(result)
            self.storedValue = result
        } else {
            storedValue = current
        }

        pendingOperation = operation
        expression = "\(display) \(symbol(for: operation))"
        shouldReplaceDisplay = true
    }

    mutating func equals() {
        lastError = nil

        if let storedValue, let pendingOperation, let current = decimal(from: display) {
            checkpoint()
            completeCalculation(lhs: storedValue, rhs: current, operation: pendingOperation)
            repeatOperation = pendingOperation
            repeatOperand = current
            self.storedValue = nil
            self.pendingOperation = nil
            return
        }

        guard let operation = repeatOperation,
              let operand = repeatOperand,
              let current = decimal(from: display),
              shouldReplaceDisplay else { return }
        checkpoint()
        completeCalculation(lhs: current, rhs: operand, operation: operation)
    }

    @discardableResult
    mutating func evaluateExpression(_ rawExpression: String) -> Bool {
        let trimmed = rawExpression.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            lastError = "请输入表达式"
            lastErrorPosition = nil
            return false
        }
        guard trimmed.count <= 200 else {
            lastError = "表达式过长"
            lastErrorPosition = 200
            return false
        }

        do {
            let value = try expressionValue(trimmed)

            checkpoint()
            let normalizedExpression = normalizeSymbols(in: trimmed)
            display = format(value)
            expression = normalizedExpression
            storedValue = nil
            pendingOperation = nil
            repeatOperation = nil
            repeatOperand = nil
            shouldReplaceDisplay = true
            hasEnteredDigit = true
            isDirectDigitEntry = false
            lastError = nil
            lastErrorPosition = nil
            addHistory(expression: normalizedExpression, result: display)
            return true
        } catch let error as ExpressionParser.ParserError {
            lastError = message(for: error)
            lastErrorPosition = error.position
        } catch {
            lastError = "表达式格式不正确"
            lastErrorPosition = nil
        }
        return false
    }

    func previewExpression(_ rawExpression: String) -> CalculatorExpressionPreview {
        let trimmed = rawExpression.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            return CalculatorExpressionPreview(result: nil, error: nil, errorPosition: nil)
        }
        guard trimmed.count <= 200 else {
            return CalculatorExpressionPreview(result: nil, error: "表达式过长", errorPosition: 200)
        }
        do {
            return CalculatorExpressionPreview(
                result: format(try expressionValue(trimmed)),
                error: nil,
                errorPosition: nil
            )
        } catch let error as ExpressionParser.ParserError {
            return CalculatorExpressionPreview(result: nil, error: message(for: error), errorPosition: error.position)
        } catch {
            return CalculatorExpressionPreview(result: nil, error: "表达式格式不正确", errorPosition: nil)
        }
    }

    mutating func backspace() {
        if display == "Error" {
            checkpoint()
            resetCalculation()
            return
        }

        if shouldReplaceDisplay, pendingOperation != nil { return }
        guard hasEnteredDigit || shouldReplaceDisplay else { return }
        checkpoint()
        lastError = nil
        lastErrorPosition = nil

        if shouldReplaceDisplay {
            expression = ""
            repeatOperation = nil
            repeatOperand = nil
            shouldReplaceDisplay = false
        }

        if display.count <= 1 || (display.hasPrefix("-") && display.count == 2) {
            display = "0"
            hasEnteredDigit = false
        } else {
            display.removeLast()
        }
        isDirectDigitEntry = pendingOperation == nil && expression.isEmpty && !display.contains(".")
    }

    mutating func clear() {
        guard display != "0" || !expression.isEmpty || lastError != nil else { return }
        checkpoint()
        resetCalculation()
    }

    mutating func toggleSign() {
        guard let value = decimal(from: display), value != 0 else { return }
        checkpoint()
        lastError = nil
        lastErrorPosition = nil
        display = format(-value)
        isDirectDigitEntry = false
    }

    mutating func percent() {
        guard let value = decimal(from: display) else { return }
        checkpoint()
        lastError = nil
        lastErrorPosition = nil
        if let storedValue, pendingOperation == .add || pendingOperation == .subtract {
            display = format(storedValue * value / 100)
        } else {
            display = format(value / 100)
        }
        shouldReplaceDisplay = false
        hasEnteredDigit = true
        isDirectDigitEntry = false
    }

    mutating func undo() {
        guard let snapshot = undoStack.popLast() else { return }
        redoStack.append(currentSnapshot)
        restoreSnapshot(snapshot)
    }

    mutating func redo() {
        guard let snapshot = redoStack.popLast() else { return }
        undoStack.append(currentSnapshot)
        restoreSnapshot(snapshot)
    }

    mutating func memoryStore() {
        guard let value = decimal(from: display) else { return }
        memoryValue = value
        persistMemory()
    }

    mutating func memoryAdd() {
        guard let value = decimal(from: display) else { return }
        memoryValue = (memoryValue ?? 0) + value
        persistMemory()
    }

    mutating func memorySubtract() {
        guard let value = decimal(from: display) else { return }
        memoryValue = (memoryValue ?? 0) - value
        persistMemory()
    }

    mutating func memoryRecall() {
        guard let memoryValue else { return }
        checkpoint()
        display = format(memoryValue)
        expression = "M"
        storedValue = nil
        pendingOperation = nil
        repeatOperation = nil
        repeatOperand = nil
        shouldReplaceDisplay = true
        hasEnteredDigit = true
        isDirectDigitEntry = false
        lastError = nil
        lastErrorPosition = nil
    }

    mutating func memoryClear() {
        memoryValue = nil
        UserDefaults.standard.removeObject(forKey: memoryDefaultsKey)
    }

    mutating func applyScientific(_ function: ScientificFunction) {
        guard let decimalValue = decimal(from: display) else { return }
        let value = NSDecimalNumber(decimal: decimalValue).doubleValue
        let result: Double?
        let calculationExpression: String

        switch function {
        case .square:
            result = value * value
            calculationExpression = "(\(format(decimalValue)))²"
        case .cube:
            result = value * value * value
            calculationExpression = "(\(format(decimalValue)))³"
        case .squareRoot:
            result = value >= 0 ? sqrt(value) : nil
            calculationExpression = "√(\(format(decimalValue)))"
        case .cubeRoot:
            result = cbrt(value)
            calculationExpression = "∛(\(format(decimalValue)))"
        case .reciprocal:
            result = value == 0 ? nil : 1 / value
            calculationExpression = "1 ÷ \(format(decimalValue))"
        case .absolute:
            result = abs(value)
            calculationExpression = "|\(format(decimalValue))|"
        case .factorial:
            result = Self.factorial(value)
            calculationExpression = "\(format(decimalValue))!"
        case .sine:
            result = sin(angleInput(value))
            calculationExpression = "sin(\(format(decimalValue)))"
        case .cosine:
            result = cos(angleInput(value))
            calculationExpression = "cos(\(format(decimalValue)))"
        case .tangent:
            result = tan(angleInput(value))
            calculationExpression = "tan(\(format(decimalValue)))"
        case .arcSine:
            result = (-1...1).contains(value) ? angleOutput(asin(value)) : nil
            calculationExpression = "sin⁻¹(\(format(decimalValue)))"
        case .arcCosine:
            result = (-1...1).contains(value) ? angleOutput(acos(value)) : nil
            calculationExpression = "cos⁻¹(\(format(decimalValue)))"
        case .arcTangent:
            result = angleOutput(atan(value))
            calculationExpression = "tan⁻¹(\(format(decimalValue)))"
        case .naturalLog:
            result = value > 0 ? log(value) : nil
            calculationExpression = "ln(\(format(decimalValue)))"
        case .commonLog:
            result = value > 0 ? log10(value) : nil
            calculationExpression = "log(\(format(decimalValue)))"
        case .exponential:
            result = exp(value)
            calculationExpression = "e^(\(format(decimalValue)))"
        }

        guard let result, result.isFinite else {
            lastError = function == .reciprocal ? "不能除以 0" : "函数输入超出定义域"
            return
        }
        checkpoint()
        setStandaloneResult(normalized(Decimal(result)), expression: calculationExpression, addToHistory: true)
    }

    mutating func applyPower(exponent: Double) {
        guard let decimalValue = decimal(from: display) else { return }
        let value = NSDecimalNumber(decimal: decimalValue).doubleValue
        let result = pow(value, exponent)
        guard result.isFinite else {
            lastError = "幂运算结果无效"
            return
        }
        checkpoint()
        setStandaloneResult(
            normalized(Decimal(result)),
            expression: "\(format(decimalValue)) ^ \(String(format: "%.12g", exponent))",
            addToHistory: true
        )
    }

    mutating func insertConstant(_ value: Double, name: String) {
        checkpoint()
        setStandaloneResult(normalized(Decimal(value)), expression: name, addToHistory: false)
    }

    mutating func generateRandomNumber() {
        checkpoint()
        setStandaloneResult(
            normalized(Decimal(Double.random(in: 0..<1))),
            expression: "随机数 [0, 1)",
            addToHistory: true
        )
    }

    mutating func setAngleMode(_ mode: CalculatorAngleMode) {
        angleMode = mode
        UserDefaults.standard.set(mode.rawValue, forKey: angleModeDefaultsKey)
    }

    mutating func setUsesThousandsSeparators(_ enabled: Bool) {
        usesThousandsSeparators = enabled
        UserDefaults.standard.set(enabled, forKey: groupingDefaultsKey)
    }

    mutating func setFixedDecimalPlaces(_ places: Int?) {
        fixedDecimalPlaces = places
        UserDefaults.standard.set(places ?? -1, forKey: decimalPlacesDefaultsKey)
    }

    mutating func setCalculationScale(_ scale: Int) {
        calculationScale = max(2, min(28, scale))
        UserDefaults.standard.set(calculationScale, forKey: calculationScaleDefaultsKey)
        if let value = decimal(from: display) {
            display = format(value)
        }
    }

    mutating func setRoundingMode(_ mode: CalculatorRoundingMode) {
        roundingMode = mode
        UserDefaults.standard.set(mode.rawValue, forKey: roundingModeDefaultsKey)
        if let value = decimal(from: display) {
            display = format(value)
        }
    }

    mutating func restore(_ entry: CalculationHistoryEntry) {
        guard let value = decimal(from: entry.result) else { return }
        checkpoint()
        setStandaloneResult(value, expression: entry.expression, addToHistory: false)
    }

    mutating func toggleFavorite(id: UUID) {
        guard let index = history.firstIndex(where: { $0.id == id }) else { return }
        history[index].isFavorite.toggle()
        history[index].updatedAt = Date()
        persistHistory()
    }

    mutating func updateNote(id: UUID, note: String) {
        guard let index = history.firstIndex(where: { $0.id == id }) else { return }
        history[index].note = note.trimmingCharacters(in: .whitespacesAndNewlines)
        history[index].updatedAt = Date()
        persistHistory()
    }

    mutating func deleteHistory(id: UUID) {
        history.removeAll { $0.id == id }
        persistHistory()
    }

    mutating func deleteHistory(ids: Set<UUID>) {
        history.removeAll { ids.contains($0.id) }
        persistHistory()
    }

    mutating func clearHistory() {
        history.removeAll()
        persistHistory()
    }

    func historyCSV() -> String {
        var rows = ["日期,表达式,结果,收藏,备注"]
        let formatter = ISO8601DateFormatter()
        for entry in history {
            rows.append([
                formatter.string(from: entry.createdAt),
                entry.expression,
                entry.result,
                entry.isFavorite ? "是" : "否",
                entry.note
            ].map(csvEscaped).joined(separator: ","))
        }
        return rows.joined(separator: "\n")
    }

    private mutating func completeCalculation(lhs: Decimal, rhs: Decimal, operation: CalculatorOperation) {
        let completedExpression = "\(format(lhs)) \(symbol(for: operation)) \(format(rhs))"
        guard let result = calculate(lhs, rhs, operation) else {
            expression = completedExpression
            setCalculationError("不能除以 0")
            return
        }
        setStandaloneResult(result, expression: completedExpression, addToHistory: true)
    }

    private mutating func setStandaloneResult(
        _ value: Decimal,
        expression: String,
        addToHistory: Bool
    ) {
        display = format(value)
        self.expression = expression
        storedValue = nil
        pendingOperation = nil
        shouldReplaceDisplay = true
        hasEnteredDigit = true
        isDirectDigitEntry = false
        lastError = nil
        lastErrorPosition = nil
        if addToHistory {
            addHistory(expression: expression, result: display)
        }
    }

    private mutating func resetCalculation() {
        display = "0"
        expression = ""
        storedValue = nil
        pendingOperation = nil
        repeatOperation = nil
        repeatOperand = nil
        shouldReplaceDisplay = false
        hasEnteredDigit = false
        isDirectDigitEntry = false
        lastError = nil
    }

    private mutating func setCalculationError(_ message: String) {
        display = "Error"
        storedValue = nil
        pendingOperation = nil
        repeatOperation = nil
        repeatOperand = nil
        shouldReplaceDisplay = true
        hasEnteredDigit = false
        isDirectDigitEntry = false
        lastError = message
    }

    private mutating func checkpoint() {
        let snapshot = currentSnapshot
        if undoStack.last != snapshot {
            undoStack.append(snapshot)
            if undoStack.count > maximumUndoCount {
                undoStack.removeFirst(undoStack.count - maximumUndoCount)
            }
        }
        redoStack.removeAll()
    }

    private var currentSnapshot: CalculatorSnapshot {
        CalculatorSnapshot(
            display: display,
            expression: expression,
            storedValue: storedValue,
            pendingOperation: pendingOperation,
            repeatOperation: repeatOperation,
            repeatOperand: repeatOperand,
            shouldReplaceDisplay: shouldReplaceDisplay,
            hasEnteredDigit: hasEnteredDigit,
            isDirectDigitEntry: isDirectDigitEntry,
            lastError: lastError
        )
    }

    private mutating func restoreSnapshot(_ snapshot: CalculatorSnapshot) {
        display = snapshot.display
        expression = snapshot.expression
        storedValue = snapshot.storedValue
        pendingOperation = snapshot.pendingOperation
        repeatOperation = snapshot.repeatOperation
        repeatOperand = snapshot.repeatOperand
        shouldReplaceDisplay = snapshot.shouldReplaceDisplay
        hasEnteredDigit = snapshot.hasEnteredDigit
        isDirectDigitEntry = snapshot.isDirectDigitEntry
        lastError = snapshot.lastError
        lastErrorPosition = nil
    }

    private mutating func addHistory(expression: String, result: String) {
        if history.first?.expression == expression, history.first?.result == result {
            return
        }
        history.insert(CalculationHistoryEntry(expression: expression, result: result), at: 0)
        if history.count > maximumHistoryCount {
            history.removeLast(history.count - maximumHistoryCount)
        }
        persistHistory()
    }

    private func persistHistory() {
        guard let data = try? Self.historyEncoder.encode(history) else { return }
        UserDefaults.standard.set(data, forKey: historyDefaultsKey)
    }

    private func persistMemory() {
        if let memoryValue {
            UserDefaults.standard.set(format(memoryValue), forKey: memoryDefaultsKey)
        }
    }

    private func calculate(_ lhs: Decimal, _ rhs: Decimal, _ operation: CalculatorOperation) -> Decimal? {
        let result: Decimal
        switch operation {
        case .add: result = lhs + rhs
        case .subtract: result = lhs - rhs
        case .multiply: result = lhs * rhs
        case .divide:
            guard rhs != 0 else { return nil }
            result = lhs / rhs
        }
        return normalized(result)
    }

    private func expressionValue(_ expression: String) throws -> Decimal {
        try ExpressionParser(
            expression,
            angleMode: angleMode,
            scale: calculationScale,
            roundingMode: roundingMode.decimalMode
        ).parse()
    }

    private func message(for error: ExpressionParser.ParserError) -> String {
        switch error {
        case .invalidExpression: "表达式格式不正确"
        case .divisionByZero: "不能除以 0"
        case .domainError: "函数输入超出定义域"
        }
    }

    private func decimal(from value: String) -> Decimal? {
        Decimal(string: value, locale: Locale(identifier: "en_US_POSIX"))
    }

    private func normalized(_ value: Decimal) -> Decimal {
        var source = value
        var result = Decimal()
        NSDecimalRound(&result, &source, calculationScale, roundingMode.decimalMode)
        return result
    }

    private func format(_ value: Decimal) -> String {
        let rounded = normalized(value)
        let result = NSDecimalNumber(decimal: rounded).stringValue
        return result == "-0" ? "0" : result
    }

    private func fixedFormat(_ value: Decimal, places: Int) -> String {
        var source = value
        var rounded = Decimal()
        NSDecimalRound(&rounded, &source, places, roundingMode.decimalMode)
        let number = NSDecimalNumber(decimal: rounded)
        let raw = number.stringValue == "-0" ? "0" : number.stringValue
        guard !raw.lowercased().contains("e") else {
            let formatter = NumberFormatter()
            formatter.locale = Locale(identifier: "en_US_POSIX")
            formatter.numberStyle = .decimal
            formatter.usesGroupingSeparator = false
            formatter.minimumFractionDigits = places
            formatter.maximumFractionDigits = places
            formatter.minimumIntegerDigits = 1
            return formatter.string(from: number) ?? raw
        }
        guard places > 0 else { return raw.split(separator: ".", maxSplits: 1).first.map(String.init) ?? raw }
        let parts = raw.split(separator: ".", maxSplits: 1, omittingEmptySubsequences: false)
        let integer = parts.first.map(String.init) ?? "0"
        let fraction = parts.count > 1 ? String(parts[1]) : ""
        return integer + "." + fraction.padding(toLength: places, withPad: "0", startingAt: 0)
    }

    func string(for value: Decimal) -> String {
        format(value)
    }

    func decimalValue(from value: String) -> Decimal? {
        decimal(from: value)
    }

    func roundedFinancial(_ value: Decimal) -> Decimal {
        var source = value
        var result = Decimal()
        NSDecimalRound(&result, &source, 2, .bankers)
        return result
    }

    func financialString(_ value: Decimal) -> String {
        let number = NSDecimalNumber(decimal: roundedFinancial(value))
        return Self.financialFormatter.string(from: number) ?? number.stringValue
    }

    private func double(from value: Decimal) -> Double {
        NSDecimalNumber(decimal: value).doubleValue
    }

    private func isFinite(_ value: Decimal) -> Bool {
        let number = NSDecimalNumber(decimal: value)
        return number != .notANumber
    }

    private func exactInteger(_ value: Decimal) -> Int? {
        let number = NSDecimalNumber(decimal: value)
        let intValue = number.intValue
        if Decimal(intValue) == value {
            return intValue
        }
        return nil
    }

    private func symbol(for operation: CalculatorOperation) -> String {
        switch operation {
        case .add: "+"
        case .subtract: "−"
        case .multiply: "×"
        case .divide: "÷"
        }
    }

    private func normalizeSymbols(in value: String) -> String {
        value
            .replacingOccurrences(of: "*", with: "×")
            .replacingOccurrences(of: "/", with: "÷")
            .replacingOccurrences(of: "-", with: "−")
    }

    private func addThousandsSeparators(to value: String) -> String {
        guard !value.lowercased().contains("e") else { return value }
        let sign = value.hasPrefix("-") ? "-" : ""
        let unsigned = sign.isEmpty ? value : String(value.dropFirst())
        let parts = unsigned.split(separator: ".", maxSplits: 1, omittingEmptySubsequences: false)
        let integer = String(parts[0])
        let reversed = Array(integer.reversed())
        var grouped = ""
        for (index, character) in reversed.enumerated() {
            if index > 0, index % 3 == 0 { grouped.append(",") }
            grouped.append(character)
        }
        let integerResult = String(grouped.reversed())
        if parts.count == 2 {
            return "\(sign)\(integerResult).\(parts[1])"
        }
        return sign + integerResult
    }

    private func angleInput(_ value: Double) -> Double {
        angleMode == .degrees ? value * .pi / 180 : value
    }

    private func angleOutput(_ value: Double) -> Double {
        angleMode == .degrees ? value * 180 / .pi : value
    }

    private static func factorial(_ value: Double) -> Double? {
        guard value >= 0, value.rounded() == value, value <= 170 else { return nil }
        if value < 2 { return 1 }
        return (2...Int(value)).reduce(1.0) { $0 * Double($1) }
    }

    private func csvEscaped(_ value: String) -> String {
        "\"\(value.replacingOccurrences(of: "\"", with: "\"\""))\""
    }
}

private struct CalculatorSnapshot: Equatable {
    let display: String
    let expression: String
    let storedValue: Decimal?
    let pendingOperation: CalculatorOperation?
    let repeatOperation: CalculatorOperation?
    let repeatOperand: Decimal?
    let shouldReplaceDisplay: Bool
    let hasEnteredDigit: Bool
    let isDirectDigitEntry: Bool
    let lastError: String?
}

private final class ExpressionParser {
    enum ParserError: Error {
        case invalidExpression(Int)
        case divisionByZero(Int)
        case domainError(Int)

        var position: Int {
            switch self {
            case let .invalidExpression(position), let .divisionByZero(position), let .domainError(position):
                position
            }
        }
    }

    private let characters: [Character]
    private let angleMode: CalculatorAngleMode
    private let scale: Int
    private let roundingMode: Decimal.RoundingMode
    private var index = 0

    init(
        _ expression: String,
        angleMode: CalculatorAngleMode,
        scale: Int,
        roundingMode: Decimal.RoundingMode
    ) {
        self.angleMode = angleMode
        self.scale = scale
        self.roundingMode = roundingMode
        characters = Array(
            expression
                .lowercased()
                .replacingOccurrences(of: "×", with: "*")
                .replacingOccurrences(of: "÷", with: "/")
                .replacingOccurrences(of: "−", with: "-")
                .replacingOccurrences(of: "π", with: "pi")
                .replacingOccurrences(of: "√", with: "sqrt")
        )
    }

    func parse() throws -> Decimal {
        let value = try parseExpression()
        skipWhitespace()
        guard index == characters.count else { throw ParserError.invalidExpression(index) }
        return rounded(value)
    }

    private func parseExpression() throws -> Decimal {
        var value = try parseTerm()
        while true {
            skipWhitespace()
            if consume("+") {
                value = rounded(value + (try parseTerm()))
            } else if consume("-") {
                value = rounded(value - (try parseTerm()))
            } else {
                return value
            }
        }
    }

    private func parseTerm() throws -> Decimal {
        var value = try parseUnary()
        while true {
            skipWhitespace()
            if consume("*") {
                value = rounded(value * (try parseUnary()))
            } else if consume("/") {
                let divisor = try parseUnary()
                guard divisor != 0 else { throw ParserError.divisionByZero(index) }
                value = rounded(value / divisor)
            } else if beginsImplicitFactor {
                value = rounded(value * (try parseUnary()))
            } else {
                return value
            }
        }
    }

    private func parseUnary() throws -> Decimal {
        skipWhitespace()
        if consume("+") { return try parseUnary() }
        if consume("-") { return -(try parseUnary()) }
        return try parsePower()
    }

    private func parsePower() throws -> Decimal {
        var value = try parsePostfix()
        skipWhitespace()
        if consume("^") {
            let exponent = try parseUnary()
            let result = Foundation.pow(double(value), double(exponent))
            guard result.isFinite else { throw ParserError.domainError(index) }
            value = rounded(Decimal(result))
        }
        return value
    }

    private func parsePostfix() throws -> Decimal {
        var value = try parsePrimary()
        while true {
            skipWhitespace()
            if consume("%") {
                value = rounded(value / 100)
            } else if consume("!") {
                guard let result = factorial(value) else { throw ParserError.domainError(index) }
                value = result
            } else {
                return value
            }
        }
    }

    private func parsePrimary() throws -> Decimal {
        skipWhitespace()
        if consume("(") {
            let value = try parseExpression()
            skipWhitespace()
            guard consume(")") else { throw ParserError.invalidExpression(index) }
            return value
        }

        if index < characters.count, characters[index].isLetter {
            let identifier = parseIdentifier()
            if identifier == "pi" { return rounded(Decimal(Double.pi)) }
            if identifier == "e" { return rounded(Decimal(M_E)) }
            if identifier == "rand" || identifier == "random" { return rounded(Decimal(Double.random(in: 0..<1))) }
            skipWhitespace()
            guard consume("(") else { throw ParserError.invalidExpression(index) }
            let value = try parseExpression()
            skipWhitespace()
            guard consume(")") else { throw ParserError.invalidExpression(index) }
            return try applyFunction(identifier, value: value)
        }

        return try parseNumber()
    }

    private func parseIdentifier() -> String {
        let start = index
        while index < characters.count, characters[index].isLetter {
            index += 1
        }
        return String(characters[start..<index])
    }

    private func applyFunction(_ name: String, value: Decimal) throws -> Decimal {
        let value = double(value)
        let input = angleMode == .degrees ? value * .pi / 180 : value
        let result: Double
        switch name {
        case "sin": result = sin(input)
        case "cos": result = cos(input)
        case "tan": result = tan(input)
        case "asin":
            guard (-1...1).contains(value) else { throw ParserError.domainError(index) }
            result = angleMode == .degrees ? asin(value) * 180 / .pi : asin(value)
        case "acos":
            guard (-1...1).contains(value) else { throw ParserError.domainError(index) }
            result = angleMode == .degrees ? acos(value) * 180 / .pi : acos(value)
        case "atan": result = angleMode == .degrees ? atan(value) * 180 / .pi : atan(value)
        case "sqrt":
            guard value >= 0 else { throw ParserError.domainError(index) }
            result = sqrt(value)
        case "cbrt": result = cbrt(value)
        case "abs": result = abs(value)
        case "ln":
            guard value > 0 else { throw ParserError.domainError(index) }
            result = log(value)
        case "log":
            guard value > 0 else { throw ParserError.domainError(index) }
            result = log10(value)
        case "exp": result = exp(value)
        default: throw ParserError.invalidExpression(index)
        }
        guard result.isFinite else { throw ParserError.domainError(index) }
        return rounded(Decimal(result))
    }

    private func parseNumber() throws -> Decimal {
        skipWhitespace()
        let start = index
        var hasDecimalPoint = false
        var hasExponent = false

        while index < characters.count {
            let character = characters[index]
            if character.isNumber {
                index += 1
            } else if character == ".", !hasDecimalPoint {
                hasDecimalPoint = true
                index += 1
            } else if (character == "e" || character == "E"), !hasExponent, index > start {
                hasExponent = true
                index += 1
                if index < characters.count, characters[index] == "+" || characters[index] == "-" {
                    index += 1
                }
            } else {
                break
            }
        }

        guard index > start else { throw ParserError.invalidExpression(index) }
        let number = String(characters[start..<index])
        guard number != ".",
              !number.hasSuffix("e"), !number.hasSuffix("e+"), !number.hasSuffix("e-"),
              let value = Decimal(string: number, locale: Locale(identifier: "en_US_POSIX")) else {
            throw ParserError.invalidExpression(index)
        }
        return rounded(value)
    }

    private func factorial(_ value: Decimal) -> Decimal? {
        let number = NSDecimalNumber(decimal: value)
        let integer = number.intValue
        guard value >= 0, Decimal(integer) == value, integer <= 100 else { return nil }
        if integer < 2 { return 1 }
        return (2...integer).reduce(Decimal(1)) { rounded($0 * Decimal($1)) }
    }

    private var beginsImplicitFactor: Bool {
        guard index < characters.count else { return false }
        return characters[index] == "(" || characters[index].isLetter
    }

    private func rounded(_ value: Decimal) -> Decimal {
        var source = value
        var result = Decimal()
        NSDecimalRound(&result, &source, scale, roundingMode)
        return result
    }

    private func double(_ value: Decimal) -> Double {
        NSDecimalNumber(decimal: value).doubleValue
    }

    private func skipWhitespace() {
        while index < characters.count, characters[index].isWhitespace {
            index += 1
        }
    }

    private func consume(_ character: Character) -> Bool {
        guard index < characters.count, characters[index] == character else { return false }
        index += 1
        return true
    }
}
