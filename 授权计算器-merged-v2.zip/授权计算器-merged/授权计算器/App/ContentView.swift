import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct ContentView: View {
    @EnvironmentObject private var authorization: AuthorizationManager
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var showingAuthorizedSoftware = false
    @State private var isInviteVerifying = false

    var body: some View {
        Group {
            if showingAuthorizedSoftware && authorization.isAuthorized {
                AuthorizedSoftwareView {
                    showingAuthorizedSoftware = false
                }
                .transition(pageTransition)
            } else {
                LocalLedgerRootView(
                    isInviteVerifying: $isInviteVerifying,
                    onInviteCode: verifyInviteCode
                )
                .transition(pageTransition)
            }
        }
        .preferredColorScheme(.dark)
        .animation(
            reduceMotion ? nil : .spring(response: 0.36, dampingFraction: 1),
            value: showingAuthorizedSoftware
        )
        .task {
            if await authorization.checkOnLaunch() {
                showingAuthorizedSoftware = true
            }
        }
    }

    private func verifyInviteCode(_ code: String) {
        guard !isInviteVerifying else { return }
        isInviteVerifying = true
        Task {
            let success = await authorization.verify(code: code)
            if success {
                showingAuthorizedSoftware = true
            }
            isInviteVerifying = false
        }
    }

    private var pageTransition: AnyTransition {
        reduceMotion ? .identity : .opacity.combined(with: .scale(scale: 0.985))
    }
}

struct CalculatorBackground: View {
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.025, green: 0.035, blue: 0.075),
                    Color(red: 0.035, green: 0.025, blue: 0.085),
                    .black
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )

            Circle()
                .fill(Color.cyan.opacity(0.16))
                .frame(width: 280, height: 280)
                .blur(radius: 70)
                .offset(x: -170, y: -320)

            Circle()
                .fill(Color.purple.opacity(0.20))
                .frame(width: 320, height: 320)
                .blur(radius: 90)
                .offset(x: 180, y: -30)

            Circle()
                .fill(Color.blue.opacity(0.14))
                .frame(width: 260, height: 260)
                .blur(radius: 80)
                .offset(x: -150, y: 350)
        }
        .ignoresSafeArea()
    }
}

struct AuroraCalculatorView: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Binding var isInviteVerifying: Bool
    let onInviteCode: (String) -> Void
    @AppStorage("calculator.haptics.enabled") private var hapticsEnabled = true
    @ScaledMetric(relativeTo: .largeTitle) private var resultFontSize: CGFloat = 59
    @ScaledMetric(relativeTo: .title2) private var keyFontSize: CGFloat = 28

    @State private var engine = CalculatorEngine()
    @State private var showingHistory = false
    @State private var showingExpressionEditor = false
    @State private var showingScientificCalculator = false
    @State private var showingCalculatorTools = false
    @State private var showingMemory = false
    @State private var showingSettings = false
    @State private var showingClearHistoryConfirmation = false
    @State private var showingHistoryExporter = false
    @State private var editorText = ""
    @State private var editorSelection = NSRange(location: 0, length: 0)
    @State private var editorPreview = CalculatorExpressionPreview(result: nil, error: nil, errorPosition: nil)
    @State private var copyConfirmation = false
    @State private var historySearchText = ""
    @State private var showsFavoritesOnly = false
    @State private var isSelectingHistory = false
    @State private var selectedHistoryIDs: Set<UUID> = []
    @State private var editingHistoryEntry: CalculationHistoryEntry?
    @State private var historyNoteText = ""
    @State private var historyExportDocument = HistoryCSVDocument(text: "")

    private let horizontalPadding: CGFloat = 16
    private let keySpacing: CGFloat = 11

    var body: some View {
        GeometryReader { geometry in
            let usesWideLayout = geometry.size.width >= 700 || geometry.size.width > geometry.size.height * 1.18
            if usesWideLayout {
                HStack(spacing: 18) {
                    VStack(spacing: 14) {
                        displayPanel(height: min(220, geometry.size.height * 0.42))
                        recentHistoryPanel
                    }
                    .frame(maxWidth: .infinity)

                    calculatorKeypad(keyHeight: resolvedWideKeyHeight(in: geometry.size))
                        .frame(maxWidth: min(560, geometry.size.width * 0.48))
                }
                .padding(.horizontal, 18)
                .padding(.vertical, 12)
            } else {
                VStack(spacing: 0) {
                    Spacer(minLength: 18)
                    displayPanel(height: min(190, geometry.size.height * 0.24))
                        .padding(.horizontal, horizontalPadding)
                    Spacer(minLength: 18)
                    calculatorKeypad(keyHeight: resolvedKeyHeight(in: geometry.size))
                        .padding(.horizontal, horizontalPadding)
                        .padding(.bottom, 8)
                }
            }
        }
        .background(
            CalculatorKeyboardCommandView(action: handleKeyboardAction)
                .frame(width: 1, height: 1)
                .opacity(0.01)
        )
        .sheet(isPresented: $showingHistory) { historySheet }
        .sheet(isPresented: $showingExpressionEditor) { expressionEditorSheet }
        .sheet(isPresented: $showingScientificCalculator) {
            ScientificCalculatorView(engine: $engine)
        }
        .sheet(isPresented: $showingCalculatorTools) { CalculatorToolsHubView() }
        .sheet(isPresented: $showingMemory) { CalculatorMemoryView(engine: $engine) }
        .sheet(isPresented: $showingSettings) { CalculatorSettingsView(engine: $engine) }
        .fileExporter(
            isPresented: $showingHistoryExporter,
            document: historyExportDocument,
            contentType: .commaSeparatedText,
            defaultFilename: "计算历史"
        ) { _ in }
    }

    private func calculatorKeypad(keyHeight: CGFloat) -> some View {
        let columns = Array(repeating: GridItem(.flexible(), spacing: keySpacing), count: 4)
        return LazyVGrid(columns: columns, spacing: keySpacing) {
            key("AC", role: .utility, height: keyHeight) { engine.clear() }
            key("±", role: .utility, height: keyHeight) { engine.toggleSign() }
            key("%", role: .utility, height: keyHeight) { engine.percent() }
            key("÷", role: .operation, height: keyHeight) { engine.choose(.divide) }
            digit("7", height: keyHeight); digit("8", height: keyHeight); digit("9", height: keyHeight)
            key("×", role: .operation, height: keyHeight) { engine.choose(.multiply) }
            digit("4", height: keyHeight); digit("5", height: keyHeight); digit("6", height: keyHeight)
            key("−", role: .operation, height: keyHeight) { engine.choose(.subtract) }
            digit("1", height: keyHeight); digit("2", height: keyHeight); digit("3", height: keyHeight)
            key("+", role: .operation, height: keyHeight) { engine.choose(.add) }

            Button { engine.input("0"); haptic(HapticKind.number) } label: {
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 24, style: .continuous).fill(keyGradient(for: .number))
                    keyBorder(cornerRadius: 24)
                    Text("0").font(.system(size: keyFontSize, weight: .medium, design: .rounded))
                        .padding(.leading, keyHeight * 0.38)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .contentShape(Rectangle())
            }
            .frame(height: keyHeight).gridCellColumns(2).foregroundStyle(.white)
            .buttonStyle(CalculatorPressStyle(reduceMotion: reduceMotion)).accessibilityLabel("数字 0")

            key(".", role: .number, height: keyHeight) { engine.decimalPoint() }
            Button(action: { handleEquals(); haptic(engine.lastError == nil ? HapticKind.success : HapticKind.error) }) {
                ZStack {
                    RoundedRectangle(cornerRadius: 24, style: .continuous).fill(keyGradient(for: .equals))
                    keyBorder(cornerRadius: 24)
                    Image(systemName: "equal").font(.system(size: 25, weight: .semibold))
                        .opacity(isInviteVerifying ? 0 : 1)
                    if isInviteVerifying { ProgressView().tint(.white) }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity).contentShape(Rectangle())
            }
            .frame(height: keyHeight).foregroundStyle(.white)
            .shadow(color: Color.cyan.opacity(0.24), radius: 16, y: 8)
            .buttonStyle(CalculatorPressStyle(reduceMotion: reduceMotion)).disabled(isInviteVerifying)
            .accessibilityLabel(isInviteVerifying ? "正在验证" : "等于")
        }
        .padding(10)
        .background { materialSurface(cornerRadius: 34, opaqueColor: Color(red: 0.075, green: 0.085, blue: 0.15)) }
        .overlay { RoundedRectangle(cornerRadius: 34, style: .continuous).stroke(Color.white.opacity(0.09), lineWidth: 1).allowsHitTesting(false) }
    }

    private var recentHistoryPanel: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack { Label("最近计算", systemImage: "clock").font(.headline); Spacer(); Button("全部") { showingHistory = true } }
            if engine.history.isEmpty {
                Text("完成计算后，最近结果会显示在这里。").font(.subheadline).foregroundStyle(.secondary)
            } else {
                ForEach(engine.history.prefix(4)) { entry in
                    Button { engine.restore(entry) } label: {
                        HStack { Text(entry.expression).lineLimit(1); Spacer(); Text(entry.result).monospacedDigit().fontWeight(.semibold) }
                    }
                    .buttonStyle(.plain).accessibilityHint("将结果放回计算器")
                }
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .background { materialSurface(cornerRadius: 24, opaqueColor: Color(red: 0.07, green: 0.08, blue: 0.145)) }
    }

    private func displayPanel(height: CGFloat) -> some View {
        VStack(alignment: .trailing, spacing: 8) {
            HStack(spacing: 8) {
                displayToolButton(
                    systemName: "clock.arrow.circlepath",
                    label: "历史记录",
                    badge: engine.history.isEmpty ? nil : "\(min(engine.history.count, 99))"
                ) {
                    showingHistory = true
                }

                displayToolButton(systemName: "pencil.line", label: "编辑表达式") {
                    editorText = engine.expressionForEditing
                    showingExpressionEditor = true
                }

                Spacer(minLength: 2)

                if copyConfirmation {
                    Text("已复制")
                        .font(.system(size: 11, weight: .semibold, design: .rounded))
                        .foregroundStyle(Color.cyan)
                        .transition(.opacity.combined(with: .scale))
                }

                displayToolButton(systemName: "doc.on.doc", label: "复制结果") {
                    copyToPasteboard(engine.display)
                }
                .disabled(!engine.canCopyResult)

                displayToolButton(systemName: "delete.left", label: "退格") {
                    engine.backspace()
                }
                .buttonRepeatBehavior(.enabled)

                advancedMenu
            }

            Spacer(minLength: 0)

            Text(engine.lastError ?? (engine.expression.isEmpty ? " " : engine.expression))
                .font(.system(size: 16, weight: .medium, design: .rounded))
                .foregroundStyle(engine.lastError == nil ? Color.white.opacity(0.42) : Color.red.opacity(0.82))
                .lineLimit(1)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack {
                    Spacer(minLength: 0)
                    Text(engine.formattedDisplay)
                        .font(.system(size: resultFontSize, weight: .light, design: .rounded))
                        .foregroundStyle(.white)
                        .monospacedDigit()
                        .contentTransition(.numericText())
                        .tracking(-1.2)
                        .fixedSize(horizontal: true, vertical: false)
                }
                .frame(minWidth: 1)
            }
            .accessibilityLabel("计算结果")
            .accessibilityValue(engine.formattedDisplay)
        }
        .frame(maxWidth: .infinity, minHeight: height, alignment: .bottomTrailing)
        .padding(.horizontal, 20)
        .padding(.vertical, 16)
        .background {
            materialSurface(
                cornerRadius: 32,
                opaqueColor: Color(red: 0.07, green: 0.08, blue: 0.145)
            )
        }
        .overlay {
            RoundedRectangle(cornerRadius: 32, style: .continuous)
                .stroke(
                    LinearGradient(
                        colors: [Color.white.opacity(0.18), Color.white.opacity(0.035)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: 1
                )
                .allowsHitTesting(false)
        }
        .shadow(color: Color.black.opacity(0.32), radius: 26, y: 14)
        .animation(
            reduceMotion ? nil : .spring(response: 0.32, dampingFraction: 1),
            value: engine.display
        )
    }

    private var advancedMenu: some View {
        Menu {
            Section("编辑") {
                Button { engine.undo() } label: {
                    Label("撤销", systemImage: "arrow.uturn.backward")
                }
                .disabled(!engine.canUndo)
                Button { engine.redo() } label: {
                    Label("重做", systemImage: "arrow.uturn.forward")
                }
                .disabled(!engine.canRedo)
                Button(action: pasteAndCalculate) {
                    Label("粘贴并计算", systemImage: "doc.on.clipboard")
                }
            }

            Section("高级功能") {
                Button { showingMemory = true } label: {
                    Label(engine.hasMemory ? "记忆功能 · M" : "记忆功能", systemImage: "memorychip")
                }
                Button { showingScientificCalculator = true } label: {
                    Label("科学计算", systemImage: "function")
                }
                Button { showingCalculatorTools = true } label: {
                    Label("计算工具", systemImage: "wrench.and.screwdriver")
                }
                Button { showingSettings = true } label: {
                    Label("计算器设置", systemImage: "gearshape")
                }
            }
        } label: {
            Image(systemName: "ellipsis")
                .font(.system(size: 16, weight: .bold))
                .frame(width: 34, height: 30)
                .background(Color.white.opacity(0.075), in: Capsule())
                .overlay(alignment: .topTrailing) {
                    if engine.hasMemory {
                        Circle()
                            .fill(Color.cyan)
                            .frame(width: 7, height: 7)
                            .offset(x: 2, y: -1)
                    }
                }
        }
        .foregroundStyle(.white.opacity(0.76))
        .accessibilityLabel("更多计算功能")
    }

    private func displayToolButton(
        systemName: String,
        label: String,
        badge: String? = nil,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: 15, weight: .semibold))
                .frame(width: 34, height: 30)
                .background(Color.white.opacity(0.075), in: Capsule())
                .overlay(alignment: .topTrailing) {
                    if let badge {
                        Text(badge)
                            .font(.system(size: 9, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 4)
                            .frame(minWidth: 15, minHeight: 15)
                            .background(Color.indigo, in: Capsule())
                            .offset(x: 5, y: -5)
                    }
                }
        }
        .buttonStyle(.plain)
        .foregroundStyle(.white.opacity(0.76))
        .accessibilityLabel(label)
    }

    private var historySheet: some View {
        NavigationStack {
            Group {
                if engine.history.isEmpty {
                    ContentUnavailableView(
                        "暂无历史记录",
                        systemImage: "clock.arrow.circlepath",
                        description: Text("完成计算后，表达式和结果会自动保存在这里。")
                    )
                } else if filteredHistory.isEmpty {
                    ContentUnavailableView.search(text: historySearchText)
                } else {
                    List {
                        ForEach(groupedHistory) { group in
                            Section(group.title) {
                                ForEach(group.entries) { entry in
                                    historyRow(entry)
                                }
                            }
                        }
                    }
                    .listStyle(.insetGrouped)
                }
            }
            .navigationTitle(showsFavoritesOnly ? "收藏记录" : "历史记录")
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $historySearchText, prompt: "搜索表达式、结果或备注")
            .safeAreaInset(edge: .bottom) {
                if isSelectingHistory {
                    selectionBar
                }
            }
            .toolbar { historyToolbar }
        }
        .preferredColorScheme(.dark)
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
        .confirmationDialog(
            "清空全部计算历史？",
            isPresented: $showingClearHistoryConfirmation,
            titleVisibility: .visible
        ) {
            Button("清空历史记录", role: .destructive) { engine.clearHistory() }
            Button("取消", role: .cancel) {}
        } message: {
            Text("此操作无法撤销。")
        }
        .sheet(item: $editingHistoryEntry) { entry in
            historyNoteEditor(entry)
        }
    }

    @ViewBuilder
    private func historyRow(_ entry: CalculationHistoryEntry) -> some View {
        HStack(spacing: 10) {
            if isSelectingHistory {
                Button {
                    toggleHistorySelection(entry.id)
                } label: {
                    Image(systemName: selectedHistoryIDs.contains(entry.id) ? "checkmark.circle.fill" : "circle")
                        .font(.title3)
                        .foregroundStyle(selectedHistoryIDs.contains(entry.id) ? Color.indigo : Color.secondary)
                }
                .buttonStyle(.plain)
            }

            Button {
                if isSelectingHistory {
                    toggleHistorySelection(entry.id)
                } else {
                    engine.restore(entry)
                    showingHistory = false
                }
            } label: {
                VStack(alignment: .leading, spacing: 6) {
                    HStack(alignment: .firstTextBaseline) {
                        Text(entry.expression)
                            .font(.system(size: 15, weight: .medium, design: .rounded))
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                        Spacer(minLength: 10)
                        Text(entry.result)
                            .font(.system(size: 22, weight: .semibold, design: .rounded))
                            .monospacedDigit()
                            .foregroundStyle(.primary)
                            .lineLimit(1)
                            .minimumScaleFactor(0.55)
                    }

                    if !entry.note.isEmpty {
                        Label(entry.note, systemImage: "note.text")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }

                    Text(entry.createdAt.formatted(date: .omitted, time: .shortened))
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityHint(isSelectingHistory ? "切换选择" : "将结果放回计算器")

            if !isSelectingHistory {
                Button {
                    engine.toggleFavorite(id: entry.id)
                } label: {
                    Image(systemName: entry.isFavorite ? "star.fill" : "star")
                        .foregroundStyle(entry.isFavorite ? Color.yellow : Color.secondary)
                        .padding(7)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(entry.isFavorite ? "取消收藏" : "收藏")
            }
        }
        .padding(.vertical, 5)
        .swipeActions(edge: .trailing, allowsFullSwipe: true) {
            Button(role: .destructive) { engine.deleteHistory(id: entry.id) } label: {
                Label("删除", systemImage: "trash")
            }
            Button { beginEditingNote(entry) } label: {
                Label("备注", systemImage: "note.text")
            }
            .tint(.orange)
        }
        .swipeActions(edge: .leading, allowsFullSwipe: true) {
            Button { copyToPasteboard("\(entry.expression) = \(entry.result)") } label: {
                Label("复制", systemImage: "doc.on.doc")
            }
            .tint(.indigo)
        }
        .contextMenu {
            Button { copyToPasteboard(entry.result) } label: {
                Label("复制结果", systemImage: "doc.on.doc")
            }
            Button { copyToPasteboard("\(entry.expression) = \(entry.result)") } label: {
                Label("复制完整算式", systemImage: "text.page")
            }
            Button { engine.toggleFavorite(id: entry.id) } label: {
                Label(entry.isFavorite ? "取消收藏" : "收藏", systemImage: entry.isFavorite ? "star.slash" : "star")
            }
            Button { beginEditingNote(entry) } label: {
                Label("编辑备注", systemImage: "note.text")
            }
            Button(role: .destructive) { engine.deleteHistory(id: entry.id) } label: {
                Label("删除这条记录", systemImage: "trash")
            }
        }
    }

    @ToolbarContentBuilder
    private var historyToolbar: some ToolbarContent {
        ToolbarItem(placement: .cancellationAction) {
            Button(isSelectingHistory ? "取消" : "完成") {
                if isSelectingHistory {
                    isSelectingHistory = false
                    selectedHistoryIDs.removeAll()
                } else {
                    showingHistory = false
                }
            }
        }

        ToolbarItemGroup(placement: .primaryAction) {
            if !isSelectingHistory {
                Button("选择") { isSelectingHistory = true }
                    .disabled(engine.history.isEmpty)

                Menu {
                    Button {
                        showsFavoritesOnly.toggle()
                    } label: {
                        Label(showsFavoritesOnly ? "显示全部记录" : "只看收藏", systemImage: "star")
                    }
                    Button(action: exportHistory) {
                        Label("导出 CSV", systemImage: "square.and.arrow.up")
                    }
                    Button(role: .destructive) {
                        showingClearHistoryConfirmation = true
                    } label: {
                        Label("清空历史", systemImage: "trash")
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
                .disabled(engine.history.isEmpty)
            }
        }
    }

    private var selectionBar: some View {
        HStack {
            Text("已选择 \(selectedHistoryIDs.count) 条")
                .font(.subheadline.weight(.medium))
            Spacer()
            Button("全选") {
                selectedHistoryIDs = Set(filteredHistory.map(\.id))
            }
            Button("删除", role: .destructive) {
                engine.deleteHistory(ids: selectedHistoryIDs)
                selectedHistoryIDs.removeAll()
                isSelectingHistory = false
            }
            .disabled(selectedHistoryIDs.isEmpty)
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 12)
        .background(.ultraThinMaterial)
    }

    private var filteredHistory: [CalculationHistoryEntry] {
        engine.history.filter { entry in
            let matchesFavorite = !showsFavoritesOnly || entry.isFavorite
            let query = historySearchText.trimmingCharacters(in: .whitespacesAndNewlines)
            let matchesSearch = query.isEmpty
                || entry.expression.localizedCaseInsensitiveContains(query)
                || entry.result.localizedCaseInsensitiveContains(query)
                || entry.note.localizedCaseInsensitiveContains(query)
            return matchesFavorite && matchesSearch
        }
    }

    private var groupedHistory: [HistoryDayGroup] {
        let calendar = Calendar.current
        let grouped = Dictionary(grouping: filteredHistory) {
            calendar.startOfDay(for: $0.createdAt)
        }
        return grouped.keys.sorted(by: >).map { date in
            HistoryDayGroup(date: date, title: historySectionTitle(for: date), entries: grouped[date] ?? [])
        }
    }

    private func historySectionTitle(for date: Date) -> String {
        let calendar = Calendar.current
        if calendar.isDateInToday(date) { return "今天" }
        if calendar.isDateInYesterday(date) { return "昨天" }
        return date.formatted(date: .long, time: .omitted)
    }

    private func historyNoteEditor(_ entry: CalculationHistoryEntry) -> some View {
        NavigationStack {
            Form {
                Section("算式") {
                    Text("\(entry.expression) = \(entry.result)")
                        .textSelection(.enabled)
                }
                Section("备注") {
                    TextField("添加用途、场景或说明", text: $historyNoteText, axis: .vertical)
                        .lineLimit(3...7)
                }
            }
            .navigationTitle("历史备注")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { editingHistoryEntry = nil }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        engine.updateNote(id: entry.id, note: historyNoteText)
                        editingHistoryEntry = nil
                    }
                }
            }
        }
        .preferredColorScheme(.dark)
        .presentationDetents([.medium])
    }

    private var expressionEditorSheet: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 16) {
                VStack(alignment: .leading, spacing: 7) {
                    Text("完整表达式")
                        .font(.headline)
                    Text("可移动光标局部修改；支持括号、百分号、阶乘、幂、常量与科学函数。")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                ZStack(alignment: .topLeading) {
                    if editorText.isEmpty {
                        Text("例如：(12 + 8) × 3 或 sin(30) + 2^3")
                            .foregroundStyle(.tertiary)
                            .padding(.horizontal, 18)
                            .padding(.vertical, 17)
                            .allowsHitTesting(false)
                    }
                    ExpressionTextView(
                        text: $editorText,
                        selection: $editorSelection,
                        errorPosition: editorPreview.errorPosition
                    )
                    .padding(10)
                    .frame(minHeight: 92, maxHeight: 120)
                }
                .background(Color.white.opacity(0.075), in: RoundedRectangle(cornerRadius: 16))
                .overlay {
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(Color.white.opacity(0.10), lineWidth: 1)
                }

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(["(", ")", "+", "−", "×", "÷", "%", "^", "!", "π", "sqrt(", "sin("], id: \.self) { symbol in
                            Button(symbol) { insertEditorToken(symbol) }
                                .font(.system(size: 16, weight: .semibold, design: .rounded))
                                .buttonStyle(.bordered)
                                .buttonBorderShape(.capsule)
                        }
                    }
                }

                if let result = editorPreview.result {
                    HStack {
                        Label("实时结果", systemImage: "equal.circle")
                        Spacer()
                        Text(result).monospacedDigit().textSelection(.enabled)
                    }
                    .font(.headline)
                    .foregroundStyle(Color.cyan)
                } else if let error = editorPreview.error {
                    Label(error, systemImage: "exclamationmark.circle.fill")
                        .font(.subheadline)
                        .foregroundStyle(Color.red.opacity(0.9))
                }

                Spacer(minLength: 0)

                Button(action: evaluateEditedExpression) {
                    Label("计算表达式", systemImage: "equal.circle.fill")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 5)
                }
                .buttonStyle(.borderedProminent)
                .buttonBorderShape(.roundedRectangle(radius: 15))
                .tint(.indigo)
            }
            .padding(20)
            .navigationTitle("编辑表达式")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { showingExpressionEditor = false }
                }
                ToolbarItem(placement: .primaryAction) {
                    Button { pasteIntoEditor() } label: {
                        Image(systemName: "doc.on.clipboard")
                    }
                    .accessibilityLabel("粘贴表达式")
                }
            }
        }
        .preferredColorScheme(.dark)
        .presentationDetents([.height(440), .medium])
        .presentationDragIndicator(.visible)
        .task(id: editorText) {
            let source = editorText
            if !source.isEmpty {
                do {
                    try await Task.sleep(nanoseconds: 100_000_000)
                } catch {
                    return
                }
            }
            guard !Task.isCancelled, source == editorText else { return }
            editorPreview = engine.previewExpression(source)
        }
    }

    private func evaluateEditedExpression() {
        if engine.evaluateExpression(editorText) {
            showingExpressionEditor = false
        }
    }

    private func pasteIntoEditor() {
        guard let pasted = UIPasteboard.general.string, !pasted.isEmpty else { return }
        editorText = pasted
        editorSelection = NSRange(location: (pasted as NSString).length, length: 0)
    }

    private func insertEditorToken(_ token: String) {
        let source = editorText as NSString
        let safeLocation = min(editorSelection.location, source.length)
        let safeLength = min(editorSelection.length, source.length - safeLocation)
        let range = NSRange(location: safeLocation, length: safeLength)
        editorText = source.replacingCharacters(in: range, with: token)
        editorSelection = NSRange(location: safeLocation + (token as NSString).length, length: 0)
    }

    private func pasteAndCalculate() {
        guard let pasted = UIPasteboard.general.string, !pasted.isEmpty else { return }
        editorText = pasted
        if !engine.evaluateExpression(pasted) {
            showingExpressionEditor = true
        }
    }

    private func beginEditingNote(_ entry: CalculationHistoryEntry) {
        historyNoteText = entry.note
        editingHistoryEntry = entry
    }

    private func toggleHistorySelection(_ id: UUID) {
        if selectedHistoryIDs.contains(id) {
            selectedHistoryIDs.remove(id)
        } else {
            selectedHistoryIDs.insert(id)
        }
    }

    private func exportHistory() {
        historyExportDocument = HistoryCSVDocument(text: engine.historyCSV())
        showingHistoryExporter = true
    }

    private func copyToPasteboard(_ value: String) {
        guard value != "Error" else { return }
        UIPasteboard.general.string = value
        if hapticsEnabled { CalculatorHapticFeedback.shared.success() }
        withAnimation(.easeOut(duration: 0.18)) {
            copyConfirmation = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.35) {
            withAnimation(.easeIn(duration: 0.18)) {
                copyConfirmation = false
            }
        }
    }

    private func handleEquals() {
        if engine.hasPendingCalculation {
            engine.equals()
            return
        }

        if let inviteCode = engine.invitationCodeCandidate {
            onInviteCode(inviteCode)
        }
    }

    private func digit(_ value: String, height: CGFloat) -> some View {
        key(value, role: .number, height: height) {
            engine.input(value)
        }
    }

    private enum KeyRole {
        case number
        case utility
        case operation
        case equals
    }

    private func key(
        _ title: String,
        role: KeyRole,
        height: CGFloat,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: { action(); haptic(role) }) {
            ZStack {
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .fill(keyGradient(for: role))
                keyBorder(cornerRadius: 24)
                Text(title)
                    .font(.system(size: keyFontSize, weight: .medium, design: .rounded))
                    .foregroundStyle(role == .utility ? Color.white.opacity(0.82) : .white)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .contentShape(Rectangle())
        }
        .frame(height: height)
        .shadow(color: Color.black.opacity(0.16), radius: 8, y: 5)
        .buttonStyle(CalculatorPressStyle(reduceMotion: reduceMotion))
        .accessibilityLabel(accessibilityLabel(for: title))
    }

    private func keyGradient(for role: KeyRole) -> LinearGradient {
        let colors: [Color]
        switch role {
        case .number:
            colors = [Color.white.opacity(0.13), Color.white.opacity(0.055)]
        case .utility:
            colors = [Color.teal.opacity(0.38), Color.indigo.opacity(0.25)]
        case .operation:
            colors = [Color(red: 0.55, green: 0.30, blue: 0.95), Color(red: 0.28, green: 0.20, blue: 0.80)]
        case .equals:
            colors = [Color(red: 0.10, green: 0.78, blue: 0.92), Color(red: 0.08, green: 0.42, blue: 0.96)]
        }
        return LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing)
    }

    private func keyBorder(cornerRadius: CGFloat) -> some View {
        RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
            .stroke(Color.white.opacity(0.10), lineWidth: 1)
            .allowsHitTesting(false)
    }

    @ViewBuilder
    private func materialSurface(cornerRadius: CGFloat, opaqueColor: Color) -> some View {
        let shape = RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
        if reduceTransparency {
            shape.fill(opaqueColor)
        } else {
            shape.fill(.ultraThinMaterial)
        }
    }

    private func accessibilityLabel(for title: String) -> String {
        switch title {
        case "AC": "清除"
        case "±": "切换正负号"
        case "%": "百分比"
        case "÷": "除以"
        case "×": "乘以"
        case "−": "减去"
        case "+": "加上"
        case ".": "小数点"
        default: "数字 \(title)"
        }
    }

    private func resolvedKeyHeight(in size: CGSize) -> CGFloat {
        let widthBased = (size.width - horizontalPadding * 2 - 20 - keySpacing * 3) / 4
        let keyboardBudget = size.height * 0.57
        let heightBased = (keyboardBudget - 20 - keySpacing * 4) / 5
        return max(52, min(widthBased, heightBased))
    }

    private func resolvedWideKeyHeight(in size: CGSize) -> CGFloat {
        max(48, min(76, (size.height - 24 - 20 - keySpacing * 4) / 5))
    }

    private enum HapticKind { case number, utility, operation, success, error }

    private func haptic(_ role: KeyRole) {
        switch role {
        case .number: haptic(HapticKind.number)
        case .utility: haptic(HapticKind.utility)
        case .operation: haptic(HapticKind.operation)
        case .equals: haptic(HapticKind.success)
        }
    }

    private func haptic(_ kind: HapticKind) {
        guard hapticsEnabled else { return }
        switch kind {
        case .number: CalculatorHapticFeedback.shared.number()
        case .utility: CalculatorHapticFeedback.shared.utility()
        case .operation: CalculatorHapticFeedback.shared.operation()
        case .success: CalculatorHapticFeedback.shared.success()
        case .error: CalculatorHapticFeedback.shared.error()
        }
    }

    private func handleKeyboardAction(_ action: CalculatorKeyboardAction) {
        switch action {
        case let .digit(value): engine.input(value); haptic(HapticKind.number)
        case .decimal: engine.decimalPoint(); haptic(HapticKind.number)
        case .add: engine.choose(.add); haptic(HapticKind.operation)
        case .subtract: engine.choose(.subtract); haptic(HapticKind.operation)
        case .multiply: engine.choose(.multiply); haptic(HapticKind.operation)
        case .divide: engine.choose(.divide); haptic(HapticKind.operation)
        case .percent: engine.percent(); haptic(HapticKind.utility)
        case .equals: handleEquals(); haptic(engine.lastError == nil ? HapticKind.success : HapticKind.error)
        case .backspace: engine.backspace(); haptic(HapticKind.utility)
        case .clear: engine.clear(); haptic(HapticKind.utility)
        case .undo: engine.undo()
        case .redo: engine.redo()
        case .copy: copyToPasteboard(engine.display)
        case .paste: pasteAndCalculate()
        }
    }
}

private struct HistoryDayGroup: Identifiable {
    let date: Date
    let title: String
    let entries: [CalculationHistoryEntry]
    var id: Date { date }
}

private struct HistoryCSVDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.commaSeparatedText] }
    var text: String

    init(text: String) {
        self.text = text
    }

    init(configuration: ReadConfiguration) throws {
        if let data = configuration.file.regularFileContents,
           let value = String(data: data, encoding: .utf8) {
            text = value
        } else {
            text = ""
        }
    }

    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: Data(text.utf8))
    }
}

private struct CalculatorPressStyle: ButtonStyle {
    let reduceMotion: Bool

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .contentShape(Rectangle())
            .scaleEffect(configuration.isPressed ? 0.965 : 1)
            .brightness(configuration.isPressed ? 0.07 : 0)
            .animation(
                reduceMotion
                    ? .linear(duration: 0.06)
                    : .spring(response: 0.24, dampingFraction: 1),
                value: configuration.isPressed
            )
    }
}

private struct ExpressionTextView: UIViewRepresentable {
    private static let functionRegex = try! NSRegularExpression(
        pattern: #"\b(sin|cos|tan|asin|acos|atan|sqrt|cbrt|abs|ln|log|exp|rand|random)\b"#
    )
    private static let numberRegex = try! NSRegularExpression(
        pattern: #"(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?"#
    )

    @Binding var text: String
    @Binding var selection: NSRange
    let errorPosition: Int?

    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }

    func makeUIView(context: Context) -> UITextView {
        let view = UITextView()
        view.delegate = context.coordinator
        view.backgroundColor = .clear
        view.keyboardType = .numbersAndPunctuation
        view.autocapitalizationType = .none
        view.autocorrectionType = .no
        view.smartQuotesType = .no
        view.smartDashesType = .no
        view.textContainerInset = UIEdgeInsets(top: 4, left: 4, bottom: 4, right: 4)
        view.accessibilityLabel = "表达式编辑器"
        return view
    }

    func updateUIView(_ view: UITextView, context: Context) {
        context.coordinator.parent = self
        if context.coordinator.renderedText != text || context.coordinator.renderedErrorPosition != errorPosition {
            let selected = view.selectedRange
            view.attributedText = highlightedText()
            context.coordinator.renderedText = text
            context.coordinator.renderedErrorPosition = errorPosition
            let preferredSelection = selection.location <= (text as NSString).length ? selection : selected
            let safeLocation = min(preferredSelection.location, (text as NSString).length)
            view.selectedRange = NSRange(
                location: safeLocation,
                length: min(preferredSelection.length, (text as NSString).length - safeLocation)
            )
        }
    }

    private func highlightedText() -> NSAttributedString {
        let result = NSMutableAttributedString(
            string: text,
            attributes: [
                .font: UIFont.monospacedSystemFont(ofSize: 20, weight: .medium),
                .foregroundColor: UIColor.white
            ]
        )
        let full = NSRange(location: 0, length: (text as NSString).length)
        Self.functionRegex.enumerateMatches(in: text, range: full) { match, _, _ in
            if let range = match?.range {
                result.addAttribute(.foregroundColor, value: UIColor.systemPurple, range: range)
            }
        }
        Self.numberRegex.enumerateMatches(in: text, range: full) { match, _, _ in
            if let range = match?.range {
                result.addAttribute(.foregroundColor, value: UIColor.systemCyan, range: range)
            }
        }
        if let errorPosition, full.length > 0 {
            let location = min(max(0, errorPosition), full.length - 1)
            result.addAttributes([
                .foregroundColor: UIColor.systemRed,
                .underlineColor: UIColor.systemRed,
                .underlineStyle: NSUnderlineStyle.thick.rawValue
            ], range: NSRange(location: location, length: 1))
        }
        return result
    }

    final class Coordinator: NSObject, UITextViewDelegate {
        var parent: ExpressionTextView
        var renderedText: String?
        var renderedErrorPosition: Int?
        init(parent: ExpressionTextView) { self.parent = parent }

        func textViewDidChange(_ textView: UITextView) {
            parent.text = textView.text
            parent.selection = textView.selectedRange
        }

        func textViewDidChangeSelection(_ textView: UITextView) {
            guard textView.markedTextRange == nil else { return }
            parent.selection = textView.selectedRange
        }
    }
}

private enum CalculatorKeyboardAction {
    case digit(String), decimal, add, subtract, multiply, divide, percent, equals
    case backspace, clear, undo, redo, copy, paste
}

private struct CalculatorKeyboardCommandView: UIViewRepresentable {
    let action: (CalculatorKeyboardAction) -> Void

    func makeUIView(context: Context) -> KeyboardCaptureView {
        let view = KeyboardCaptureView()
        view.action = action
        return view
    }

    func updateUIView(_ view: KeyboardCaptureView, context: Context) {
        view.action = action
    }
}

private final class KeyboardCaptureView: UIView {
    var action: ((CalculatorKeyboardAction) -> Void)?
    override var canBecomeFirstResponder: Bool { true }

    override func didMoveToWindow() {
        super.didMoveToWindow()
        if window != nil { becomeFirstResponder() }
    }

    private lazy var calculatorKeyCommands: [UIKeyCommand] = {
        var commands = (0...9).map { UIKeyCommand(input: String($0), modifierFlags: [], action: #selector(handleKey(_:))) }
        for input in [".", ",", "+", "-", "*", "/", "%", "=", "\r", "\u{8}", "\u{7f}", "\u{1b}"] {
            commands.append(UIKeyCommand(input: input, modifierFlags: [], action: #selector(handleKey(_:))))
        }
        commands.append(UIKeyCommand(input: "z", modifierFlags: .command, action: #selector(handleKey(_:))))
        commands.append(UIKeyCommand(input: "z", modifierFlags: [.command, .shift], action: #selector(handleKey(_:))))
        commands.append(UIKeyCommand(input: "c", modifierFlags: .command, action: #selector(handleKey(_:))))
        commands.append(UIKeyCommand(input: "v", modifierFlags: .command, action: #selector(handleKey(_:))))
        return commands
    }()

    override var keyCommands: [UIKeyCommand]? { calculatorKeyCommands }

    @objc private func handleKey(_ command: UIKeyCommand) {
        let flags = command.modifierFlags
        if flags.contains(.command) {
            switch command.input?.lowercased() {
            case "z": action?(flags.contains(.shift) ? .redo : .undo)
            case "c": action?(.copy)
            case "v": action?(.paste)
            default: break
            }
            return
        }
        guard let input = command.input else { return }
        if input.count == 1, input.first?.isNumber == true { action?(.digit(input)); return }
        switch input {
        case ".", ",": action?(.decimal)
        case "+": action?(.add)
        case "-": action?(.subtract)
        case "*": action?(.multiply)
        case "/": action?(.divide)
        case "%": action?(.percent)
        case "=", "\r": action?(.equals)
        case "\u{8}", "\u{7f}": action?(.backspace)
        case "\u{1b}": action?(.clear)
        default: break
        }
    }
}

private final class CalculatorHapticFeedback {
    static let shared = CalculatorHapticFeedback()

    private let numberGenerator = UIImpactFeedbackGenerator(style: .light)
    private let utilityGenerator = UIImpactFeedbackGenerator(style: .soft)
    private let operationGenerator = UIImpactFeedbackGenerator(style: .medium)
    private let notificationGenerator = UINotificationFeedbackGenerator()

    private init() {
        numberGenerator.prepare()
        utilityGenerator.prepare()
        operationGenerator.prepare()
        notificationGenerator.prepare()
    }

    func number() {
        numberGenerator.impactOccurred(intensity: 0.55)
        numberGenerator.prepare()
    }

    func utility() {
        utilityGenerator.impactOccurred()
        utilityGenerator.prepare()
    }

    func operation() {
        operationGenerator.impactOccurred()
        operationGenerator.prepare()
    }

    func success() {
        notificationGenerator.notificationOccurred(.success)
        notificationGenerator.prepare()
    }

    func error() {
        notificationGenerator.notificationOccurred(.error)
        notificationGenerator.prepare()
    }
}
