import Combine
import Foundation

enum LocalLedgerEntryKind: String, Codable, CaseIterable, Identifiable {
    case expense
    case income

    var id: String { rawValue }
    var title: String { self == .expense ? "支出" : "收入" }
    var symbol: String { self == .expense ? "arrow.up.right" : "arrow.down.left" }
}

enum LocalLedgerCategory: String, Codable, CaseIterable, Identifiable {
    case dining, shopping, transport, housing, entertainment, health
    case education, travel, salary, bonus, investment, other

    var id: String { rawValue }

    var title: String {
        switch self {
        case .dining: "餐饮"
        case .shopping: "购物"
        case .transport: "交通"
        case .housing: "居住"
        case .entertainment: "娱乐"
        case .health: "医疗"
        case .education: "学习"
        case .travel: "旅行"
        case .salary: "工资"
        case .bonus: "奖金"
        case .investment: "理财"
        case .other: "其他"
        }
    }

    var symbol: String {
        switch self {
        case .dining: "fork.knife"
        case .shopping: "bag.fill"
        case .transport: "car.fill"
        case .housing: "house.fill"
        case .entertainment: "gamecontroller.fill"
        case .health: "cross.case.fill"
        case .education: "book.fill"
        case .travel: "airplane"
        case .salary: "briefcase.fill"
        case .bonus: "gift.fill"
        case .investment: "chart.line.uptrend.xyaxis"
        case .other: "ellipsis.circle.fill"
        }
    }

    var supportsExpense: Bool {
        ![.salary, .bonus, .investment].contains(self)
    }

    var supportsIncome: Bool {
        [.salary, .bonus, .investment, .other].contains(self)
    }

    static func available(for kind: LocalLedgerEntryKind) -> [LocalLedgerCategory] {
        allCases.filter { kind == .expense ? $0.supportsExpense : $0.supportsIncome }
    }
}

enum LocalLedgerAccountKind: String, Codable, CaseIterable, Identifiable {
    case cash, bank, eWallet, credit, other

    var id: String { rawValue }

    var title: String {
        switch self {
        case .cash: "现金"
        case .bank: "银行卡"
        case .eWallet: "电子钱包"
        case .credit: "信用账户"
        case .other: "其他账户"
        }
    }

    var symbol: String {
        switch self {
        case .cash: "banknote.fill"
        case .bank: "creditcard.fill"
        case .eWallet: "iphone.gen3"
        case .credit: "creditcard.trianglebadge.exclamationmark"
        case .other: "wallet.bifold.fill"
        }
    }
}

struct LocalLedgerAccount: Codable, Identifiable, Hashable {
    let id: UUID
    var name: String
    var kind: LocalLedgerAccountKind
    var openingBalance: Decimal
    let createdAt: Date

    init(
        id: UUID = UUID(),
        name: String,
        kind: LocalLedgerAccountKind,
        openingBalance: Decimal = 0,
        createdAt: Date = .now
    ) {
        self.id = id
        self.name = name
        self.kind = kind
        self.openingBalance = openingBalance
        self.createdAt = createdAt
    }
}

struct LocalLedgerEntry: Codable, Identifiable, Hashable {
    let id: UUID
    var kind: LocalLedgerEntryKind
    var amount: Decimal
    var category: LocalLedgerCategory
    var accountID: UUID
    var date: Date
    var merchant: String
    var note: String
    let createdAt: Date
    var updatedAt: Date

    init(
        id: UUID = UUID(),
        kind: LocalLedgerEntryKind,
        amount: Decimal,
        category: LocalLedgerCategory,
        accountID: UUID,
        date: Date = .now,
        merchant: String = "",
        note: String = "",
        createdAt: Date = .now,
        updatedAt: Date = .now
    ) {
        self.id = id
        self.kind = kind
        self.amount = amount
        self.category = category
        self.accountID = accountID
        self.date = date
        self.merchant = merchant
        self.note = note
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}

struct LocalLedgerBudget: Codable, Identifiable, Hashable {
    let id: UUID
    var category: LocalLedgerCategory?
    var amount: Decimal
    var isEnabled: Bool
    let createdAt: Date

    init(
        id: UUID = UUID(),
        category: LocalLedgerCategory?,
        amount: Decimal,
        isEnabled: Bool = true,
        createdAt: Date = .now
    ) {
        self.id = id
        self.category = category
        self.amount = amount
        self.isEnabled = isEnabled
        self.createdAt = createdAt
    }
}

private struct LocalLedgerEnvelope: Codable {
    var accounts: [LocalLedgerAccount]
    var entries: [LocalLedgerEntry]
    var budgets: [LocalLedgerBudget]
}

@MainActor
final class LocalLedgerStore: ObservableObject {
    @Published private(set) var accounts: [LocalLedgerAccount]
    @Published private(set) var entries: [LocalLedgerEntry]
    @Published private(set) var budgets: [LocalLedgerBudget]

    private let defaults: UserDefaults
    private let storageKey = "local-ledger.data.v1"
    private let encoder = JSONEncoder()
    private let decoder = JSONDecoder()

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        if let data = defaults.data(forKey: storageKey),
           let envelope = try? decoder.decode(LocalLedgerEnvelope.self, from: data) {
            accounts = envelope.accounts
            entries = envelope.entries.sorted { $0.date > $1.date }
            budgets = envelope.budgets
        } else {
            accounts = [
                LocalLedgerAccount(name: "日常钱包", kind: .cash)
            ]
            entries = []
            budgets = []
        }

        if accounts.isEmpty {
            accounts = [LocalLedgerAccount(name: "日常钱包", kind: .cash)]
            persist()
        }
    }

    var totalBalance: Decimal {
        accounts.reduce(0) { $0 + balance(for: $1.id) }
    }

    var currentMonthEntries: [LocalLedgerEntry] {
        entries.filter { Calendar.current.isDate($0.date, equalTo: .now, toGranularity: .month) }
    }

    var currentMonthIncome: Decimal {
        currentMonthEntries.reduce(0) { $0 + ($1.kind == .income ? $1.amount : 0) }
    }

    var currentMonthExpense: Decimal {
        currentMonthEntries.reduce(0) { $0 + ($1.kind == .expense ? $1.amount : 0) }
    }

    var currentMonthNet: Decimal { currentMonthIncome - currentMonthExpense }

    var currentMonthCategoryExpenses: [(category: LocalLedgerCategory, amount: Decimal)] {
        var values: [LocalLedgerCategory: Decimal] = [:]
        for entry in currentMonthEntries where entry.kind == .expense {
            values[entry.category, default: 0] += entry.amount
        }
        return values.map { ($0.key, $0.value) }.sorted { $0.amount > $1.amount }
    }

    func account(id: UUID) -> LocalLedgerAccount? {
        accounts.first { $0.id == id }
    }

    func balance(for accountID: UUID) -> Decimal {
        let opening = account(id: accountID)?.openingBalance ?? 0
        return entries.reduce(opening) { result, entry in
            guard entry.accountID == accountID else { return result }
            return result + (entry.kind == .income ? entry.amount : -entry.amount)
        }
    }

    func spent(for budget: LocalLedgerBudget) -> Decimal {
        currentMonthEntries.reduce(0) { result, entry in
            guard entry.kind == .expense,
                  budget.category == nil || budget.category == entry.category else {
                return result
            }
            return result + entry.amount
        }
    }

    func addEntry(
        kind: LocalLedgerEntryKind,
        amount: Decimal,
        category: LocalLedgerCategory,
        accountID: UUID,
        date: Date,
        merchant: String,
        note: String
    ) {
        guard amount > 0, account(id: accountID) != nil else { return }
        entries.append(
            LocalLedgerEntry(
                kind: kind,
                amount: roundedMoney(amount),
                category: category,
                accountID: accountID,
                date: date,
                merchant: normalizedText(merchant),
                note: normalizedText(note)
            )
        )
        sortEntriesAndPersist()
    }

    func updateEntry(
        id: UUID,
        kind: LocalLedgerEntryKind,
        amount: Decimal,
        category: LocalLedgerCategory,
        accountID: UUID,
        date: Date,
        merchant: String,
        note: String
    ) {
        guard amount > 0,
              account(id: accountID) != nil,
              let index = entries.firstIndex(where: { $0.id == id }) else { return }
        entries[index].kind = kind
        entries[index].amount = roundedMoney(amount)
        entries[index].category = category
        entries[index].accountID = accountID
        entries[index].date = date
        entries[index].merchant = normalizedText(merchant)
        entries[index].note = normalizedText(note)
        entries[index].updatedAt = .now
        sortEntriesAndPersist()
    }

    func deleteEntry(id: UUID) {
        entries.removeAll { $0.id == id }
        persist()
    }

    func addAccount(name: String, kind: LocalLedgerAccountKind, openingBalance: Decimal) {
        let name = normalizedText(name)
        guard !name.isEmpty else { return }
        accounts.append(
            LocalLedgerAccount(
                name: name,
                kind: kind,
                openingBalance: roundedMoney(openingBalance)
            )
        )
        persist()
    }

    func updateAccount(id: UUID, name: String, kind: LocalLedgerAccountKind, openingBalance: Decimal) {
        let name = normalizedText(name)
        guard !name.isEmpty, let index = accounts.firstIndex(where: { $0.id == id }) else { return }
        accounts[index].name = name
        accounts[index].kind = kind
        accounts[index].openingBalance = roundedMoney(openingBalance)
        persist()
    }

    @discardableResult
    func deleteAccount(id: UUID) -> Bool {
        guard accounts.count > 1, !entries.contains(where: { $0.accountID == id }) else { return false }
        accounts.removeAll { $0.id == id }
        persist()
        return true
    }

    func saveBudget(id: UUID?, category: LocalLedgerCategory?, amount: Decimal, isEnabled: Bool) {
        guard amount > 0 else { return }
        if let id, let index = budgets.firstIndex(where: { $0.id == id }) {
            budgets[index].category = category
            budgets[index].amount = roundedMoney(amount)
            budgets[index].isEnabled = isEnabled
        } else if let index = budgets.firstIndex(where: { $0.category == category }) {
            budgets[index].amount = roundedMoney(amount)
            budgets[index].isEnabled = isEnabled
        } else {
            budgets.append(LocalLedgerBudget(category: category, amount: roundedMoney(amount), isEnabled: isEnabled))
        }
        budgets.sort { ($0.category?.title ?? "") < ($1.category?.title ?? "") }
        persist()
    }

    func deleteBudget(id: UUID) {
        budgets.removeAll { $0.id == id }
        persist()
    }

    func clearAllData() {
        accounts = [LocalLedgerAccount(name: "日常钱包", kind: .cash)]
        entries = []
        budgets = []
        persist()
    }

    func moneyString(_ value: Decimal, signed: Bool = false) -> String {
        let number = NSDecimalNumber(decimal: roundedMoney(value))
        let prefix = signed && value > 0 ? "+" : ""
        return prefix + (Self.moneyFormatter.string(from: number) ?? number.stringValue)
    }

    private func sortEntriesAndPersist() {
        entries.sort { lhs, rhs in
            lhs.date == rhs.date ? lhs.updatedAt > rhs.updatedAt : lhs.date > rhs.date
        }
        persist()
    }

    private func persist() {
        let envelope = LocalLedgerEnvelope(accounts: accounts, entries: entries, budgets: budgets)
        guard let data = try? encoder.encode(envelope) else { return }
        defaults.set(data, forKey: storageKey)
    }

    private func roundedMoney(_ value: Decimal) -> Decimal {
        var source = value
        var result = Decimal()
        NSDecimalRound(&result, &source, 2, .bankers)
        return result
    }

    private func normalizedText(_ value: String) -> String {
        String(value.trimmingCharacters(in: .whitespacesAndNewlines).prefix(80))
    }

    private static let moneyFormatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.locale = .current
        formatter.numberStyle = .decimal
        formatter.usesGroupingSeparator = true
        formatter.minimumFractionDigits = 2
        formatter.maximumFractionDigits = 2
        return formatter
    }()
}
