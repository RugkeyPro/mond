import SwiftUI
import CompanySoftwareKit

struct AuthorizedSoftwareView: View {
    let onBack: () -> Void

    var body: some View {
        CompanySoftwareEntry(onBack: onBack)
    }
}
