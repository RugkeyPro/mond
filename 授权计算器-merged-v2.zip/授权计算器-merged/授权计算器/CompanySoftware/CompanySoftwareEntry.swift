//
//  CompanySoftwareEntry.swift
//  授权计算器 (CompanySoftwareKit)
//
//  入口适配器：把本地最新版 mond ContentView 以 CompanySoftwareEntry 形式暴露给宿主 App。
//  授权验证通过后，宿主 App 通过 CompanySoftwareEntry(onBack:) 进入本界面。
//

import SwiftUI
import PartyUI
import Foundation
import Darwin

// ── 全局变量（mond.swift 中原有，此处移植） ──────────────────────────────────
var pipe = Pipe()
var sema = DispatchSemaphore(value: 0)
var fm = FileManager.default

var path: String {
    let url = FileManager.default
        .urls(for: .documentDirectory, in: .userDomainMask)[0]
        .appendingPathComponent("test.txt")
    if !FileManager.default.fileExists(atPath: url.path) {
        FileManager.default.createFile(atPath: url.path, contents: Data())
    }
    return url.path
}

// ── 公开入口（宿主 App 使用此类型） ──────────────────────────────────────────
/// 宿主 App 在授权验证成功后通过该类型嵌入 mond 文件管理主界面。
@MainActor
public struct CompanySoftwareEntry: View {
    private let onBack: () -> Void

    public init(onBack: @escaping () -> Void) {
        self.onBack = onBack
    }

    public var body: some View {
        AnyView(CompanySoftwareRoot(onBack: onBack))
    }
}

// ── 实际根视图（内部实现） ────────────────────────────────────────────────────
private struct CompanySoftwareRoot: View {
    @StateObject private var state = AppState()
    let onBack: () -> Void

    init(onBack: @escaping () -> Void) {
        self.onBack = onBack
        UserDefaults.standard.register(defaults: ["exploit_method": "bad_query"])
        if !is_debugged() {
            setvbuf(stdout, nil, _IONBF, 0)
            dup2(pipe.fileHandleForWriting.fileDescriptor, STDOUT_FILENO)
        }
    }

    var body: some View {
        // CompanyRootView 即本地 mond ContentView（已重命名）
        CompanyRootView(onBack: onBack)
            .environmentObject(state)
            .onAppear {
                if !is_supported() {
                    Alertinator.shared.alert(
                        title: "当前系统可能不受支持",
                        body: "mond 支持 iOS 16.0 – 27.x。"
                    )
                }
            }
            .overlay {
                if state.show_respring {
                    RespringView()
                        .brightness(-1.0)
                        .ignoresSafeArea()
                        .onAppear {
                            print("(respring) respringing now...")
                        }
                }
            }
    }
}
