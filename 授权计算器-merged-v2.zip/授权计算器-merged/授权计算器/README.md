# 弦光 (LumaArc)

“弦光”是一款以本地账本为主、计算器为实用工具的 SwiftUI iOS App。桌面显示名为“弦光”，Bundle ID 为 `com.beiqizou.xianguang`。

## 已实现

- 首页采用全屏计算器布局；授权码直接显示在计算器显示区域，通过数字键盘输入。
- 点击计算器“等于”时把显示区域中的 8 位数字交给服务器兑换；验证失败时显示值保持不变。
- 使用 Keychain 保存授权令牌和稳定的安装设备 ID，首次兑换时将设备 ID 发送给后台。
- 每次启动调用后台复验；授权码作废、删除、过期或设备不匹配时不放行并清除本地令牌。
- 验证成功进入独立的“我的软件”接入位，后续可替换为你提供的软件源码。

## 授权平台接口

首次输入 8 位数字授权码时调用：

```http
POST https://api.xn--8wto81h.online/api/v1/invites/redeem
Content-Type: application/json
```

```json
{
  "code": "12345678",
  "deviceId": "本机稳定安装 ID"
}
```

兑换成功后保存服务器返回的 `token`。每次启动和点击“等于”复验时调用：

```http
GET https://api.xn--8wto81h.online/api/v1/app/me
Authorization: Bearer <token>
X-Device-ID: <本机稳定安装 ID>
```

以响应中的 `authorized: true` 放行。客户端不本地判断授权码是否有效，后台继续负责授权码是否存在、是否已使用、是否过期、是否作废、是否删除以及设备绑定。

## 构建

```sh
xcodebuild -project '授权计算器.xcodeproj' -scheme '授权计算器' -sdk iphonesimulator CODE_SIGNING_ALLOWED=NO build
```

在 Xcode 中打开工程后请选择自己的 Team。提供软件源码后，将其替换到 `AuthorizedSoftwareView` 接入位即可保留现有授权流程。
