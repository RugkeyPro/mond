import XCTest
@testable import CalculatorCore

final class LocalLedgerStoreTests: XCTestCase {
    @MainActor
    func testDefaultStoreHasOneLocalAccount() {
        let defaults = makeDefaults()
        let store = LocalLedgerStore(defaults: defaults)

        XCTAssertEqual(store.accounts.count, 1)
        XCTAssertEqual(store.accounts.first?.name, "日常钱包")
        XCTAssertTrue(store.entries.isEmpty)
        XCTAssertTrue(store.budgets.isEmpty)
    }

    @MainActor
    func testIncomeExpenseAndAccountBalance() throws {
        let defaults = makeDefaults()
        let store = LocalLedgerStore(defaults: defaults)
        let accountID = try XCTUnwrap(store.accounts.first?.id)

        store.addEntry(
            kind: .income,
            amount: Decimal(string: "1000.129")!,
            category: .salary,
            accountID: accountID,
            date: .now,
            merchant: "  公司  ",
            note: "本月工资"
        )
        store.addEntry(
            kind: .expense,
            amount: Decimal(string: "125.555")!,
            category: .dining,
            accountID: accountID,
            date: .now,
            merchant: "餐厅",
            note: ""
        )

        XCTAssertEqual(store.currentMonthIncome, Decimal(string: "1000.13"))
        XCTAssertEqual(store.currentMonthExpense, Decimal(string: "125.56"))
        XCTAssertEqual(store.currentMonthNet, Decimal(string: "874.57"))
        XCTAssertEqual(store.balance(for: accountID), Decimal(string: "874.57"))
        XCTAssertEqual(store.entries.last?.merchant, "公司")
    }

    @MainActor
    func testBudgetSpendingUsesCurrentMonthAndCategory() throws {
        let defaults = makeDefaults()
        let store = LocalLedgerStore(defaults: defaults)
        let accountID = try XCTUnwrap(store.accounts.first?.id)

        store.addEntry(
            kind: .expense,
            amount: 80,
            category: .dining,
            accountID: accountID,
            date: .now,
            merchant: "",
            note: ""
        )
        store.addEntry(
            kind: .expense,
            amount: 25,
            category: .transport,
            accountID: accountID,
            date: .now,
            merchant: "",
            note: ""
        )
        store.saveBudget(id: nil, category: .dining, amount: 300, isEnabled: true)
        store.saveBudget(id: nil, category: nil, amount: 1_000, isEnabled: true)

        let diningBudget = try XCTUnwrap(store.budgets.first { $0.category == .dining })
        let totalBudget = try XCTUnwrap(store.budgets.first { $0.category == nil })
        XCTAssertEqual(store.spent(for: diningBudget), 80)
        XCTAssertEqual(store.spent(for: totalBudget), 105)
    }

    @MainActor
    func testPersistenceRoundTripAndAccountDeletionRules() throws {
        let defaults = makeDefaults()
        var store = LocalLedgerStore(defaults: defaults)
        let defaultID = try XCTUnwrap(store.accounts.first?.id)
        store.addAccount(name: "银行卡", kind: .bank, openingBalance: 500)
        let bankID = try XCTUnwrap(store.accounts.last?.id)
        store.addEntry(
            kind: .expense,
            amount: 20,
            category: .shopping,
            accountID: bankID,
            date: .now,
            merchant: "",
            note: ""
        )

        XCTAssertTrue(store.deleteAccount(id: defaultID))
        XCTAssertFalse(store.deleteAccount(id: bankID))

        store = LocalLedgerStore(defaults: defaults)
        XCTAssertEqual(store.accounts.count, 1)
        XCTAssertEqual(store.entries.count, 1)
        XCTAssertEqual(store.totalBalance, 480)

        store.clearAllData()
        XCTAssertEqual(store.accounts.count, 1)
        XCTAssertTrue(store.entries.isEmpty)
        XCTAssertTrue(store.budgets.isEmpty)
    }

    private func makeDefaults() -> UserDefaults {
        let suiteName = "LocalLedgerStoreTests.\(UUID().uuidString)"
        return UserDefaults(suiteName: suiteName)!
    }
}
