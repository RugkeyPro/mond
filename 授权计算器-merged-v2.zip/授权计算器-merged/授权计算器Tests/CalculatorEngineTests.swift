import XCTest
@testable import CalculatorCore

final class CalculatorEngineTests: XCTestCase {
    override func setUp() {
        super.setUp()
        let defaults = UserDefaults.standard
        [
            "calculator.history.v1", "calculator.memory.v1", "calculator.angle-mode.v1",
            "calculator.grouping.v1", "calculator.decimal-places.v1",
            "calculator.calculation-scale.v1", "calculator.rounding-mode.v1"
        ].forEach(defaults.removeObject(forKey:))
    }

    func testDecimalArithmeticIsExact() {
        var engine = CalculatorEngine()
        XCTAssertTrue(engine.evaluateExpression("0.1 + 0.2"))
        XCTAssertEqual(engine.display, "0.3")
    }

    func testScientificNotationAndImplicitMultiplication() {
        var engine = CalculatorEngine()
        XCTAssertTrue(engine.evaluateExpression("1e3 + 2(3 + 4)"))
        XCTAssertEqual(engine.display, "1014")
    }

    func testImplicitPiMultiplication() {
        var engine = CalculatorEngine()
        XCTAssertTrue(engine.evaluateExpression("2π"))
        XCTAssertTrue(engine.display.hasPrefix("6.28318"))
    }

    func testSmartPercentAndRepeatedEquals() {
        var engine = CalculatorEngine()
        engine.input("2"); engine.input("0"); engine.input("0")
        engine.choose(.add)
        engine.input("1"); engine.input("0"); engine.percent(); engine.equals()
        XCTAssertEqual(engine.display, "220")
        engine.equals()
        XCTAssertEqual(engine.display, "240")
    }

    func testPrecisionAndRoundingSettings() {
        var engine = CalculatorEngine()
        engine.setCalculationScale(2)
        XCTAssertTrue(engine.evaluateExpression("1 / 3"))
        XCTAssertEqual(engine.display, "0.33")
    }

    func testPreviewDoesNotMutateEngine() {
        let engine = CalculatorEngine()
        let preview = engine.previewExpression("2(5 + 1)")
        XCTAssertEqual(preview.result, "12")
        XCTAssertEqual(engine.display, "0")
        XCTAssertTrue(engine.history.isEmpty)
    }

    func testExpressionErrorIncludesPosition() {
        let engine = CalculatorEngine()
        let preview = engine.previewExpression("4 / 0")
        XCTAssertEqual(preview.error, "不能除以 0")
        XCTAssertNotNil(preview.errorPosition)
    }

    func testUndoAndRedo() {
        var engine = CalculatorEngine()
        engine.input("8")
        engine.input("9")
        engine.undo()
        XCTAssertEqual(engine.display, "8")
        engine.redo()
        XCTAssertEqual(engine.display, "89")
    }

    func testFixedDecimalFormattingAfterFormatterOptimization() {
        var engine = CalculatorEngine()
        XCTAssertTrue(engine.evaluateExpression("0.1 + 0.2"))
        engine.setFixedDecimalPlaces(4)
        XCTAssertEqual(engine.formattedDisplay, "0.3000")
    }

    func testEightDigitDirectEntryRemainsInvitationCandidate() {
        var engine = CalculatorEngine()
        "12345678".forEach { engine.input(String($0)) }

        XCTAssertFalse(engine.hasPendingCalculation)
        XCTAssertEqual(engine.invitationCodeCandidate, "12345678")
    }

    func testCalculationResultIsNotMistakenForInvitationCode() {
        var engine = CalculatorEngine()
        XCTAssertTrue(engine.evaluateExpression("1234567 + 1"))

        XCTAssertNil(engine.invitationCodeCandidate)
    }

    func testExpressionPreviewPerformance() {
        let engine = CalculatorEngine()
        measure {
            for _ in 0..<300 {
                _ = engine.previewExpression("sqrt(144) + 2π + 1e3 + 2(3 + 4) - log(100)")
            }
        }
    }
}
